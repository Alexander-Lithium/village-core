# Village Core v1.0

A small, deterministic, agent-based village simulation (research testbed). Pure ES modules with no dependencies, so it runs in Node ≥ 18 and in modern browsers.

## How to run

```
node gen_cast.js          # writes cast/cast_s1_n20.csv
node gen_rule_tables.js   # writes tables/rules/T1..T12 (normalised form)
node test.js              # acceptance tests + golden hashes
node build_viewer.js      # writes viewer.html (open it in a browser, no network needed)

node run.js --runSeed 1 --n 20 --days 30 --tableDir tables/rules --out results/A
node run.js --runSeed 1 --n 20 --days 30 --seeds 1-100 --out results/batch
```

`run.js` options: `--runSeed --castSeed --n --days --hamletSize --pSecond --tableDir --tablesMode csv|shuffled|random --loopOff --traitsOff --skipValidation --logDecisions false --seeds a-b --out dir`.
It prints the state hash, log hash, missingRows and ms/tick. With `--out` it writes `summary.json`, `snapshots.json`, `decisions.csv` and `events.csv` (the logs are only written when decision logging is on). With `--seeds` it writes one folder per seed plus `final_metrics.csv`.

## Files

| File | Purpose |
| --- | --- |
| `engine.js` | Engine (`Village` class), vocabulary, table definitions, loader and validator, RNG, cast generator. |
| `sha256.js` | Pure-JS SHA-256 over UTF-8. |
| `gen_rule_tables.js` | Rule baseline (A6.1) → `tables/rules/*.csv`. |
| `gen_cast.js` | `cast/cast_s1_n20.csv`. |
| `run.js` | CLI batch runner. Also exports `loadTableDir` and `runOnce`. |
| `test.js` | Acceptance tests A15.1–11 (plus test 0, a SHA-256 known-answer check). |
| `build_viewer.js` / `viewer.html` | Self-contained viewer. |
| `results/A`…`results/I` | Outputs of the R0 reference runs. |

## File formats

- **Tables:** `tables/<set>/T*_*.csv`, headers exactly as in A6.0b. They are written in normalised form: header, then rows sorted by key (`|`-joined inputs, UTF-16 order), with `\n` after every line. Table hash = SHA-256 of that normalised text.
- **Cast:** `id,warmth,sociability,diligence,honesty,pride,flexibility,trust_pole,trust_tier,worth_pole,worth_tier,effort_pole,effort_tier`. Pole columns hold the full belief text (e.g. `people are against me`).
- **Decision log:** `tick,npc,table,key,output,choice` (A12). Log hash = SHA-256 of the header plus all lines, each followed by `\n`.
- **Event log:** `tick,room,initiator,receiver,act,event,meaning,pressure,likingChange`. For an apology, act = `apologise`. For a night work outcome, tick = `night<day>`, room / initiator / act / likingChange = `-`. `likingChange` is the table's output, before grudge modifiers.
- **summary.json:** `config`, `castHash`, `tableHashes` (the tables as loaded), `effectiveTableHashes` (only for shuffled/random: the tables after the transform), `missingRows` (count), `missingKeys` (`table:key` → count), `stateHash`, `logHash`, `dailyMetrics`, `timing`.
- **dailyMetrics[d]:** `events` (counts including night work outcomes), `moods` (end of hour 15), `positions[pair]` = counts at positions `[-3,-2,-1,+1,+2,+3]` after the night, `moves` (up/down/flip/break), `friendships`, `feuds`, `isolates`.
- **snapshots.json:** per day, per NPC: `positions` (trust, worth, effort), `eff` (warmth, sociability, diligence, pride) after the night, `mood` at the end of hour 15, plus the list of `moves` applied.

## Golden hashes (from `test.js`)

| Run | State hash | Log hash |
| --- | --- | --- |
| runSeed 1, n 20, days 30, rule tables | `f64386a9c686111ad2818b5dd48412efa7f727864a2721ec5d2c843475a76d75` | `7b862fb6ba29eccacde6d9a18f4b835e52267a73b863698cb0c26eaa218d48d9` |
| runSeed 1, n 5, days 3, rule tables | `7ae5d3c79d87a1d26ec9cb79851774a5df533b2d5ee32ac6b3818f9f2b06fa1c` | `40733d27d403624584d42e743542331d1b15eadd4b6abc1e4b7dffe7bc96b204` |

Cast hash (`cast_s1_n20.csv`): `89d3b47eff3c1ef57122b363aaad969fa0c7fc348367821a3572782801da885b`

## Builder decisions

1. **Step-wise ticks.** Each numbered step of A10 and A11 runs over all NPCs (id ascending) before the next step starts. Lookups are logged in exactly that order, at the moment they happen.
2. **Draws.** A `room` draw is consumed only when T2 is actually looked up (not for `eat now` / `rest now`). An `act` draw is consumed only when T4 is looked up (not when an apology replaces the act). The `meet` stream does the Fisher–Yates shuffle of a room, then one `draw(2)` per pair as each pair is processed. The two-option rule is `draw(100) < pSecond` → `second`.
3. **Cast.** The engine generates the cast from `castSeed` for any n. The first n rows are identical to `cast_s1_n20.csv`, and the cast hash is the hash of the CSV for exactly those n rows (so the n = 5 cast hash covers 5 rows). The viewer passes the shipped CSV for n ≤ 20. Pole columns hold the full belief text.
4. **Liking change (A10.6).** Resolved in this order, using R's grudge toward I *before* this event updates it. (a) Grudge `cool off` and change `same` or `up` → −1. (b) Otherwise `up` → +1, or 0 under `hold grudge` / `pay back`. (c) `down` → −1. (d) `same` → 0. The counter only changes, and the counter rule (A10.7) only runs, when the delta is not 0. The rule runs immediately.
5. **Offence and apology bullets** run in the order listed. If an `apologised to` event gets a `slight` / `insult` meaning (impossible under the rule tables), the offence is first set to that meaning, then resolved by the apology bullet.
6. **Worked beside** is set for every field encounter, including ones that turn into an apology.
7. **Pay back:** stance `hostile` with no T3 lookup (so nothing is logged for T3). T4 is still looked up and logged.
8. **Night work outcomes** use T8 and T9, are logged with tick `night<day>` (day 0-based), and do not set `gotEvent`, which is reset at the next tick anyway.
9. **Moves "applied"** (snapshot list and `moves` metric) = moves that changed the belief. Lookups that return `stay`, or a move that doesn't apply (A7), are not counted. All T11 lookups are still logged.
10. **Initial compile** runs even with `loopOff`. `loopOff` skips night steps 2 and 3 only (so buffers stay empty).
11. **traitsOff** sets all six temperament traits, including honesty and flexibility, to `mid`.
12. **Validation** enforces the full A3 pressure constraint: at `core` only `same` / `strained`; at `faint` / `held` only `stronger` / `same` / `weaker`. This is slightly stricter than the A6.0 wording (it also rejects `weaker` at core). It also rejects a bad header, wrong column counts, duplicates, missing or extra rows, out-of-vocabulary values and T4 acts not allowed in the row's room.
13. **missingRows** = the total number of lookups that fell back to a default. `missingKeys` gives the count per key. The T9 default is the current mood.
14. **Table hashes.** `tableHashes` are the hashes of the loaded CSVs (normalised). For `shuffled` / `random` the summary also gives `effectiveTableHashes` after the transform.
15. **Metrics.** Friendships and feuds are counted per unordered pair. Isolate = NPC with no `like` / `close` toward anyone and none toward it. Daily event counts include night work outcomes and apologies.
16. **logDecisions false** also turns off the event log. The log hash is then `-`.
17. **Timing** is `performance.now()` around each tick (the night is included in the hour-15 tick). `msPerTick` = total / waking ticks. It is never used in decisions.
18. **Starving-run tracking** (for test 8) counts consecutive waking ticks in which the food tier at the needs step is `starving`. It is instrumentation only and not part of the state.
19. **Test choices.** Test 4 changes T4 `neutral|square|mid` to `argue/argue` and compares day-0 encounters (tick, room, initiator, receiver). Test 7 deletes T3 `low|neutral|calm` (rule output `cold`, so the default `neutral` is visibly different). Test 8 checks runSeeds 1–5. Test 5 compares the last day's positions with both the starting positions and the day-0 snapshot.
20. **Viewer.** The n selector also offers 100 / 1000 / 10000. Decision logging is off in the viewer above n = 1000. Hashes are computed on Run or with "Compute hashes".

## R1: teacher fills and consensus

`node analyze_r1.js` imports `teacher_replies/*.txt` (unedited) into `tables/<fill>/`. T1 and T11 are copied from `tables/rules`. It builds `tables/consensus/` and writes `results/R1/report.md` plus `results/R1/lookups.json`. The engine is unchanged; the golden hashes above still pass.

R1 decisions:
- **Row parsing.** Data rows are recognised by a `T<n>-<nn>` id; headers, blank lines and code fences are ignored. The row's input values (after clean-up) give the key. The row id is checked against the grid position as a sanity check only.
- **Clean-up.** Only the permitted clean-up is applied, cell by cell, and each changed cell is logged.
- **Consensus ties.** When there is no rule value among the tied values, the tie goes to A3 order. For T4 that is the row's room list (field: help, chat, take credit, argue; square: chat, praise, share food, interrupt, ignore, argue).
- **Majority** = the value with the highest count; a tie is any equal top count, including 3–3–2.
- **Noise vs temperament.** A self-consistent arm is one where run 1 equals run 2. "Temperament" = at least two distinct values among the self-consistent arms. "Stable" = all 8 values equal. "Noise" = everything else.
- **Usage weights.** These come from the decision logs of 20 consensus runs (seeds 1–20, n 20, 30 days). Rows never looked up have weight 0. The "differs" shares use weighted cells over the ten teacher tables only.
- **Table shares of look-ups.** All twelve tables are included, including T1 and T11.
