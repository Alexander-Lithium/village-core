// R5: are table answers as believable as a live AI's?
//   node analyze_r5.js   → results/R5/report.md, summary.json, moments_table.csv
// Inputs (unchanged copies of the attachments) in inputs/R5/.
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { Village, DEFAULT_CONFIG, TABLE_DEFS } from './engine.js';
import { loadTableDir } from './run.js';

const here = dirname(fileURLToPath(import.meta.url));
const IN = join(here, 'inputs', 'R5');
const OUT = join(here, 'results', 'R5');
mkdirSync(OUT, { recursive: true });
const lines = [];
const P = (...l) => { for (const x of l) { lines.push(x); console.log(x); } };

// ---------------------------------------------------------------- CSV parsing (quoted fields, embedded newlines)
function parseCsv(text) {
  const rows = []; let row = [], cell = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) {
      if (ch === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; }
      else cell += ch;
    } else if (ch === '"') q = true;
    else if (ch === ',') { row.push(cell); cell = ''; }
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') i++;
      row.push(cell); cell = '';
      if (row.length > 1 || row[0] !== '') rows.push(row);
      row = [];
    } else cell += ch;
  }
  if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
  const [h, ...data] = rows;
  return data.map(r => Object.fromEntries(h.map((k, i) => [k.trim(), (r[i] ?? '').trim()])));
}
const moments = parseCsv(readFileSync(join(IN, 'moments.csv'), 'utf8'));
const live = {
  opus: Object.fromEntries(parseCsv(readFileSync(join(IN, 'live_answers_opus55.csv'), 'utf8')).map(r => [r.id, r])),
  gpt6: Object.fromEntries(parseCsv(readFileSync(join(IN, 'live_answers_gpt6.csv'), 'utf8')).map(r => [r.id, r])),
};
if (moments.length !== 40) throw new Error('expected 40 moments, got ' + moments.length);

// ---------------------------------------------------------------- step 1: replay
const tables = loadTableDir('tables/consensus');
const sim = new Village({ ...DEFAULT_CONFIG, runSeed: 101, n: 20, days: 30, tableDir: 'tables/consensus', logDecisions: true }, tables);
sim.run();
const logSet = new Set(sim.decisionLog.slice(1).map(l => { const [t, npc, tid, key] = l.split(','); return `${t},${npc},${tid},${key}`; }));
const found = moments.map(m => logSet.has(`${m.tick},${m.npc},${m.table},${m.key}`));

// ---------------------------------------------------------------- step 2: table answers
function tableMap(dir) {
  const texts = loadTableDir(dir), maps = {};
  for (const tid of ['T2', 'T4', 'T6', 'T7']) {
    const nIn = TABLE_DEFS[tid].inputs.length, names = TABLE_DEFS[tid].outputs.map(o => o[0]);
    const [, ...rows] = texts[tid].trim().split('\n');
    maps[tid] = new Map(rows.map(r => { const c = r.split(','); return [c.slice(0, nIn).join('|'), Object.fromEntries(names.map((n, i) => [n, c[nIn + i]]))]; }));
  }
  return maps;
}
const TM = { tables: tableMap('tables/consensus'), rules: tableMap('tables/rules') };
const SOURCES = ['tables', 'rules', 'opus', 'gpt6'];
const SLABEL = { tables: 'Tables', rules: 'Rules', opus: 'Live Opus 5.5', gpt6: 'Live GPT-6' };
const answers = {}; // answers[id][source] = canonical string
for (const m of moments) {
  const a = {};
  for (const s of ['tables', 'rules']) {
    const row = TM[s][m.table].get(m.key);
    if (!row) throw new Error(`no row ${m.table} ${m.key} in ${s}`);
    a[s] = m.type === 'reaction' ? `${row.meaning}; ${row.liking_change}` : row.first;
  }
  for (const s of ['opus', 'gpt6']) {
    const r = live[s][m.id];
    a[s] = m.type === 'reaction' ? `${r.meaning}; ${r.liking_change}` : r.answer;
  }
  answers[m.id] = a;
}

P('# R5 report', '');
P('## Step 1: are the moments real?', '');
P(`Replay: consensus, seed 101, n 20, 30 days. State \`${sim.stateHash()}\`, log \`${sim.logHash()}\`, missingRows ${sim.missingRows}.`, '');
P('| Type | Moments | Found in decision log |', '| --- | --- | --- |');
for (const t of ['room', 'act', 'reaction']) { const ms = moments.filter(m => m.type === t); P(`| ${t} | ${ms.length} | ${ms.filter(m => found[moments.indexOf(m)]).length} |`); }
P(`| all | 40 | ${found.filter(Boolean).length} |`, '');
const notFound = moments.filter((m, i) => !found[i]).map(m => m.id);
if (notFound.length) P(`Not found: ${notFound.join(', ')}`, '');

P('## Step 2: answers per moment', '');
P('| id | type | table | key | Tables | Rules | Live Opus | Live GPT-6 |', '| --- | --- | --- | --- | --- | --- | --- | --- |');
for (const m of moments) { const a = answers[m.id]; P(`| ${m.id} | ${m.type} | ${m.table} | ${m.key} | ${a.tables} | ${a.rules} | ${a.opus} | ${a.gpt6} |`); }
P('');
writeFileSync(join(OUT, 'moments_table.csv'), 'id,type,table,key,found,tables,rules,opus,gpt6\n' +
  moments.map((m, i) => [m.id, m.type, m.table, m.key, found[i], ...SOURCES.map(s => answers[m.id][s])].map(x => `"${x}"`).join(',')).join('\n') + '\n');

// ---------------------------------------------------------------- step 3: agreement
P('## Step 3: identical answers', '');
const PAIRS_S = [];
for (let i = 0; i < SOURCES.length; i++) for (let j = i + 1; j < SOURCES.length; j++) PAIRS_S.push([SOURCES[i], SOURCES[j]]);
P('| Pair | All (40) | Room (12) | Act (14) | Reaction (14) |', '| --- | --- | --- | --- | --- |');
const agreement = {};
for (const [x, y] of PAIRS_S) {
  const cnt = ms => ms.filter(m => answers[m.id][x] === answers[m.id][y]).length;
  const r = { all: cnt(moments), room: cnt(moments.filter(m => m.type === 'room')), act: cnt(moments.filter(m => m.type === 'act')), reaction: cnt(moments.filter(m => m.type === 'reaction')) };
  agreement[`${x}-${y}`] = r;
  P(`| ${SLABEL[x]} – ${SLABEL[y]} | ${r.all} | ${r.room} | ${r.act} | ${r.reaction} |`);
}
P('');

// ---------------------------------------------------------------- step 4: judging
const prompt = readFileSync(join(IN, 'judge_prompt.md'), 'utf8');
const items = [];
{
  const re = /^\*\*(J\d+)\.\*\* (.*)$/;
  let cur = null;
  for (const line of prompt.split('\n')) {
    const h = line.match(re);
    if (h) { cur = { id: h[1], text: h[2].trim(), options: {} }; items.push(cur); continue; }
    const o = line.match(/^\s+([A-Z])\. (.*)$/);
    if (o && cur) cur.options[o[1]] = o[2].trim();
  }
}
const firstLine = t => t.split('\n')[0].trim();
function optionToAnswer(type, s) {
  let m;
  if (type === 'room' && (m = s.match(/^goes to the (home|field|square)$/))) return m[1];
  if (type === 'act' && (m = s.match(/^chooses to (.+)$/))) return m[1];
  if (type === 'reaction' && (m = s.match(/^takes it as "(.+)"; liking (goes up|stays the same|goes down)$/)))
    return `${m[1]}; ${{ 'goes up': 'up', 'stays the same': 'same', 'goes down': 'down' }[m[2]]}`;
  throw new Error(`cannot parse option "${s}" (${type})`);
}
const itemInfo = items.map(it => {
  const ms = moments.filter(m => firstLine(m.text) === it.text);
  if (ms.length !== 1) throw new Error(`${it.id}: ${ms.length} matching moments`);
  const m = ms[0];
  const opt = Object.fromEntries(Object.entries(it.options).map(([L, s]) => [L, optionToAnswer(m.type, s)]));
  return { item: it.id, moment: m.id, type: m.type, opt };
});

// judges' ratings
function parseRatings(text) {
  const out = {};
  for (const line of text.split('\n')) { const m = line.trim().match(/^(J\d+),([A-Z]),(\d)$/); if (m) out[`${m[1]},${m[2]}`] = +m[3]; }
  return out;
}
const two = readFileSync(join(IN, 'judge_ratings_gpt6_and_gemini_flashlite.txt'), 'utf8');
const split = two.indexOf('Gemini incognito');
if (split < 0) throw new Error('cannot split the two-judge file');
const JUDGES = {
  gpt6: parseRatings(two.slice(0, split)),
  flashlite: parseRatings(two.slice(split)),
  thinking: parseRatings(readFileSync(join(IN, 'judge_ratings_gemini_thinking.txt'), 'utf8')),
};
const JLABEL = { gpt6: 'GPT-6', flashlite: 'Gemini Flash Lite', thinking: 'Gemini thinking' };
const allKeys = itemInfo.flatMap(ii => Object.keys(ii.opt).map(L => `${ii.item},${L}`));
for (const [j, r] of Object.entries(JUDGES)) {
  const missing = allKeys.filter(k => !(k in r)), extra = Object.keys(r).filter(k => !allKeys.includes(k));
  if (missing.length || extra.length) throw new Error(`${j}: missing ${missing} extra ${extra}`);
}

// coverage checks
const disagree = moments.filter(m => new Set(SOURCES.map(s => answers[m.id][s])).size > 1).map(m => m.id);
const judged = itemInfo.map(ii => ii.moment);
const optionSetMatches = itemInfo.filter(ii => {
  const want = [...new Set(SOURCES.map(s => answers[ii.moment][s]))].sort().join('/');
  return [...new Set(Object.values(ii.opt))].sort().join('/') === want;
}).length;
const sourceMissing = [];
for (const ii of itemInfo) for (const s of SOURCES) if (!Object.values(ii.opt).includes(answers[ii.moment][s])) sourceMissing.push(`${ii.item}:${s}`);

P('## Step 4: judging', '');
P(`Judge items: ${items.length}, each matched to exactly one moment by its first line. Moments where the four sources do not all agree: ${disagree.length} (${disagree.join(', ')}).`);
P(`Judged moments not in that set: ${judged.filter(x => !disagree.includes(x)).join(', ') || 'none'}. Disagreement moments not judged: ${disagree.filter(x => !judged.includes(x)).join(', ') || 'none'}.`);
P(`Items whose options are exactly the distinct answers of the four sources: ${optionSetMatches}/${items.length}. Source answers with no matching option: ${sourceMissing.join(', ') || 'none'}.`, '');
P('| Item | Moment | Type | Options |', '| --- | --- | --- | --- |');
for (const ii of itemInfo) {
  const desc = Object.entries(ii.opt).map(([L, a]) => `${L} = ${a} [${SOURCES.filter(s => answers[ii.moment][s] === a).map(s => SLABEL[s]).join(', ') || 'no source'}]`).join('; ');
  P(`| ${ii.item} | ${ii.moment} | ${ii.type} | ${desc} |`);
}
P('');

const rating = (j, ii, s) => {
  const L = Object.keys(ii.opt).find(L => ii.opt[L] === answers[ii.moment][s]);
  return L === undefined ? null : JUDGES[j][`${ii.item},${L}`];
};
const mean = a => a.reduce((x, y) => x + y, 0) / a.length;
const JCOLS = [['gpt6', ['gpt6']], ['flashlite', ['flashlite']], ['thinking', ['thinking']], ['gemini both', ['flashlite', 'thinking']]];
const jl = name => JLABEL[name] ?? 'Both Gemini judges';

P(`### Mean believability of each source's answer (${itemInfo.length} judged moments)`, '');
P('| Source | ' + JCOLS.map(([n]) => jl(n)).join(' | ') + ' |', '|' + ' --- |'.repeat(JCOLS.length + 1));
const means = {};
for (const s of SOURCES) {
  means[s] = {};
  const cells = JCOLS.map(([n, js]) => {
    const v = js.flatMap(j => itemInfo.map(ii => rating(j, ii, s))).filter(x => x !== null);
    const nm = itemInfo.filter(ii => rating(js[0], ii, s) !== null).length;
    means[s][n] = { mean: mean(v), moments: nm }; return mean(v).toFixed(2) + (nm !== itemInfo.length ? ` (n=${nm})` : '');
  });
  P(`| ${SLABEL[s]} | ${cells.join(' | ')} |`);
}
P('');
for (const t of ['room', 'act', 'reaction']) {
  const sub = itemInfo.filter(ii => ii.type === t);
  P(`By type: ${t} (${sub.length} judged moments)`, '');
  P('| Source | ' + JCOLS.map(([n]) => jl(n)).join(' | ') + ' |', '|' + ' --- |'.repeat(JCOLS.length + 1));
  for (const s of SOURCES) P(`| ${SLABEL[s]} | ` + JCOLS.map(([, js]) => { const v = js.flatMap(j => sub.map(ii => rating(j, ii, s))).filter(x => x !== null); const nm = sub.filter(ii => rating(js[0], ii, s) !== null).length; return mean(v).toFixed(2) + (nm !== sub.length ? ` (n=${nm})` : ''); }).join(' | ') + ' |');
  P('');
}

P('(n=17: the rules answer for Q21 (J08), `chat`, is not among the judge options, so rules is averaged over the other 17 judged moments.)', '');
P('### Head to head against the table answer', '', 'Over the judged moments where the source\'s answer differs from the table answer: the source\'s option was rated higher / the same / lower than the table\'s option.', '');
P('| Source | Moments differing | ' + Object.keys(JUDGES).map(j => JLABEL[j]).join(' | ') + ' |', '|' + ' --- |'.repeat(Object.keys(JUDGES).length + 2));
const h2h = {};
for (const s of ['rules', 'opus', 'gpt6']) {
  const diffAll = itemInfo.filter(ii => answers[ii.moment][s] !== answers[ii.moment].tables);
  const diff = diffAll.filter(ii => rating('gpt6', ii, s) !== null && rating('gpt6', ii, 'tables') !== null);
  h2h[s] = { moments: diff.map(ii => ii.moment), unrated: diffAll.filter(ii => !diff.includes(ii)).map(ii => ii.moment) };
  const cells = Object.keys(JUDGES).map(j => {
    let hi = 0, same = 0, lo = 0;
    for (const ii of diff) { const a = rating(j, ii, s), b = rating(j, ii, 'tables'); if (a > b) hi++; else if (a === b) same++; else lo++; }
    h2h[s][j] = { higher: hi, same, lower: lo }; return `${hi} / ${same} / ${lo}`;
  });
  P(`| ${SLABEL[s]} | ${diff.length}${h2h[s].unrated.length ? ` (+${h2h[s].unrated.length} with no rated option: ${h2h[s].unrated.join(', ')})` : ''} | ${cells.join(' | ')} |`);
}
const notJudgedDiff = {};
for (const s of ['rules', 'opus', 'gpt6']) notJudgedDiff[s] = moments.filter(m => answers[m.id][s] !== answers[m.id].tables && !judged.includes(m.id)).length;
P('', `Moments where the source differs from the tables but which were not judged: rules ${notJudgedDiff.rules}, Opus ${notJudgedDiff.opus}, GPT-6 ${notJudgedDiff.gpt6}.`, '');

P(`### Correlation between judges (Pearson, ${allKeys.length} rated options)`, '');
const pear = (x, y) => { const mx = mean(x), my = mean(y); let sxy = 0, sxx = 0, syy = 0; for (let i = 0; i < x.length; i++) { sxy += (x[i] - mx) * (y[i] - my); sxx += (x[i] - mx) ** 2; syy += (y[i] - my) ** 2; } return sxy / Math.sqrt(sxx * syy); };
P('| Pair | r |', '| --- | --- |');
const corr = {};
const jk = Object.keys(JUDGES);
for (let i = 0; i < jk.length; i++) for (let k = i + 1; k < jk.length; k++) {
  const r = pear(allKeys.map(x => JUDGES[jk[i]][x]), allKeys.map(x => JUDGES[jk[k]][x]));
  corr[`${jk[i]}-${jk[k]}`] = r; P(`| ${JLABEL[jk[i]]} – ${JLABEL[jk[k]]} | ${r.toFixed(3)} |`);
}
P('');
writeFileSync(join(OUT, 'report.md'), lines.join('\n') + '\n');
writeFileSync(join(OUT, 'summary.json'), JSON.stringify({ found: found.filter(Boolean).length, notFound, answers, agreement, items: itemInfo, disagree, means, h2h, corr }, null, 1));
