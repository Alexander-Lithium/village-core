# R5 report

## Step 1: are the moments real?

Replay: consensus, seed 101, n 20, 30 days. State `cf14cf19ee6c6c7172eecb2654eca4f58e656030886419b7e0980862428c7f52`, log `ba7733d77cd7304ebcbeae27a4ad941078fe1b92865c80d416723f8086b02800`, missingRows 0.

| Type | Moments | Found in decision log |
| --- | --- | --- |
| room | 12 | 12 |
| act | 14 | 14 |
| reaction | 14 | 14 |
| all | 40 | 40 |

## Step 2: answers per moment

| id | type | table | key | Tables | Rules | Live Opus | Live GPT-6 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Q01 | room | T2 | none|mid|high | square | square | field | square |
| Q02 | room | T2 | none|low|mid | square | square | square | home |
| Q03 | room | T2 | none|high|mid | field | field | field | field |
| Q04 | room | T2 | none|low|high | square | square | square | square |
| Q05 | room | T2 | eat|low|high | home | home | home | home |
| Q06 | room | T2 | rest|high|high | home | home | home | home |
| Q07 | room | T2 | none|high|high | field | field | field | field |
| Q08 | room | T2 | rest|high|mid | home | home | home | home |
| Q09 | room | T2 | none|low|low | home | field | home | home |
| Q10 | room | T2 | none|mid|mid | field | field | field | field |
| Q11 | room | T2 | eat|high|mid | home | home | home | home |
| Q12 | room | T2 | eat|low|low | home | home | home | home |
| Q13 | act | T4 | friendly|field|low | help | help | help | help |
| Q14 | act | T4 | friendly|square|high | chat | praise | chat | chat |
| Q15 | act | T4 | friendly|square|low | chat | praise | chat | praise |
| Q16 | act | T4 | friendly|square|mid | chat | praise | chat | chat |
| Q17 | act | T4 | friendly|field|mid | help | help | help | help |
| Q18 | act | T4 | neutral|field|high | help | chat | help | chat |
| Q19 | act | T4 | friendly|field|high | help | help | help | help |
| Q20 | act | T4 | neutral|field|mid | chat | chat | chat | help |
| Q21 | act | T4 | cold|field|low | take credit | chat | take credit | help |
| Q22 | act | T4 | neutral|field|low | chat | chat | chat | argue |
| Q23 | act | T4 | neutral|square|low | chat | chat | chat | chat |
| Q24 | act | T4 | cold|field|high | chat | chat | chat | chat |
| Q25 | act | T4 | neutral|square|high | chat | chat | chat | chat |
| Q26 | act | T4 | hostile|field|low | take credit | argue | take credit | take credit |
| Q27 | reaction | T7 | praised|i am overlooked|faint|high | good sign; up | good sign; up | good sign; up | good sign; up |
| Q28 | reaction | T7 | praised|i am overlooked|held|low | good sign; up | nothing much; same | good sign; up | good sign; up |
| Q29 | reaction | T6 | helped|people mean well|held | good sign; up | good sign; up | good sign; up | good sign; up |
| Q30 | reaction | T6 | helped|people mean well|core | good sign; up | good sign; up | good sign; up | good sign; up |
| Q31 | reaction | T7 | praised|i am respected|core|mid | good sign; up | good sign; up | good sign; up | good sign; same |
| Q32 | reaction | T7 | credit taken|i am overlooked|held|low | slight; down | slight; down | slight; down | insult; down |
| Q33 | reaction | T6 | helped|people are against me|faint | good sign; up | good sign; up | good sign; up | slight; same |
| Q34 | reaction | T7 | credit taken|i am overlooked|faint|mid | insult; down | slight; down | insult; down | insult; down |
| Q35 | reaction | T6 | shared food with|people mean well|held | good sign; up | good sign; up | good sign; up | good sign; up |
| Q36 | reaction | T7 | ignored|i am respected|core|high | insult; down | insult; down | slight; down | insult; down |
| Q37 | reaction | T6 | argued with|people mean well|held | slight; down | slight; down | slight; down | insult; down |
| Q38 | reaction | T6 | argued with|people mean well|core | slight; down | slight; down | slight; down | insult; down |
| Q39 | reaction | T6 | apologised to|people mean well|core | good sign; up | good sign; up | good sign; up | good sign; up |
| Q40 | reaction | T6 | shared food with|people mean well|core | good sign; up | good sign; up | good sign; up | good sign; up |

## Step 3: identical answers

| Pair | All (40) | Room (12) | Act (14) | Reaction (14) |
| --- | --- | --- | --- | --- |
| Tables – Rules | 31 | 11 | 8 | 12 |
| Tables – Live Opus 5.5 | 38 | 11 | 14 | 13 |
| Tables – Live GPT-6 | 29 | 11 | 9 | 9 |
| Rules – Live Opus 5.5 | 29 | 10 | 8 | 11 |
| Rules – Live GPT-6 | 25 | 10 | 8 | 7 |
| Live Opus 5.5 – Live GPT-6 | 27 | 10 | 9 | 8 |

## Step 4: judging

Judge items: 18, each matched to exactly one moment by its first line. Moments where the four sources do not all agree: 19 (Q01, Q02, Q09, Q14, Q15, Q16, Q18, Q20, Q21, Q22, Q26, Q28, Q31, Q32, Q33, Q34, Q36, Q37, Q38).
Judged moments not in that set: Q13. Disagreement moments not judged: Q14, Q16.
Items whose options are exactly the distinct answers of the four sources: 16/18. Source answers with no matching option: J08:rules.

| Item | Moment | Type | Options |
| --- | --- | --- | --- |
| J01 | Q01 | room | A = square [Tables, Rules, Live GPT-6]; B = field [Live Opus 5.5] |
| J02 | Q02 | room | A = square [Tables, Rules, Live Opus 5.5]; B = home [Live GPT-6] |
| J03 | Q09 | room | A = home [Tables, Live Opus 5.5, Live GPT-6]; B = field [Rules] |
| J04 | Q13 | act | A = chat [no source]; B = help [Tables, Rules, Live Opus 5.5, Live GPT-6] |
| J05 | Q15 | act | A = praise [Rules, Live GPT-6]; B = chat [Tables, Live Opus 5.5] |
| J06 | Q18 | act | A = help [Tables, Live Opus 5.5]; B = chat [Rules, Live GPT-6] |
| J07 | Q20 | act | A = chat [Tables, Rules, Live Opus 5.5]; B = help [Live GPT-6] |
| J08 | Q21 | act | A = help [Live GPT-6]; B = argue [no source]; C = take credit [Tables, Live Opus 5.5] |
| J09 | Q22 | act | A = argue [Live GPT-6]; B = chat [Tables, Rules, Live Opus 5.5] |
| J10 | Q26 | act | A = argue [Rules]; B = take credit [Tables, Live Opus 5.5, Live GPT-6] |
| J11 | Q28 | reaction | A = nothing much; same [Rules]; B = good sign; up [Tables, Live Opus 5.5, Live GPT-6] |
| J12 | Q31 | reaction | A = good sign; up [Tables, Rules, Live Opus 5.5]; B = good sign; same [Live GPT-6] |
| J13 | Q32 | reaction | A = slight; down [Tables, Rules, Live Opus 5.5]; B = insult; down [Live GPT-6] |
| J14 | Q33 | reaction | A = good sign; up [Tables, Rules, Live Opus 5.5]; B = slight; same [Live GPT-6] |
| J15 | Q34 | reaction | A = slight; down [Rules]; B = insult; down [Tables, Live Opus 5.5, Live GPT-6] |
| J16 | Q36 | reaction | A = insult; down [Tables, Rules, Live GPT-6]; B = slight; down [Live Opus 5.5] |
| J17 | Q37 | reaction | A = slight; down [Tables, Rules, Live Opus 5.5]; B = insult; down [Live GPT-6] |
| J18 | Q38 | reaction | A = slight; down [Tables, Rules, Live Opus 5.5]; B = insult; down [Live GPT-6] |

### Mean believability of each source's answer (18 judged moments)

| Source | GPT-6 | Gemini Flash Lite | Gemini thinking | Both Gemini judges |
| --- | --- | --- | --- | --- |
| Tables | 3.56 | 3.94 | 3.94 | 3.94 |
| Rules | 3.41 (n=17) | 3.41 (n=17) | 3.29 (n=17) | 3.35 (n=17) |
| Live Opus 5.5 | 3.33 | 3.78 | 3.83 | 3.81 |
| Live GPT-6 | 4.39 | 3.83 | 3.83 | 3.83 |

By type: room (3 judged moments)

| Source | GPT-6 | Gemini Flash Lite | Gemini thinking | Both Gemini judges |
| --- | --- | --- | --- | --- |
| Tables | 4.00 | 3.67 | 4.00 | 3.83 |
| Rules | 3.33 | 3.00 | 3.00 | 3.00 |
| Live Opus 5.5 | 3.33 | 3.33 | 3.67 | 3.50 |
| Live GPT-6 | 4.33 | 4.00 | 4.33 | 4.17 |

By type: act (7 judged moments)

| Source | GPT-6 | Gemini Flash Lite | Gemini thinking | Both Gemini judges |
| --- | --- | --- | --- | --- |
| Tables | 3.14 | 3.86 | 4.14 | 4.00 |
| Rules | 3.83 (n=6) | 3.67 (n=6) | 3.83 (n=6) | 3.75 (n=6) |
| Live Opus 5.5 | 3.14 | 3.86 | 4.14 | 4.00 |
| Live GPT-6 | 3.86 | 3.71 | 3.29 | 3.50 |

By type: reaction (8 judged moments)

| Source | GPT-6 | Gemini Flash Lite | Gemini thinking | Both Gemini judges |
| --- | --- | --- | --- | --- |
| Tables | 3.75 | 4.13 | 3.75 | 3.94 |
| Rules | 3.13 | 3.38 | 3.00 | 3.19 |
| Live Opus 5.5 | 3.50 | 3.88 | 3.63 | 3.75 |
| Live GPT-6 | 4.88 | 3.88 | 4.13 | 4.00 |

(n=17: the rules answer for Q21 (J08), `chat`, is not among the judge options, so rules is averaged over the other 17 judged moments.)

### Head to head against the table answer

Over the judged moments where the source's answer differs from the table answer: the source's option was rated higher / the same / lower than the table's option.

| Source | Moments differing | GPT-6 | Gemini Flash Lite | Gemini thinking |
| --- | --- | --- | --- | --- |
| Rules | 6 (+1 with no rated option: Q21) | 2 / 0 / 4 | 0 / 2 / 4 | 0 / 1 / 5 |
| Live Opus 5.5 | 2 | 0 / 0 / 2 | 0 / 0 / 2 | 0 / 0 / 2 |
| Live GPT-6 | 11 | 10 / 0 / 1 | 4 / 2 / 5 | 3 / 3 / 5 |

Moments where the source differs from the tables but which were not judged: rules 2, Opus 0, GPT-6 0.

### Correlation between judges (Pearson, 37 rated options)

| Pair | r |
| --- | --- |
| GPT-6 – Gemini Flash Lite | 0.388 |
| GPT-6 – Gemini thinking | 0.391 |
| Gemini Flash Lite – Gemini thinking | 0.768 |

