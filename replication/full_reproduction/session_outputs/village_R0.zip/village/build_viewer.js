// Inlines engine.js, sha256.js and every CSV in tables/ and cast/ into a self-contained viewer.html (A14).
import { readFileSync, writeFileSync, readdirSync, statSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const stripModule = src => src
  .replace(/^import .*$/gm, '')
  .replace(/^export (const|function|class|let) /gm, '$1 ');

const tableSets = {};
for (const d of readdirSync(join(here, 'tables'))) {
  const p = join(here, 'tables', d);
  if (!statSync(p).isDirectory()) continue;
  tableSets[d] = {};
  for (const f of readdirSync(p).filter(f => f.endsWith('.csv')).sort()) tableSets[d][f] = readFileSync(join(p, f), 'utf8');
}
const casts = {};
for (const f of readdirSync(join(here, 'cast')).filter(f => f.endsWith('.csv')).sort()) casts[f] = readFileSync(join(here, 'cast', f), 'utf8');

const code = stripModule(readFileSync(join(here, 'sha256.js'), 'utf8')) + '\n' + stripModule(readFileSync(join(here, 'engine.js'), 'utf8'));
const data = JSON.stringify({ tableSets, casts }).replace(/</g, '\\u003c');

const html = `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><title>Village Core v1.0 viewer</title>
<style>
body{font:13px/1.4 system-ui,sans-serif;margin:0;background:#f6f5f2;color:#222}
header{padding:8px 12px;background:#fff;border-bottom:1px solid #ddd;display:flex;flex-wrap:wrap;gap:10px;align-items:center}
header label{display:flex;gap:4px;align-items:center}
input[type=number]{width:64px}
button{padding:3px 10px}
main{display:grid;grid-template-columns:1fr 360px;gap:10px;padding:10px}
.hamlet{margin-bottom:8px}.hamlet h4{margin:4px 0}
.rooms{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}
.room{background:#fff;border:1px solid #ddd;border-radius:6px;padding:6px;min-height:60px}
.room b{display:block;margin-bottom:4px;text-transform:capitalize}
.dot{display:inline-block;margin:2px;padding:1px 5px;border-radius:9px;font-size:11px;cursor:pointer;border:1px solid #999}
.dot.low{background:#f3d0cc}.dot.calm{background:#e8e8e8}.dot.good{background:#cdebd2}.dot.sel{outline:2px solid #2a62c9}
.panel{background:#fff;border:1px solid #ddd;border-radius:6px;padding:8px;margin-bottom:10px}
.panel h3{margin:0 0 6px;font-size:14px}
pre{white-space:pre-wrap;word-break:break-all;font-size:11px;margin:0}
table.kv td{padding:0 6px 0 0;vertical-align:top}
canvas{width:100%;height:120px;background:#fff;border:1px solid #eee;margin-bottom:4px}
#status{font-weight:600}
</style></head><body>
<header>
 <label>run seed <input id="runSeed" type="number" value="1"></label>
 <label>n <select id="n"><option>5</option><option selected>20</option><option>100</option><option>1000</option><option>10000</option></select></label>
 <label>days <input id="days" type="number" value="30"></label>
 <label>table set <select id="tableSet"></select></label>
 <label><input id="loopOff" type="checkbox">loopOff</label>
 <label><input id="traitsOff" type="checkbox">traitsOff</label>
 <label>tablesMode <select id="tablesMode"><option>csv</option><option>shuffled</option><option>random</option></select></label>
 <button id="run">Run</button><button id="step">Step</button><button id="play">Play</button>
 <span id="status"></span>
</header>
<main>
 <div><div id="rooms"></div>
  <div class="panel"><h3>Belief positions by day (thick = mean)</h3><canvas id="c_trust"></canvas><canvas id="c_worth"></canvas><canvas id="c_effort"></canvas></div>
 </div>
 <div>
  <div class="panel"><h3>Selected NPC</h3><div id="npc">Click a dot.</div></div>
  <div class="panel"><h3>Summary</h3><pre id="summary"></pre>
   <button id="hash">Compute hashes</button> <button id="dlSummary">Summary JSON</button> <button id="dlLog">Decision log</button> <button id="dlEvents">Event log</button></div>
 </div>
</main>
<script>
${code}
const DATA = ${data};
const $ = id => document.getElementById(id);
for (const k of Object.keys(DATA.tableSets)) $('tableSet').append(new Option(k, k, k === 'rules', k === 'rules'));
let sim = null, selected = null, timer = null, hashes = null;
function cfg() {
  return { ...DEFAULT_CONFIG, runSeed: +$('runSeed').value, n: +$('n').value, days: +$('days').value,
    tableDir: 'tables/' + $('tableSet').value, loopOff: $('loopOff').checked, traitsOff: $('traitsOff').checked,
    tablesMode: $('tablesMode').value, logDecisions: +$('n').value <= 1000 };
}
function newSim() {
  const set = DATA.tableSets[$('tableSet').value];
  const texts = {}; for (const t of TABLE_IDS) texts[t] = set[TABLE_DEFS[t].file];
  const c = cfg();
  const castFile = 'cast_s' + c.castSeed + '_n20.csv';
  sim = new Village(c, texts, c.n <= 20 && DATA.casts[castFile] ? DATA.casts[castFile] : null);
  hashes = null; selected = null;
}
const done = () => sim && sim.ticksRun >= sim.config.days * 16;
function stepOnce() { if (!sim) newSim(); if (!done()) sim.tick(); hashes = null; }
function render() {
  if (!sim) return;
  $('status').textContent = 'day ' + sim.day + ' hour ' + sim.hour + (done() ? ' (finished)' : '');
  const big = sim.npcs.length >= 1000;
  const rooms = $('rooms'); rooms.innerHTML = '';
  if (!big) for (let h = 0; h < sim.hamlets.length; h++) {
    const div = document.createElement('div'); div.className = 'hamlet';
    div.innerHTML = '<h4>Hamlet ' + (h + 1) + '</h4>';
    const grid = document.createElement('div'); grid.className = 'rooms';
    for (const r of ROOMS) {
      const box = document.createElement('div'); box.className = 'room'; box.innerHTML = '<b>' + r + '</b>';
      for (const n of sim.hamlets[h]) if (n.room === r) {
        const d = document.createElement('span'); d.className = 'dot ' + n.mood + (selected === n ? ' sel' : '');
        d.textContent = n.id; d.title = 'food ' + n.food + ', energy ' + n.energy + ', mood ' + n.mood;
        d.onclick = () => { selected = n; render(); }; box.append(d);
      }
      grid.append(box);
    }
    div.append(grid); rooms.append(div);
  } else rooms.innerHTML = '<div class="panel">n = ' + sim.npcs.length + ': dots hidden; metrics and timing only.</div>';
  renderNpc(); renderCharts(); renderSummary();
}
function renderNpc() {
  const n = selected; if (!n) { $('npc').textContent = 'Click a dot.'; return; }
  const rows = [
    ['temperament', TRAITS.map(t => t + ' ' + n.temperament[t]).join(', ')],
    ['effective', COMPILED_TRAITS.map(t => t + ' ' + n.eff[t]).join(', ')],
    ['beliefs', PAIRS.map(p => POLES[p][n.beliefs[p].pole] + ' (' + n.beliefs[p].tier + ')').join('; ')],
    ['mood', n.mood], ['body', 'food ' + n.food + ', energy ' + n.energy + ', room ' + n.room],
    ['liking', n.relOrder.map(o => { const r = n.rel.get(o.num); return o.id + ' ' + r.liking + (r.grudge !== 'none' ? ' [' + r.grudge + ']' : ''); }).join(', ')],
  ];
  let trace = [];
  if (sim.decisionLog) for (let k = sim.decisionLog.length - 1; k > 0 && trace.length < 10; k--) {
    const v = sim.decisionLog[k].split(',');
    if (v[1] === n.id) trace.unshift('[' + v[0] + '] ' + v[3].split('|').join(', ') + ' → ' + v[2] + ' → ' + v[4].split('|').join(', ') + (v[5] !== '-' ? ' (' + v[5] + ')' : ''));
  }
  $('npc').innerHTML = '<b>' + n.id + '</b><table class="kv">' + rows.map(r => '<tr><td>' + r[0] + '</td><td>' + r[1] + '</td></tr>').join('') + '</table><b>Last decisions</b><pre>' + (trace.join('\\n') || '(none)') + '</pre>';
}
function renderCharts() {
  PAIRS.forEach((p, pi) => {
    const cv = $('c_' + p); const W = cv.width = cv.clientWidth * 2, H = cv.height = 240; const g = cv.getContext('2d');
    g.clearRect(0, 0, W, H); g.font = '20px sans-serif'; g.fillStyle = '#333'; g.fillText(p, 8, 22);
    const snaps = sim.snapshots; const nd = Math.max(2, sim.config.days);
    const x = d => 40 + (W - 50) * d / (nd - 1), y = v => H / 2 - v * (H - 30) / 6.5;
    g.strokeStyle = '#ccc'; g.beginPath(); g.moveTo(40, y(0)); g.lineTo(W, y(0)); g.stroke();
    if (!snaps.length) return;
    const showEach = sim.npcs.length <= 100;
    if (showEach) { g.strokeStyle = 'rgba(42,98,201,0.15)'; g.lineWidth = 2;
      for (let i = 0; i < sim.npcs.length; i++) { g.beginPath(); snaps.forEach((s, d) => { const v = s.npcs[i].positions[pi]; d ? g.lineTo(x(d), y(v)) : g.moveTo(x(d), y(v)); }); g.stroke(); } }
    g.strokeStyle = '#2a62c9'; g.lineWidth = 5; g.beginPath();
    snaps.forEach((s, d) => { const m = s.npcs.reduce((a, b) => a + b.positions[pi], 0) / s.npcs.length; d ? g.lineTo(x(d), y(m)) : g.moveTo(x(d), y(m)); });
    g.stroke();
  });
}
function renderSummary() {
  const lines = ['ticks ' + sim.ticksRun + ', missingRows ' + sim.missingRows,
    'ms per tick ' + (sim.totalMs / Math.max(1, sim.ticksRun)).toFixed(3), 'cast hash ' + sim.castHash];
  if (hashes) lines.push('state hash ' + hashes.state, 'log hash   ' + hashes.log);
  const m = sim.metrics[sim.metrics.length - 1];
  if (m) lines.push('day ' + m.day + ': friendships ' + m.friendships + ', feuds ' + m.feuds + ', isolates ' + m.isolates);
  lines.push('table hashes:'); for (const t of TABLE_IDS) lines.push('  ' + t + ' ' + sim.tableHashes[t]);
  $('summary').textContent = lines.join('\\n');
}
function download(name, text) { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text])); a.download = name; a.click(); }
$('run').onclick = () => { stop(); newSim(); while (!done()) sim.tick(); hashes = { state: sim.stateHash(), log: sim.logHash() }; render(); };
$('step').onclick = () => { stop(); stepOnce(); render(); };
function stop() { if (timer) { clearInterval(timer); timer = null; $('play').textContent = 'Play'; } }
$('play').onclick = () => { if (timer) return stop(); if (!sim || done()) newSim(); $('play').textContent = 'Pause';
  timer = setInterval(() => { stepOnce(); render(); if (done()) stop(); }, sim.npcs.length > 100 ? 0 : 60); };
$('hash').onclick = () => { if (sim) { hashes = { state: sim.stateHash(), log: sim.logHash() }; render(); } };
$('dlSummary').onclick = () => sim && download('summary.json', JSON.stringify(sim.summary(), null, 1));
$('dlLog').onclick = () => sim && sim.decisionLog && download('decisions.csv', sim.decisionLogText());
$('dlEvents').onclick = () => sim && sim.eventLog && download('events.csv', sim.eventLogText());
newSim(); render();
</script></body></html>
`;
writeFileSync(join(here, 'viewer.html'), html);
console.log('wrote viewer.html (' + html.length + ' bytes)');
