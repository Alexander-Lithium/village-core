// Village Core v1.0 engine. One ES module, no dependencies besides sha256.js.
// Runs unchanged in Node >= 18 and modern browsers (no fs access here; callers pass CSV text).
import { sha256, utf8Encode } from './sha256.js';

// ---------------------------------------------------------------- A3 vocabulary
export const LEVELS = ['low', 'mid', 'high'];
export const LEVEL_INDEX = { low: -1, mid: 0, high: 1 };
export const TRAITS = ['warmth', 'sociability', 'diligence', 'honesty', 'pride', 'flexibility'];
export const COMPILED_TRAITS = ['warmth', 'sociability', 'diligence', 'pride'];
export const FOOD_TIERS = ['starving', 'very hungry', 'hungry', 'fed'];
export const ENERGY_TIERS = ['exhausted', 'very tired', 'tired', 'rested'];
export const MOODS = ['low', 'calm', 'good'];
export const LIKINGS = ['dislike', 'neutral', 'like', 'close'];
export const PAIRS = ['trust', 'worth', 'effort'];
export const POLES = {
  trust: ['people mean well', 'people are against me'],
  worth: ['i am respected', 'i am overlooked'],
  effort: ['hard work pays off', 'nothing i do matters'],
};
export const BELIEFS6 = [...POLES.trust, ...POLES.worth, ...POLES.effort];
export const TIERS = ['faint', 'held', 'core'];
export const ROOMS = ['home', 'field', 'square'];
export const NEEDS = ['none', 'eat', 'rest', 'eat now', 'rest now'];
export const STANCES = ['friendly', 'neutral', 'cold', 'hostile'];
export const ACTS_BY_ROOM = {
  field: ['help', 'chat', 'take credit', 'argue'],
  square: ['chat', 'praise', 'share food', 'interrupt', 'ignore', 'argue'],
};
export const ALL_ACTS = ['help', 'chat', 'take credit', 'argue', 'praise', 'share food', 'interrupt', 'ignore'];
// Events in A3 table order: [event, pair, valence]
export const EVENTS = [
  ['helped', 'trust', 1], ['chatted with', 'trust', 1], ['shared food with', 'trust', 1],
  ['argued with', 'trust', -1], ['interrupted', 'trust', -1], ['apologised to', 'trust', 1],
  ['praised', 'worth', 1], ['ignored', 'worth', -1], ['credit taken', 'worth', -1],
  ['work went well', 'effort', 1], ['work went badly', 'effort', -1],
];
export const EVENT_PAIR = Object.fromEntries(EVENTS.map(e => [e[0], e[1]]));
export const EVENT_VALENCE = Object.fromEntries(EVENTS.map(e => [e[0], e[2]]));
export const EVENTS_OF_PAIR = p => EVENTS.filter(e => e[1] === p).map(e => e[0]);
export const ACT_EVENT = {
  help: 'helped', chat: 'chatted with', 'share food': 'shared food with', argue: 'argued with',
  interrupt: 'interrupted', praise: 'praised', ignore: 'ignored', 'take credit': 'credit taken',
};
export const NEGATIVE_ACTS = new Set(['argue', 'interrupt', 'ignore', 'take credit']);
export const MEANINGS = ['good sign', 'nothing much', 'slight', 'insult'];
export const PRESSURES = ['stronger', 'same', 'weaker', 'strained'];
export const LIKING_CHANGES = ['up', 'same', 'down'];
export const GRUDGE_RESPONSES = ['let it go', 'cool off', 'hold grudge', 'pay back'];
export const DECISIONS = ['apologise', "don't"];
export const BALANCES = ['mostly against', 'mixed', 'mostly for', 'strongly for'];
export const MOVES = ['stay', 'up', 'down', 'flip', 'break'];
export const STEPS = ['-1', '0', '+1'];
const PAIR_TABLE = { trust: 'T6', worth: 'T7', effort: 'T8' };

// ---------------------------------------------------------------- A6 table definitions
export const TABLE_DEFS = {
  T1: { file: 'T1_needs.csv', type: 'designer', inputs: [['food', FOOD_TIERS], ['energy', ENERGY_TIERS]], outputs: [['need', NEEDS]], def: ['none'] },
  T2: { file: 'T2_action.csv', type: 'teacher', inputs: [['need', ['none', 'eat', 'rest']], ['diligence', LEVELS], ['sociability', LEVELS]], outputs: [['first', ROOMS], ['second', ROOMS]], def: ['home', 'square'] },
  T3: { file: 'T3_stance.csv', type: 'teacher', inputs: [['warmth', LEVELS], ['liking', LIKINGS], ['mood', MOODS]], outputs: [['stance', STANCES]], def: ['neutral'] },
  T4: { file: 'T4_act.csv', type: 'teacher', inputs: [['stance', STANCES], ['room', ['field', 'square']], ['honesty', LEVELS]], outputs: [['first', ALL_ACTS], ['second', ALL_ACTS]], def: ['chat', 'chat'] },
  T5: { file: 'T5_apology.csv', type: 'teacher', inputs: [['honesty', LEVELS], ['pride', LEVELS]], outputs: [['decision', DECISIONS]], def: ["don't"] },
  T6: { file: 'T6_appraise_trust.csv', type: 'teacher', inputs: [['event', EVENTS_OF_PAIR('trust')], ['belief', POLES.trust], ['tier', TIERS]], outputs: [['meaning', MEANINGS], ['pressure', PRESSURES], ['liking_change', LIKING_CHANGES]], def: ['nothing much', 'same', 'same'] },
  T7: { file: 'T7_appraise_worth.csv', type: 'teacher', inputs: [['event', EVENTS_OF_PAIR('worth')], ['belief', POLES.worth], ['tier', TIERS], ['pride', LEVELS]], outputs: [['meaning', MEANINGS], ['pressure', PRESSURES], ['liking_change', LIKING_CHANGES]], def: ['nothing much', 'same', 'same'] },
  T8: { file: 'T8_appraise_effort.csv', type: 'teacher', inputs: [['event', EVENTS_OF_PAIR('effort')], ['belief', POLES.effort], ['tier', TIERS]], outputs: [['meaning', MEANINGS], ['pressure', PRESSURES]], def: ['nothing much', 'same'] },
  T9: { file: 'T9_mood.csv', type: 'teacher', inputs: [['mood', MOODS], ['meaning', MEANINGS]], outputs: [['new_mood', MOODS]], def: null /* current mood */ },
  T10: { file: 'T10_grudge.csv', type: 'teacher', inputs: [['warmth', LEVELS], ['offence', ['slight', 'insult']], ['apology', ['none', 'received']]], outputs: [['response', GRUDGE_RESPONSES]], def: ['cool off'] },
  T11: { file: 'T11_integration.csv', type: 'designer', inputs: [['balance', BALANCES], ['tier', TIERS], ['flexibility', LEVELS]], outputs: [['move', MOVES]], def: ['stay'] },
  T12: { file: 'T12_compile.csv', type: 'teacher', inputs: [['belief', BELIEFS6], ['tier', TIERS]], outputs: [['warmth', STEPS], ['sociability', STEPS], ['diligence', STEPS], ['pride', STEPS]], def: ['0', '0', '0', '0'] },
};
export const TABLE_IDS = ['T1', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'T8', 'T9', 'T10', 'T11', 'T12'];
export const TEACHER_IDS = TABLE_IDS.filter(t => TABLE_DEFS[t].type === 'teacher');

export function headerOf(tid) {
  const d = TABLE_DEFS[tid];
  return [...d.inputs.map(c => c[0]), ...d.outputs.map(c => c[0])].join(',');
}

// Full grid of input combinations, in value order.
export function gridKeys(tid) {
  let combos = [[]];
  for (const [, vals] of TABLE_DEFS[tid].inputs) {
    const next = [];
    for (const c of combos) for (const v of vals) next.push([...c, v]);
    combos = next;
  }
  return combos;
}

// Allowed values for an output column of a given row (A6.0 / A13 random).
export function allowedOutputs(tid, colIndex, inputs) {
  const d = TABLE_DEFS[tid];
  const [name, vals] = d.outputs[colIndex];
  if (tid === 'T4') return ACTS_BY_ROOM[inputs[1]];
  if ((tid === 'T6' || tid === 'T7' || tid === 'T8') && name === 'pressure') {
    return inputs[2] === 'core' ? ['same', 'strained'] : ['stronger', 'same', 'weaker'];
  }
  return vals;
}

// Normalised text (A6.0): header, rows sorted by key (UTF-16 order), each line + '\n'.
export function normaliseTable(tid, map) {
  const keys = [...map.keys()].sort(cmpStr);
  let s = headerOf(tid) + '\n';
  for (const k of keys) s += k.split('|').concat(map.get(k)).join(',') + '\n';
  return s;
}

function cmpStr(a, b) { return a < b ? -1 : a > b ? 1 : 0; }

// Parse a table CSV into rows (arrays of strings).
export function parseCsv(text) {
  const lines = text.split('\n').map(l => (l.endsWith('\r') ? l.slice(0, -1) : l));
  while (lines.length && lines[lines.length - 1] === '') lines.pop();
  return { header: lines[0], rows: lines.slice(1).map(l => l.split(',')) };
}

// Load + validate one table. Returns { map, errors }.
export function loadTable(tid, text) {
  const d = TABLE_DEFS[tid];
  const nIn = d.inputs.length, nOut = d.outputs.length;
  const errors = [];
  const { header, rows } = parseCsv(text);
  if (header !== headerOf(tid)) errors.push(`${tid}: bad header "${header}"`);
  const map = new Map();
  for (const r of rows) {
    if (r.length !== nIn + nOut) { errors.push(`${tid}: wrong column count in row "${r.join(',')}"`); continue; }
    const inputs = r.slice(0, nIn), outputs = r.slice(nIn);
    const key = inputs.join('|');
    if (map.has(key)) errors.push(`${tid}: duplicate row ${key}`);
    map.set(key, outputs);
  }
  // full grid, no extras
  const grid = new Set(gridKeys(tid).map(c => c.join('|')));
  for (const k of grid) if (!map.has(k)) errors.push(`${tid}: missing row ${k}`);
  for (const k of map.keys()) if (!grid.has(k)) errors.push(`${tid}: extra row ${k}`);
  // allowed outputs (incl. T4 room and T6-T8 pressure constraints)
  for (const [k, outs] of map) {
    const inputs = k.split('|');
    outs.forEach((v, i) => {
      if (!d.outputs[i][1].includes(v)) errors.push(`${tid}: illegal ${d.outputs[i][0]} "${v}" in ${k}`);
      else if (grid.has(k) && !allowedOutputs(tid, i, inputs).includes(v)) errors.push(`${tid}: ${d.outputs[i][0]} "${v}" not allowed in ${k}`);
    });
  }
  return { map, errors };
}

// ---------------------------------------------------------------- A8 randomness
export function fnv1a(str) {
  let h = 0x811c9dc5;
  // UTF-8 bytes
  const bytes = utf8Encode(str);
  for (let i = 0; i < bytes.length; i++) { h ^= bytes[i]; h = Math.imul(h, 0x01000193) >>> 0; }
  return h >>> 0;
}
export class Stream {
  constructor(seed) { this.a = seed >>> 0; }
  next() {
    this.a = (this.a + 0x6d2b79f5) >>> 0;
    let t = this.a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return (t ^ (t >>> 14)) >>> 0;
  }
  draw(n) { return this.next() % n; }
  shuffle(arr) {
    for (let i = arr.length - 1; i >= 1; i--) { const j = this.draw(i + 1); const t = arr[i]; arr[i] = arr[j]; arr[j] = t; }
    return arr;
  }
}
export const streamFor = (str) => new Stream(fnv1a(str));

// ---------------------------------------------------------------- A9 cast
export const CAST_HEADER = 'id,warmth,sociability,diligence,honesty,pride,flexibility,trust_pole,trust_tier,worth_pole,worth_tier,effort_pole,effort_tier';
export const npcId = num => 'n' + String(num).padStart(4, '0');

export function generateCast(castSeed, n) {
  const s = streamFor(`cast:${castSeed}`);
  const rows = [];
  for (let num = 1; num <= n; num++) {
    const row = { num, id: npcId(num), temperament: {}, beliefs: {} };
    for (const t of TRAITS) row.temperament[t] = LEVELS[s.draw(3)];
    for (const p of PAIRS) {
      const pole = s.draw(2) === 0 ? 0 : 1;
      const r = s.draw(100);
      row.beliefs[p] = { pole, tier: r < 50 ? 'faint' : r < 85 ? 'held' : 'core' };
    }
    rows.push(row);
  }
  return rows;
}
export function castToCsv(rows) {
  let s = CAST_HEADER + '\n';
  for (const r of rows) {
    s += [r.id, ...TRAITS.map(t => r.temperament[t]),
      ...PAIRS.flatMap(p => [POLES[p][r.beliefs[p].pole], r.beliefs[p].tier])].join(',') + '\n';
  }
  return s;
}
export function parseCastCsv(text) {
  const { header, rows } = parseCsv(text);
  if (header !== CAST_HEADER) throw new Error('bad cast header');
  return rows.map(r => {
    const num = parseInt(r[0].slice(1), 10);
    const o = { num, id: r[0], temperament: {}, beliefs: {} };
    TRAITS.forEach((t, i) => { o.temperament[t] = r[1 + i]; });
    PAIRS.forEach((p, i) => {
      const pole = POLES[p].indexOf(r[7 + 2 * i]);
      if (pole < 0) throw new Error('bad cast belief ' + r[7 + 2 * i]);
      o.beliefs[p] = { pole, tier: r[8 + 2 * i] };
    });
    return o;
  });
}

// ---------------------------------------------------------------- helpers
const foodTier = f => (f <= 15 ? 'starving' : f <= 35 ? 'very hungry' : f <= 60 ? 'hungry' : 'fed');
const energyTier = e => (e <= 15 ? 'exhausted' : e <= 35 ? 'very tired' : e <= 60 ? 'tired' : 'rested');
const towardCalm = () => 'calm'; // one step toward calm from low or good is calm
const clamp = (x, lo, hi) => (x < lo ? lo : x > hi ? hi : x);
export const beliefPosition = b => (b.pole === 0 ? 1 : -1) * (TIERS.indexOf(b.tier) + 1);

export const DEFAULT_CONFIG = {
  runSeed: 1, castSeed: 1, n: 20, days: 30, hamletSize: 20, pSecond: 25,
  tableDir: 'tables/rules', loopOff: false, traitsOff: false, tablesMode: 'csv',
  logDecisions: true, skipValidation: false,
};

// ---------------------------------------------------------------- simulation
export class Village {
  // tableTexts: { T1: csvText, ... }  castCsv: optional cast CSV text (else generated from castSeed)
  constructor(config, tableTexts, castCsv = null) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    const c = this.config;
    // tables
    this.tables = {};
    this.tableHashes = {};
    const errors = [];
    for (const tid of TABLE_IDS) {
      const text = tableTexts[tid];
      if (text == null) { errors.push(`${tid}: missing file`); continue; }
      const { map, errors: e } = loadTable(tid, text);
      errors.push(...e);
      this.tables[tid] = map;
      this.tableHashes[tid] = sha256(normaliseTable(tid, map));
    }
    this.validationErrors = errors;
    if (errors.length && !c.skipValidation) throw new Error('Table validation failed:\n' + errors.join('\n'));
    // streams
    const st = name => streamFor(`${c.runSeed}:${name}`);
    this.rng = { meet: st('meet'), room: st('room'), act: st('act'), work: st('work'), shuffle: st('shuffle'), random: st('random') };
    if (c.tablesMode === 'shuffled') this._shuffleTables();
    else if (c.tablesMode === 'random') this._randomTables();
    else if (c.tablesMode !== 'csv') throw new Error('bad tablesMode ' + c.tablesMode);
    this.effectiveTableHashes = {};
    for (const tid of TABLE_IDS) if (this.tables[tid]) this.effectiveTableHashes[tid] = sha256(normaliseTable(tid, this.tables[tid]));
    // cast
    let castRows = castCsv ? parseCastCsv(castCsv).slice(0, c.n) : generateCast(c.castSeed, c.n);
    if (castRows.length !== c.n) throw new Error('cast has fewer rows than n');
    this.castCsv = castToCsv(castRows);
    this.castHash = sha256(this.castCsv);
    // logs and counters
    this.decisionLog = c.logDecisions ? ['tick,npc,table,key,output,choice'] : null;
    this.eventLog = c.logDecisions ? ['tick,room,initiator,receiver,act,event,meaning,pressure,likingChange'] : null;
    this.encounters = []; // (tick, room, initiator, receiver) for tests/viewer
    this.missingRows = 0;
    this.missingKeys = new Map();
    this.snapshots = [];
    this.metrics = [];
    this.maxStarvingRun = 0;
    this.day = 0; this.hour = 0;
    this.dayEvents = {};
    this.totalMs = 0; this.ticksRun = 0;
    // NPCs
    this.npcs = castRows.map(r => {
      const temperament = { ...r.temperament };
      if (c.traitsOff) for (const t of TRAITS) temperament[t] = 'mid';
      return {
        num: r.num, id: r.id, temperament,
        beliefs: Object.fromEntries(PAIRS.map(p => [p, { ...r.beliefs[p] }])),
        eff: {}, food: 80, energy: 80, mood: 'calm', room: 'home', need: 'none',
        fieldTicksToday: 0, todayPressure: { trust: [], worth: [], effort: [] },
        buffer: { trust: [], worth: [], effort: [] }, gotEvent: false,
        rel: new Map(), relOrder: [], starvingRun: 0,
        hamlet: Math.floor((r.num - 1) / c.hamletSize),
      };
    });
    this.hamlets = [];
    for (const npc of this.npcs) (this.hamlets[npc.hamlet] ||= []).push(npc);
    for (const h of this.hamlets) {
      for (const a of h) for (const b of h) if (a !== b) {
        a.rel.set(b.num, { liking: 'neutral', counter: 0, grudge: 'none', offence: 'none', owesApology: false, workedBesideToday: false });
        a.relOrder.push(b);
      }
    }
    this.byNum = new Map(this.npcs.map(n => [n.num, n]));
    // initial compile
    for (const npc of this.npcs) this._compile(npc, 'start');
    this.initialPositions = this.npcs.map(n => PAIRS.map(p => beliefPosition(n.beliefs[p])));
  }

  // ---- tablesMode transforms (A13)
  _shuffleTables() {
    for (const tid of TEACHER_IDS) {
      const map = this.tables[tid];
      const keys = [...map.keys()].sort(cmpStr);
      const groupOf = k => { const v = k.split('|'); return tid === 'T4' ? v[1] : (tid === 'T6' || tid === 'T7' || tid === 'T8') ? v[2] : ''; };
      const groups = new Map();
      for (const k of keys) { const g = groupOf(k); if (!groups.has(g)) groups.set(g, []); groups.get(g).push(k); }
      for (const gk of groups.values()) {
        const outs = gk.map(k => map.get(k));
        this.rng.shuffle.shuffle(outs);
        gk.forEach((k, i) => map.set(k, outs[i]));
      }
    }
  }
  _randomTables() {
    for (const tid of TEACHER_IDS) {
      const map = this.tables[tid];
      const keys = [...map.keys()].sort(cmpStr);
      for (const k of keys) {
        const inputs = k.split('|');
        const outs = TABLE_DEFS[tid].outputs.map((_, i) => {
          const allowed = allowedOutputs(tid, i, inputs);
          return allowed[this.rng.random.draw(allowed.length)];
        });
        map.set(k, outs);
      }
    }
  }

  // ---- lookup + logging (A5, A12)
  _lookup(tid, inputs, label, npc, choice = '-') {
    const key = inputs.join('|');
    let out = this.tables[tid] && this.tables[tid].get(key);
    if (!out) {
      out = tid === 'T9' ? [inputs[0]] : TABLE_DEFS[tid].def;
      this.missingRows++;
      const mk = tid + ':' + key;
      this.missingKeys.set(mk, (this.missingKeys.get(mk) || 0) + 1);
    }
    return { key, out, log: (ch = choice) => { if (this.decisionLog) this.decisionLog.push(`${label},${npc.id},${tid},${key},${out.join('|')},${ch}`); } };
  }
  _look(tid, inputs, label, npc) { const r = this._lookup(tid, inputs, label, npc); r.log(); return r.out; }
  _twoOption(tid, inputs, label, npc, stream) {
    const r = this._lookup(tid, inputs, label, npc);
    const ch = stream.draw(100) < this.config.pSecond ? 'second' : 'first';
    r.log(ch);
    return ch === 'first' ? r.out[0] : r.out[1];
  }

  _compile(npc, label) {
    const sums = { warmth: 0, sociability: 0, diligence: 0, pride: 0 };
    for (const p of PAIRS) {
      const b = npc.beliefs[p];
      const out = this._look('T12', [POLES[p][b.pole], b.tier], label, npc);
      COMPILED_TRAITS.forEach((t, i) => { sums[t] += parseInt(out[i], 10); });
    }
    for (const t of COMPILED_TRAITS) npc.eff[t] = LEVELS[clamp(LEVEL_INDEX[npc.temperament[t]] + sums[t], -1, 1) + 1];
    npc.eff.honesty = npc.temperament.honesty;
    npc.eff.flexibility = npc.temperament.flexibility;
  }

  _countEvent(ev) { this.dayEvents[ev] = (this.dayEvents[ev] || 0) + 1; }

  // Appraisal by R of an event (A10.6). I = initiator or null (night work outcome).
  _appraise(R, I, event, label, room, act) {
    const pair = EVENT_PAIR[event];
    const tid = PAIR_TABLE[pair];
    const b = R.beliefs[pair];
    const inputs = [event, POLES[pair][b.pole], b.tier];
    if (tid === 'T7') inputs.push(R.eff.pride);
    const out = this._look(tid, inputs, label, R);
    const meaning = out[0], pressure = out[1], lc = tid === 'T8' ? '-' : out[2];
    this._countEvent(event);
    if (I) R.gotEvent = true;
    R.todayPressure[pair].push(pressure);
    R.mood = this._look('T9', [R.mood, meaning], label, R)[0];
    if (I) {
      const rel = R.rel.get(I.num);
      let delta = 0;
      if (rel.grudge === 'cool off' && (lc === 'same' || lc === 'up')) delta = -1;
      else if (lc === 'up') delta = (rel.grudge === 'hold grudge' || rel.grudge === 'pay back') ? 0 : 1;
      else if (lc === 'down') delta = -1;
      if (delta !== 0) {
        rel.counter += delta;
        if (rel.counter >= 3) { rel.liking = LIKINGS[Math.min(3, LIKINGS.indexOf(rel.liking) + 1)]; rel.counter = 0; }
        else if (rel.counter <= -3) { rel.liking = LIKINGS[Math.max(0, LIKINGS.indexOf(rel.liking) - 1)]; rel.counter = 0; }
      }
      if (meaning === 'slight' || meaning === 'insult') {
        rel.offence = meaning;
        const g = this._look('T10', [R.eff.warmth, meaning, 'none'], label, R)[0];
        rel.grudge = g === 'let it go' ? 'none' : g;
      }
      if (event === 'apologised to' && rel.offence !== 'none') {
        const g = this._look('T10', [R.eff.warmth, rel.offence, 'received'], label, R)[0];
        rel.grudge = g === 'let it go' ? 'none' : g;
        rel.offence = 'none';
      }
    }
    if (this.eventLog) this.eventLog.push(`${label},${room},${I ? I.id : '-'},${R.id},${act},${event},${meaning},${pressure},${lc}`);
  }

  // ---- one waking tick (A10)
  tick() {
    const t0 = (typeof performance !== 'undefined') ? performance.now() : 0;
    const c = this.config;
    const tickNo = this.day * 16 + this.hour;
    const label = String(tickNo);
    const npcs = this.npcs;
    // 0 reset
    for (const n of npcs) n.gotEvent = false;
    // 1 body
    for (const n of npcs) {
      n.food = Math.max(0, n.food - 5);
      n.energy = Math.max(0, n.energy - (n.room === 'field' ? 6 : 4));
    }
    // 2 needs
    for (const n of npcs) {
      const ft = foodTier(n.food);
      n.starvingRun = ft === 'starving' ? n.starvingRun + 1 : 0;
      if (n.starvingRun > this.maxStarvingRun) this.maxStarvingRun = n.starvingRun;
      n.need = this._look('T1', [ft, energyTier(n.energy)], label, n)[0];
    }
    // 3 room choice
    for (const n of npcs) {
      if (n.need === 'eat now' || n.need === 'rest now') n.room = 'home';
      else n.room = this._twoOption('T2', [n.need, n.eff.diligence, n.eff.sociability], label, n, this.rng.room);
    }
    // 4 home effects
    for (const n of npcs) {
      if (n.room !== 'home') continue;
      if (n.need === 'eat' || n.need === 'eat now') n.food = Math.min(100, n.food + 40);
      if (n.need === 'rest' || n.need === 'rest now') n.energy = Math.min(100, n.energy + 15);
      if (n.need === 'none') n.energy = Math.min(100, n.energy + 5);
    }
    // 5 field count
    for (const n of npcs) if (n.room === 'field') n.fieldTicksToday++;
    // 6 encounters
    const meet = this.rng.meet;
    for (const h of this.hamlets) {
      for (const room of ['field', 'square']) {
        const occ = h.filter(n => n.room === room);
        meet.shuffle(occ);
        for (let k = 0; k + 1 < occ.length; k += 2) {
          const first = meet.draw(2) === 0;
          const I = first ? occ[k] : occ[k + 1];
          const R = first ? occ[k + 1] : occ[k];
          this.encounters.push(`${tickNo},${room},${I.id},${R.id}`);
          const relIR = I.rel.get(R.num);
          if (room === 'field') {
            if (!relIR.workedBesideToday) relIR.workedBesideToday = true;
            const relRI = R.rel.get(I.num);
            if (!relRI.workedBesideToday) relRI.workedBesideToday = true;
          }
          if (relIR.owesApology) {
            const dec = this._look('T5', [I.eff.honesty, I.eff.pride], label, I)[0];
            if (dec === 'apologise') {
              relIR.owesApology = false;
              this._appraise(R, I, 'apologised to', label, room, 'apologise');
              continue;
            }
          }
          let stance;
          if (relIR.grudge === 'pay back') { stance = 'hostile'; relIR.grudge = 'hold grudge'; }
          else stance = this._look('T3', [I.eff.warmth, relIR.liking, I.mood], label, I)[0];
          const act = this._twoOption('T4', [stance, room, I.eff.honesty], label, I, this.rng.act);
          if (NEGATIVE_ACTS.has(act)) relIR.owesApology = true;
          this._appraise(R, I, ACT_EVENT[act], label, room, act);
        }
      }
    }
    // 8 quiet-hour mood fade
    for (const n of npcs) if (!n.gotEvent) n.mood = towardCalm(n.mood);
    // advance clock
    this.ticksRun++;
    this.hour++;
    if (this.hour === 16) {
      this.night();
    }
    if (t0) this.totalMs += performance.now() - t0;
  }

  // ---- night (A11)
  night() {
    const c = this.config;
    const label = 'night' + this.day;
    const npcs = this.npcs;
    const moodsAt15 = npcs.map(n => n.mood);
    // 1 work outcome
    for (const n of npcs) {
      if (n.fieldTicksToday < 4) continue;
      const chance = { low: 35, mid: 50, high: 65 }[n.eff.diligence];
      const ev = this.rng.work.draw(100) < chance ? 'work went well' : 'work went badly';
      this._appraise(n, null, ev, label, '-', '-');
    }
    // 2 integration
    const moves = [];
    if (!c.loopOff) {
      for (const n of npcs) {
        for (const p of PAIRS) {
          let s = 0;
          for (const pr of n.todayPressure[p]) s += pr === 'stronger' ? 1 : (pr === 'weaker' || pr === 'strained') ? -1 : 0;
          const buf = n.buffer[p];
          buf.push(Math.sign(s));
          if (buf.length > 7) buf.shift();
          let bal = 0; for (const v of buf) bal += v;
          const balance = bal <= -2 ? 'mostly against' : bal <= 1 ? 'mixed' : bal <= 4 ? 'mostly for' : 'strongly for';
          const b = n.beliefs[p];
          const move = this._look('T11', [balance, b.tier, n.temperament.flexibility], label, n)[0];
          let changed = false;
          if (move === 'up' && b.tier !== 'core') { b.tier = TIERS[TIERS.indexOf(b.tier) + 1]; changed = true; }
          else if (move === 'down' && b.tier !== 'faint') { b.tier = TIERS[TIERS.indexOf(b.tier) - 1]; changed = true; }
          else if (move === 'flip' && b.tier === 'faint') { b.pole = 1 - b.pole; changed = true; }
          else if (move === 'break' && b.tier === 'core') { b.pole = 1 - b.pole; b.tier = 'faint'; changed = true; }
          if (changed) { n.buffer[p] = []; moves.push({ npc: n.id, pair: p, move }); }
        }
      }
      // 3 recompile
      for (const n of npcs) this._compile(n, label);
    }
    // 4 grudge decay
    for (const n of npcs) for (const r of n.rel.values()) if (r.grudge === 'cool off') r.grudge = 'none';
    // 5 mood
    for (const n of npcs) n.mood = towardCalm(n.mood);
    // 6 body
    for (const n of npcs) { n.energy = Math.min(100, n.energy + 60); n.food = Math.max(0, n.food - 10); n.room = 'home'; }
    // 7 reset
    for (const n of npcs) {
      n.fieldTicksToday = 0;
      n.todayPressure = { trust: [], worth: [], effort: [] };
      for (const r of n.rel.values()) r.workedBesideToday = false;
    }
    // 8 snapshot + metrics
    this.snapshots.push({
      day: this.day,
      npcs: npcs.map((n, i) => ({
        id: n.id, positions: PAIRS.map(p => beliefPosition(n.beliefs[p])),
        eff: COMPILED_TRAITS.map(t => n.eff[t]), mood: moodsAt15[i],
      })),
      moves,
    });
    this.metrics.push(this._dailyMetrics(moodsAt15, moves));
    this.dayEvents = {};
    this.day++;
    this.hour = 0;
  }

  _dailyMetrics(moodsAt15, moves) {
    const events = Object.fromEntries(EVENTS.map(e => [e[0], this.dayEvents[e[0]] || 0]));
    const moods = Object.fromEntries(MOODS.map(m => [m, 0]));
    for (const m of moodsAt15) moods[m]++;
    const positions = {};
    for (const p of PAIRS) {
      // counts at positions [-3, -2, -1, +1, +2, +3]
      positions[p] = [0, 0, 0, 0, 0, 0];
      for (const n of this.npcs) { const x = beliefPosition(n.beliefs[p]); positions[p][x < 0 ? x + 3 : x + 2]++; }
    }
    const moveCounts = { up: 0, down: 0, flip: 0, break: 0 };
    for (const m of moves) moveCounts[m.move]++;
    const pos = l => l === 'like' || l === 'close';
    let friendships = 0, feuds = 0;
    const hasPos = new Set();
    for (const a of this.npcs) for (const b of a.relOrder) {
      const ab = a.rel.get(b.num).liking;
      if (pos(ab)) { hasPos.add(a.num); hasPos.add(b.num); }
      if (a.num < b.num) {
        const ba = b.rel.get(a.num).liking;
        if (pos(ab) && pos(ba)) friendships++;
        if (ab === 'dislike' && ba === 'dislike') feuds++;
      }
    }
    const isolates = this.npcs.length - hasPos.size;
    return { day: this.day, events, moods, positions, moves: moveCounts, friendships, feuds, isolates };
  }

  run() {
    const total = this.config.days * 16;
    while (this.ticksRun < total) this.tick();
    return this.summary();
  }

  canonicalState() {
    const lines = [];
    for (const n of this.npcs) {
      const b = p => `${POLES[p][n.beliefs[p].pole]}/${n.beliefs[p].tier}`;
      const rel = n.relOrder.map(o => {
        const r = n.rel.get(o.num);
        return `${o.id}:${r.liking}:${r.counter}:${r.grudge}:${r.offence}:${r.owesApology ? 1 : 0}`;
      }).join(';');
      lines.push(`${n.id}|food=${n.food}|energy=${n.energy}|mood=${n.mood}|room=${n.room}|trust=${b('trust')}|worth=${b('worth')}|effort=${b('effort')}|eff=${n.eff.warmth},${n.eff.sociability},${n.eff.diligence},${n.eff.pride}|buf=${PAIRS.map(p => n.buffer[p].join(',')).join(';')}|rel=${rel}`);
    }
    return lines.join('\n');
  }
  decisionLogText() { return this.decisionLog ? this.decisionLog.join('\n') + '\n' : null; }
  eventLogText() { return this.eventLog ? this.eventLog.join('\n') + '\n' : null; }
  stateHash() { return sha256(this.canonicalState()); }
  logHash() { return this.decisionLog ? sha256(this.decisionLogText()) : '-'; }

  summary() {
    return {
      config: this.config,
      castHash: this.castHash,
      tableHashes: this.tableHashes,
      effectiveTableHashes: this.config.tablesMode === 'csv' ? undefined : this.effectiveTableHashes,
      missingRows: this.missingRows,
      missingKeys: Object.fromEntries(this.missingKeys),
      stateHash: this.stateHash(),
      logHash: this.logHash(),
      days: this.day,
      ticks: this.ticksRun,
      dailyMetrics: this.metrics,
      timing: { totalMs: Number(this.totalMs.toFixed(3)), msPerTick: Number((this.totalMs / Math.max(1, this.ticksRun)).toFixed(4)) },
    };
  }
}
