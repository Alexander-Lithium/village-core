// Writes cast/cast_s1_n20.csv using the cast generator (A9).
import { mkdirSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { generateCast, castToCsv } from './engine.js';
import { sha256 } from './sha256.js';

const here = dirname(fileURLToPath(import.meta.url));
mkdirSync(join(here, 'cast'), { recursive: true });
const text = castToCsv(generateCast(1, 20));
writeFileSync(join(here, 'cast', 'cast_s1_n20.csv'), text);
console.log('wrote cast/cast_s1_n20.csv  cast hash ' + sha256(text));
