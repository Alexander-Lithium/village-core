// Acceptance tests (A15). Prints PASS/FAIL per test and the golden hashes.
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { Village, loadTable, generateCast, castToCsv, PAIRS, beliefPosition, TRAITS, DEFAULT_CONFIG } from './engine.js';
import { sha256 } from './sha256.js';
import { loadTableDir } from './run.js';

const here = dirname(fileURLToPath(import.meta.url));
const rules = loadTableDir('tables/rules');
let failures = 0;
const report = (name, ok, detail = '') => {
  if (!ok) failures++;
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
};
const run = (cfg, tables = rules) => { const sim = new Village({ ...DEFAULT_CONFIG, ...cfg }, tables); sim.run(); return sim; };
const dropRow = (text, key) => text.split('\n').filter(l => l.split(',').slice(0, key.split('|').length).join('|') !== key).join('\n');
const replaceRow = (text, key, outs) => text.split('\n').map(l => {
  const v = l.split(','); const k = key.split('|').length;
  return v.slice(0, k).join('|') === key ? [...v.slice(0, k), ...outs].join(',') : l;
}).join('\n');

// 0. SHA-256 known-answer check (extra)
report('0 sha256 known vector ("abc")', sha256('abc') === 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');

// 1. Validation
{
  const allOk = Object.entries(rules).every(([tid, text]) => loadTable(tid, text).errors.length === 0);
  const del = loadTable('T3', dropRow(rules.T3, 'mid|neutral|calm')).errors;
  const ill = loadTable('T9', replaceRow(rules.T9, 'calm|slight', ['furious'])).errors;
  const room = loadTable('T4', replaceRow(rules.T4, 'friendly|field|mid', ['praise', 'chat'])).errors;
  const press = loadTable('T6', replaceRow(rules.T6, 'helped|people mean well|core', ['good sign', 'stronger', 'up'])).errors;
  let refused = false;
  try { new Village({ ...DEFAULT_CONFIG }, { ...rules, T3: dropRow(rules.T3, 'mid|neutral|calm') }); } catch { refused = true; }
  report('1 validation', allOk && del.length > 0 && ill.length > 0 && room.length > 0 && press.length > 0 && refused,
    `rule tables valid=${allOk}; deleted row → "${del[0]}"; illegal output → "${ill[0]}"; T4 room → "${room[0]}"; T6 pressure → "${press[0]}"; engine refuses=${refused}`);
}

// 2. Determinism
const a1 = run({ runSeed: 1, n: 20, days: 30 });
const a2 = run({ runSeed: 1, n: 20, days: 30 });
report('2 determinism', a1.stateHash() === a2.stateHash() && a1.logHash() === a2.logHash());

// 3. Seed sensitivity
const s2 = run({ runSeed: 2, n: 20, days: 30 });
report('3 seed sensitivity', s2.stateHash() !== a1.stateHash());

// 4. Stream isolation
{
  const key = 'neutral|square|mid';
  const mod = { ...rules, T4: replaceRow(rules.T4, key, ['argue', 'argue']) };
  const b = run({ runSeed: 1, n: 20, days: 1 });
  const m = run({ runSeed: 1, n: 20, days: 1 }, mod);
  const day0 = sim => sim.encounters.filter(e => parseInt(e, 10) < 16).join('\n');
  const actsChanged = b.eventLogText() !== m.eventLogText();
  report('4 stream isolation', day0(b) === day0(m) && actsChanged,
    `T4 ${key} → argue/argue; acts changed=${actsChanged}; day-0 meetings identical (${b.encounters.length} encounters)`);
}

// 5. Loop off
{
  const sim = run({ runSeed: 1, n: 20, days: 30, loopOff: true });
  const last = sim.snapshots[sim.snapshots.length - 1].npcs.map(x => x.positions.join(','));
  const start = sim.initialPositions.map(p => p.join(','));
  const day0 = sim.snapshots[0].npcs.map(x => x.positions.join(','));
  report('5 loop off', last.join(';') === start.join(';') && last.join(';') === day0.join(';'));
}

// 6. Traits off
{
  const sim = new Village({ ...DEFAULT_CONFIG, traitsOff: true }, rules);
  report('6 traits off', sim.npcs.every(n => TRAITS.every(t => n.temperament[t] === 'mid')));
}

// 7. Fallback
{
  const key = 'low|neutral|calm'; // rule output is "cold"; default is "neutral"
  const sim = run({ runSeed: 1, n: 20, days: 30, skipValidation: true }, { ...rules, T3: dropRow(rules.T3, key) });
  const used = sim.decisionLog.filter(l => l.includes(`,T3,${key},`));
  const allDefault = used.length > 0 && used.every(l => l.endsWith(',neutral,-'));
  report('7 fallback', sim.ticksRun === 480 && sim.missingRows > 0 && allDefault,
    `deleted T3 ${key}; missingRows=${sim.missingRows}; default "neutral" used in ${used.length} lookups`);
}

// 8. Body sanity
{
  const runs = [a1, s2, ...[3, 4, 5].map(s => run({ runSeed: s, n: 20, days: 30 }))];
  const worst = Math.max(...runs.map(s => s.maxStarvingRun));
  report('8 body sanity', worst <= 16, `longest starving run over seeds 1–5 = ${worst} waking ticks`);
}

// 9. Cast
{
  const shipped = readFileSync(join(here, 'cast', 'cast_s1_n20.csv'), 'utf8');
  const regen = castToCsv(generateCast(1, 20));
  report('9 cast', sha256(shipped) === sha256(regen) && a1.castHash === sha256(shipped), `cast hash ${sha256(shipped)}`);
}

// 10. Scale
{
  const sim = new Village({ ...DEFAULT_CONFIG, n: 10000, days: 1, logDecisions: false }, rules);
  sim.run();
  report('10 scale', sim.ticksRun === 16, `n 10000, days 1: ${(sim.totalMs / sim.ticksRun).toFixed(2)} ms per tick; state hash ${sim.stateHash()}`);
}

// 11. Golden hashes
{
  const b = run({ runSeed: 1, n: 5, days: 3 });
  report('11 golden hashes', true);
  console.log(`  runSeed 1, n 20, days 30: state ${a1.stateHash()}`);
  console.log(`                            log   ${a1.logHash()}`);
  console.log(`  runSeed 1, n 5,  days 3:  state ${b.stateHash()}`);
  console.log(`                            log   ${b.logHash()}`);
}

console.log(failures === 0 ? 'ALL TESTS PASSED' : `${failures} TEST(S) FAILED`);
process.exitCode = failures ? 1 : 0;
