// Writes the baseline rule tables (A6.1) to tables/rules/*.csv in normalised form (A6.0).
import { mkdirSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import {
  TABLE_DEFS, TABLE_IDS, gridKeys, normaliseTable, LEVEL_INDEX, LIKINGS, MOODS, POLES,
  EVENT_VALENCE, MEANINGS,
} from './engine.js';

const i = x => LEVEL_INDEX[x];
const likingIdx = { dislike: -1, neutral: 0, like: 1, close: 2 };
const moodIdx = { low: -1, calm: 0, good: 1 };
const poleSign = (pair, belief) => (POLES[pair][0] === belief ? 1 : -1);

const rules = {
  T1: ([food, energy]) => {
    if (food === 'starving') return ['eat now'];
    if (energy === 'exhausted') return ['rest now'];
    if (food === 'very hungry') return ['eat'];
    if (energy === 'very tired') return ['rest'];
    if (food === 'hungry' && energy === 'tired') return ['eat'];
    return ['none'];
  },
  T2: ([need, dil, soc]) => {
    if (need === 'eat' || need === 'rest') return ['home', dil === 'high' ? 'field' : 'square'];
    const f = i(dil), s = i(soc);
    const first = s > f ? 'square' : 'field';
    const other = first === 'field' ? 'square' : 'field';
    return [first, (f === -1 && s === -1) ? 'home' : other];
  },
  T3: ([warmth, liking, mood]) => {
    const s = i(warmth) + likingIdx[liking] + moodIdx[mood];
    return [s >= 2 ? 'friendly' : s >= 0 ? 'neutral' : s === -1 ? 'cold' : 'hostile'];
  },
  T4: ([stance, room, honesty]) => {
    const low = honesty === 'low';
    if (room === 'field') {
      if (stance === 'friendly') return ['help', 'chat'];
      if (stance === 'neutral') return ['chat', 'help'];
      if (stance === 'cold') return low ? ['chat', 'take credit'] : ['chat', 'chat'];
      return low ? ['argue', 'take credit'] : ['argue', 'chat'];
    }
    if (stance === 'friendly') return ['praise', 'share food'];
    if (stance === 'neutral') return low ? ['chat', 'ignore'] : ['chat', 'chat'];
    if (stance === 'cold') return ['ignore', 'interrupt'];
    return ['argue', 'interrupt'];
  },
  T5: ([honesty, pride]) => [i(honesty) - i(pride) >= 0 ? 'apologise' : "don't"],
  T9: ([mood, meaning]) => {
    const m = MOODS.indexOf(mood);
    if (meaning === 'good sign') return [MOODS[Math.min(2, m + 1)]];
    if (meaning === 'nothing much') return [mood];
    if (meaning === 'slight') return [MOODS[Math.max(0, m - 1)]];
    return ['low'];
  },
  T10: ([warmth, offence, apology]) => {
    const g = i(warmth) + (apology === 'received' ? 1 : 0) - (offence === 'insult' ? 1 : 0);
    return [g >= 1 ? 'let it go' : g === 0 ? 'cool off' : g === -1 ? 'hold grudge' : 'pay back'];
  },
  T11: ([balance, tier, flex]) => {
    if (balance === 'strongly for') return [tier === 'core' ? 'stay' : 'up'];
    if (balance === 'mostly for') return [flex === 'high' && tier !== 'core' ? 'up' : 'stay'];
    if (balance === 'mixed') return ['stay'];
    if (tier === 'faint') return [flex === 'low' ? 'stay' : 'flip'];
    if (tier === 'held') return [flex === 'low' ? 'stay' : 'down'];
    return [flex === 'high' ? 'break' : flex === 'mid' ? 'down' : 'stay'];
  },
  T12: ([belief, tier]) => {
    // steps: warmth, sociability, diligence, pride
    const z = ['0', '0', '0', '0'];
    if (tier === 'faint') return z;
    const held = tier === 'held';
    switch (belief) {
      case 'people mean well': return held ? ['+1', '0', '0', '0'] : ['+1', '+1', '0', '0'];
      case 'people are against me': return held ? ['-1', '0', '0', '0'] : ['-1', '-1', '0', '0'];
      case 'i am respected': return held ? z : ['0', '0', '0', '+1'];
      case 'i am overlooked': return held ? ['0', '-1', '0', '0'] : ['0', '-1', '0', '+1'];
      case 'hard work pays off': return held ? ['0', '0', '+1', '0'] : ['0', '0', '+1', '0'];
      case 'nothing i do matters': return held ? ['0', '0', '-1', '0'] : ['0', '-1', '-1', '0'];
    }
    throw new Error('bad belief ' + belief);
  },
};

// T6-T8 appraisal rules
function appraise(pair, withLiking, withPride) {
  return (inputs) => {
    const [event, belief, tier] = inputs;
    const pride = withPride ? inputs[3] : null;
    let meaning, pressure;
    if (event === 'chatted with') {
      meaning = 'nothing much'; pressure = 'same';
      return withLiking ? [meaning, pressure, 'same'] : [meaning, pressure];
    }
    const v = EVENT_VALENCE[event];
    const p = poleSign(pair, belief);
    if (v === p) { // confirming
      pressure = tier === 'core' ? 'same' : 'stronger';
      meaning = v > 0 ? 'good sign' : (tier === 'faint' ? 'slight' : 'insult');
    } else { // contradicting
      pressure = tier === 'core' ? 'strained' : 'weaker';
      meaning = v > 0 ? (tier === 'faint' ? 'good sign' : 'nothing much') : 'slight';
    }
    if (withPride && v < 0) {
      const ladder = ['nothing much', 'slight', 'insult'];
      const k = ladder.indexOf(meaning);
      if (k >= 0) {
        if (pride === 'high') meaning = ladder[Math.min(2, k + 1)];
        else if (pride === 'low') meaning = ladder[Math.max(0, k - 1)];
      }
    }
    if (!withLiking) return [meaning, pressure];
    const lc = meaning === 'good sign' ? 'up' : meaning === 'nothing much' ? 'same' : 'down';
    return [meaning, pressure, lc];
  };
}
rules.T6 = appraise('trust', true, false);
rules.T7 = appraise('worth', true, true);
rules.T8 = appraise('effort', false, false);

export function ruleTableTexts() {
  const out = {};
  for (const tid of TABLE_IDS) {
    const map = new Map();
    for (const inputs of gridKeys(tid)) map.set(inputs.join('|'), rules[tid](inputs));
    out[tid] = normaliseTable(tid, map);
  }
  return out;
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const here = dirname(fileURLToPath(import.meta.url));
  const dir = join(here, 'tables', 'rules');
  mkdirSync(dir, { recursive: true });
  const texts = ruleTableTexts();
  let rows = 0;
  for (const tid of TABLE_IDS) {
    writeFileSync(join(dir, TABLE_DEFS[tid].file), texts[tid]);
    rows += texts[tid].split('\n').length - 2;
  }
  console.log(`wrote ${TABLE_IDS.length} tables (${rows} rows) to tables/rules/`);
}
