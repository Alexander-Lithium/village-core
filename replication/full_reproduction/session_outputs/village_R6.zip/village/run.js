// Command-line batch runner (A13).
// node run.js --runSeed 1 --n 20 --days 30 --tableDir tables/rules [--loopOff] [--traitsOff]
//   [--tablesMode shuffled|random] [--seeds 1-100] [--castSeed 1] [--hamletSize 20] [--pSecond 25]
//   [--logDecisions false] [--likingStep 3 --foodPerTick 5 --mealSize 40 --bufferDays 7 --balAgainst -2 --balFor 2 --balStrong 5] --out results/<name>
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';
import { Village, TABLE_DEFS, TABLE_IDS, DEFAULT_CONFIG } from './engine.js';

const here = dirname(fileURLToPath(import.meta.url));

export function loadTableDir(dir) {
  const abs = resolve(here, dir);
  const out = {};
  for (const tid of TABLE_IDS) out[tid] = readFileSync(join(abs, TABLE_DEFS[tid].file), 'utf8');
  return out;
}

export function runOnce(config, tableTexts) {
  const cfg = { ...DEFAULT_CONFIG, ...config };
  const sim = new Village(cfg, tableTexts ?? loadTableDir(cfg.tableDir));
  const summary = sim.run();
  return { sim, summary };
}

function parseArgs(argv) {
  const cfg = {}; let seeds = null; let out = null;
  const flags = new Set(['loopOff', 'traitsOff', 'skipValidation']);
  for (let k = 0; k < argv.length; k++) {
    const a = argv[k];
    if (!a.startsWith('--')) throw new Error('bad arg ' + a);
    const name = a.slice(2);
    if (flags.has(name)) { cfg[name] = true; continue; }
    const v = argv[++k];
    if (name === 'seeds') { const [x, y] = v.split('-').map(Number); seeds = [x, y ?? x]; }
    else if (name === 'out') out = v;
    else if (['runSeed', 'castSeed', 'n', 'days', 'hamletSize', 'pSecond', 'likingStep', 'foodPerTick', 'mealSize', 'bufferDays', 'balAgainst', 'balFor', 'balStrong'].includes(name)) cfg[name] = parseInt(v, 10);
    else if (name === 'logDecisions') cfg[name] = v !== 'false';
    else if (name === 'tableDir' || name === 'tablesMode') cfg[name] = v;
    else throw new Error('unknown option --' + name);
  }
  return { cfg, seeds, out };
}

function finalRow(summary) {
  const m = summary.dailyMetrics[summary.dailyMetrics.length - 1];
  const row = { runSeed: summary.config.runSeed, stateHash: summary.stateHash, logHash: summary.logHash, missingRows: summary.missingRows };
  if (m) {
    for (const [k, v] of Object.entries(m.moods)) row['mood_' + k] = v;
    for (const [p, d] of Object.entries(m.positions)) ['m3', 'm2', 'm1', 'p1', 'p2', 'p3'].forEach((pos, k) => { row[`${p}_${pos}`] = d[k]; });
    row.friendships = m.friendships; row.feuds = m.feuds; row.isolates = m.isolates;
  }
  return row;
}

function writeRun(dir, sim, summary) {
  mkdirSync(dir, { recursive: true });
  writeFileSync(join(dir, 'summary.json'), JSON.stringify(summary, null, 1));
  writeFileSync(join(dir, 'snapshots.json'), JSON.stringify(sim.snapshots));
  if (sim.decisionLog) {
    writeFileSync(join(dir, 'decisions.csv'), sim.decisionLogText());
    writeFileSync(join(dir, 'events.csv'), sim.eventLogText());
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const { cfg, seeds, out } = parseArgs(process.argv.slice(2));
  const tables = loadTableDir(cfg.tableDir ?? DEFAULT_CONFIG.tableDir);
  const list = seeds ? Array.from({ length: seeds[1] - seeds[0] + 1 }, (_, k) => seeds[0] + k) : [cfg.runSeed ?? DEFAULT_CONFIG.runSeed];
  const rows = [];
  for (const s of list) {
    const { sim, summary } = runOnce({ ...cfg, runSeed: s }, tables);
    console.log(`runSeed ${s}  state ${summary.stateHash}  log ${summary.logHash}  missingRows ${summary.missingRows}  ms/tick ${summary.timing.msPerTick}`);
    if (out) writeRun(seeds ? join(out, 'seed_' + s) : out, sim, summary);
    rows.push(finalRow(summary));
  }
  if (out && seeds) {
    const cols = [...new Set(rows.flatMap(r => Object.keys(r)))];
    writeFileSync(join(out, 'final_metrics.csv'), cols.join(',') + '\n' + rows.map(r => cols.map(c => r[c] ?? '').join(',')).join('\n') + '\n');
  }
}
