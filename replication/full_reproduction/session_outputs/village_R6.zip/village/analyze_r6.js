// R6: what happens when an outside mind steers one villager?
//   node analyze_r6.js --step2 <seedFrom>-<seedTo>  → results/R6/raw/step2_seed<s>.json (one baseline + 20×16 steered runs per seed)
//   node analyze_r6.js --report                      → self-checks, Step 2 table, Steps 3 and 4 → results/R6/report.md, summary.json
//   node analyze_r6.js                               → everything (missing Step 2 seeds first)
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { Village, DEFAULT_CONFIG, PAIRS, POLES, LEVEL_INDEX, COMPILED_TRAITS, beliefPosition, isSteeredDay, SUTURE_MINDS } from './engine.js';
import { loadTableDir } from './run.js';

const here = dirname(fileURLToPath(import.meta.url));
const OUT = join(here, 'results', 'R6');
const RAW = join(OUT, 'raw');
const TABLE_DIR = 'tables/consensus';
const tables = loadTableDir(TABLE_DIR);
const IDS = Array.from({ length: 20 }, (_, i) => 'n' + String(i + 1).padStart(4, '0'));
const MINDS = ['cold', 'warm', 'twin', 'random'];
const FRACTIONS = [0.25, 0.5, 0.75, 1];
const S2_SEEDS = Array.from({ length: 10 }, (_, i) => 101 + i);
const S2_DAYS = 90, UNTIL = 60, CAPTURE = [60, 90];

function makeSim(seed, days, suture = null, logs = false, extra = {}) {
  return new Village({ ...DEFAULT_CONFIG, runSeed: seed, n: 20, days, tableDir: TABLE_DIR, logDecisions: logs, suture, ...extra }, tables);
}
// state of one villager "at day k" = after k full days (k × 16 waking ticks and k nights); day 0 = after the initial compile
function capture(sim, n) {
  const pos = l => l === 'like' || l === 'close';
  const others = sim.npcs.filter(o => o !== n);
  return {
    traits: COMPILED_TRAITS.map(t => LEVEL_INDEX[n.eff[t]]),
    positions: PAIRS.map(p => beliefPosition(n.beliefs[p])),
    beliefs: PAIRS.map(p => `${POLES[p][n.beliefs[p].pole]} (${n.beliefs[p].tier})`),
    friends: others.filter(o => pos(n.rel.get(o.num).liking)).map(o => o.id),
    enemies: others.filter(o => n.rel.get(o.num).liking === 'dislike').map(o => o.id),
    likedBy: others.filter(o => pos(o.rel.get(n.num).liking)).length,
    dislikedBy: others.filter(o => o.rel.get(n.num).liking === 'dislike').length,
  };
}
// run to the end, capturing the given villagers at the given days; moves counted over days [0, movesUntil)
function runCapture(sim, ids, days, movesUntil = UNTIL) {
  const at = {};
  const snap = d => { at[d] = Object.fromEntries(ids.map(id => [id, capture(sim, sim.npcs.find(n => n.id === id))])); };
  if (days.includes(0)) snap(0);
  const total = sim.config.days * 16;
  while (sim.ticksRun < total) { sim.tick(); if (sim.hour === 0 && days.includes(sim.day)) snap(sim.day); }
  const moves = Object.fromEntries(ids.map(id => [id, { moves: 0, breaks: 0, flips: 0 }]));
  for (const s of sim.snapshots.slice(0, movesUntil)) for (const m of s.moves) if (moves[m.npc]) {
    moves[m.npc].moves++; if (m.move === 'break') moves[m.npc].breaks++; if (m.move === 'flip') moves[m.npc].flips++;
  }
  return { at, moves, stateHash: sim.stateHash(), steeredDays: sim.steeredDays };
}
const slim = c => ({ traits: c.traits, positions: c.positions, friends: c.friends.length, enemies: c.enemies.length, likedBy: c.likedBy, dislikedBy: c.dislikedBy });

// ---------------------------------------------------------------- Step 2 runs
function step2Seed(seed) {
  const base = runCapture(makeSim(seed, S2_DAYS), IDS, CAPTURE);
  const out = { seed, baseline: { stateHash: base.stateHash, villagers: {} }, steered: [] };
  for (const id of IDS) out.baseline.villagers[id] = { 60: slim(base.at[60][id]), 90: slim(base.at[90][id]), ...base.moves[id] };
  for (const mind of MINDS) for (const fraction of FRACTIONS) for (const id of IDS) {
    const r = runCapture(makeSim(seed, S2_DAYS, { subjects: [id], mind, fraction, untilDay: UNTIL }), [id], CAPTURE);
    out.steered.push({ mind, fraction, subject: id, steeredDays: r.steeredDays, stateHash: r.stateHash, 60: slim(r.at[60][id]), 90: slim(r.at[90][id]), ...r.moves[id] });
  }
  mkdirSync(RAW, { recursive: true });
  writeFileSync(join(RAW, `step2_seed${seed}.json`), JSON.stringify(out));
  console.log(`step 2 seed ${seed}: ${out.steered.length} steered runs`);
}

// ---------------------------------------------------------------- statistics
const mean = a => a.reduce((s, x) => s + x, 0) / a.length;
const sd = a => { const m = mean(a); return Math.sqrt(a.reduce((s, x) => s + (x - m) ** 2, 0) / (a.length - 1)); };
const mci = a => `${mean(a).toFixed(2)} ± ${(1.96 * sd(a) / Math.sqrt(a.length)).toFixed(2)}`;
const absSum = (a, b) => a.reduce((s, x, i) => s + Math.abs(x - b[i]), 0);
const MIND_VEC = Object.fromEntries(Object.entries(SUTURE_MINDS).map(([k, m]) => [k, COMPILED_TRAITS.map(t => LEVEL_INDEX[m[t]])]));

function report() {
  const lines = [];
  const P = (...l) => { for (const x of l) { lines.push(x); console.log(x); } };
  const summary = {};
  P('# R6 report', '');

  // ---- self-checks
  P('## Self-checks', '');
  const checks = [];
  const h = (cfg, extra = {}) => { const s = makeSim(101, 30, cfg, false, extra); s.run(); return s.stateHash(); };
  const b30 = h(null);
  checks.push(['suture with no subjects (cold, fraction 1) = no steering', h({ subjects: [], mind: 'cold', fraction: 1, untilDay: 60 }) === b30]);
  checks.push(['untilDay 0 (cold, fraction 1, subject n0001) = no steering', h({ subjects: ['n0001'], mind: 'cold', fraction: 1, untilDay: 0 }) === b30]);
  checks.push(['fraction 0 (cold, subject n0001) = no steering', h({ subjects: ['n0001'], mind: 'cold', fraction: 0, untilDay: 60 }) === b30]);
  checks.push(['loop off: twin mind on every villager, fraction 1 = no steering (twin = own traits when beliefs cannot move)',
    h({ subjects: IDS, mind: 'twin', fraction: 1, untilDay: 60 }, { loopOff: true }) === h(null, { loopOff: true })]);
  checks.push(['cold mind, fraction 1, subject n0001 changes the run', h({ subjects: ['n0001'], mind: 'cold', fraction: 1, untilDay: 60 }) !== b30]);
  for (const f of FRACTIONS) {
    const days = Array.from({ length: S2_DAYS }, (_, d) => d).filter(d => isSteeredDay(d, f, UNTIL));
    checks.push([`fraction ${f}: ${days.length} steered days in 0–59 (first ${days.slice(0, 4).join(', ')}…)`, days.length === f * UNTIL && days.every(d => d < UNTIL)]);
  }
  for (const [name, ok] of checks) P(`- ${ok ? 'PASS' : 'FAIL'}: ${name}`);
  P('');
  summary.selfChecks = checks;

  // ---- Step 2
  const seeds = S2_SEEDS.map(s => JSON.parse(readFileSync(join(RAW, `step2_seed${s}.json`), 'utf8')));
  const baseHashOk = seeds.every(s => { const sim = makeSim(s.seed, S2_DAYS); sim.run(); return sim.stateHash() === s.baseline.stateHash; });
  P('## Step 2: steering one villager (seeds 101–110, 20 subjects each, 90 days, steered until day 60)', '');
  P(`Runs: ${seeds.length} baselines (= ${seeds.length * 20} subject baselines) and ${seeds.reduce((t, s) => t + s.steered.length, 0)} steered runs. Baseline hashes re-checked: ${baseHashOk}.`);
  P('Each cell: mean ± 1.96 × SD / √200 over 20 subjects × 10 seeds. "d60" = end of day 60 (after 60 days), "d90" = after 90 days. Δ = steered − baseline.', '');
  const COLS = [
    ['Toward-mind d60', r => r.toward60], ['Toward-mind d90', r => r.toward90],
    ['Trait shift d60', r => r.traitShift60], ['Trait shift d90', r => r.traitShift90],
    ['Belief shift d60', r => r.beliefShift60], ['Belief shift d90', r => r.beliefShift90],
    ['Δ worth pos d60', r => r.dWorth60], ['Δ trust pos d60', r => r.dTrust60],
    ['Δ friends d60', r => r.dFriends60], ['Δ friends d90', r => r.dFriends90],
    ['Δ enemies d60', r => r.dEnemies60], ['Δ enemies d90', r => r.dEnemies90],
    ['Δ liked by d60', r => r.dLikedBy60], ['Δ disliked by d60', r => r.dDislikedBy60],
    ['Moves steered', r => r.movesS], ['Moves base', r => r.movesB],
    ['Breaks steered', r => r.breaksS], ['Breaks base', r => r.breaksB],
    ['Flips steered', r => r.flipsS], ['Flips base', r => r.flipsB],
  ];
  P('| Mind | Fraction | Steered days | ' + COLS.map(c => c[0]).join(' | ') + ' |', '|' + ' --- |'.repeat(COLS.length + 3));
  summary.step2 = {};
  for (const mind of MINDS) for (const fraction of FRACTIONS) {
    const rows = [];
    let steeredDays = new Set();
    for (const s of seeds) for (const st of s.steered.filter(x => x.mind === mind && x.fraction === fraction)) {
      const b = s.baseline.villagers[st.subject];
      steeredDays.add(st.steeredDays);
      const mv = MIND_VEC[mind];
      rows.push({
        toward60: mv ? absSum(b[60].traits, mv) - absSum(st[60].traits, mv) : null,
        toward90: mv ? absSum(b[90].traits, mv) - absSum(st[90].traits, mv) : null,
        traitShift60: absSum(st[60].traits, b[60].traits), traitShift90: absSum(st[90].traits, b[90].traits),
        beliefShift60: absSum(st[60].positions, b[60].positions), beliefShift90: absSum(st[90].positions, b[90].positions),
        dTrust60: st[60].positions[0] - b[60].positions[0], dWorth60: st[60].positions[1] - b[60].positions[1],
        dFriends60: st[60].friends - b[60].friends, dFriends90: st[90].friends - b[90].friends,
        dEnemies60: st[60].enemies - b[60].enemies, dEnemies90: st[90].enemies - b[90].enemies,
        dLikedBy60: st[60].likedBy - b[60].likedBy, dDislikedBy60: st[60].dislikedBy - b[60].dislikedBy,
        movesS: st.moves, movesB: b.moves, breaksS: st.breaks, breaksB: b.breaks, flipsS: st.flips, flipsB: b.flips,
      });
    }
    if (rows.length !== 200) throw new Error(`${mind} ${fraction}: ${rows.length} rows`);
    const cells = COLS.map(([name, f]) => { const v = rows.map(f); return v[0] === null ? '—' : mci(v); });
    summary.step2[`${mind}|${fraction}`] = Object.fromEntries(COLS.map(([name, f]) => { const v = rows.map(f); return [name, v[0] === null ? null : { mean: mean(v), ci: 1.96 * sd(v) / Math.sqrt(v.length) }]; }));
    P(`| ${mind} | ${fraction} | ${[...steeredDays].join('/')} | ${cells.join(' | ')} |`);
  }
  P('');

  // ---- Step 3
  P('## Step 3: why (fraction 1, seeds 101–105, 60 days, logs on; every villager as subject)', '');
  P('Per subject per run, averaged over 20 subjects × 5 seeds (mean ± 1.96 × SD / √100).', '');
  P('| Mind | T2 → home | T2 → field | T2 → square | Received `praised` | Received `credit taken` |', '| --- | --- | --- | --- | --- | --- |');
  summary.step3 = {};
  for (const mind of ['none', 'cold', 'warm', 'twin']) {
    const rows = [];
    for (let seed = 101; seed <= 105; seed++) {
      const base = mind === 'none' ? makeSim(seed, 60, null, true) : null;
      if (base) base.run();
      for (const id of IDS) {
        let sim = base;
        if (!sim) { sim = makeSim(seed, 60, { subjects: [id], mind, fraction: 1, untilDay: 60 }, true); sim.run(); }
        const r = { home: 0, field: 0, square: 0, praised: 0, credit: 0 };
        for (let i = 1; i < sim.decisionLog.length; i++) {
          const [, npc, tid, , out, ch] = sim.decisionLog[i].split(',');
          if (npc === id && tid === 'T2') { const o = out.split('|'); r[ch === 'first' ? o[0] : o[1]]++; }
        }
        for (let i = 1; i < sim.eventLog.length; i++) {
          const [, , , rec, , ev] = sim.eventLog[i].split(',');
          if (rec !== id) continue;
          if (ev === 'praised') r.praised++; else if (ev === 'credit taken') r.credit++;
        }
        rows.push(r);
      }
    }
    summary.step3[mind] = Object.fromEntries(['home', 'field', 'square', 'praised', 'credit'].map(k => [k, mean(rows.map(r => r[k]))]));
    P(`| ${mind === 'none' ? 'no steering' : mind} | ${['home', 'field', 'square', 'praised', 'credit'].map(k => mci(rows.map(r => r[k]))).join(' | ')} |`);
  }
  P('');

  // ---- Step 4
  P('## Step 4: one life (n0017, seed 101, 90 days; cold mind at fraction 1 until day 60)', '');
  summary.step4 = {};
  for (const [label, su] of [['no steering', null], ['cold, fraction 1', { subjects: ['n0017'], mind: 'cold', fraction: 1, untilDay: 60 }]]) {
    const r = runCapture(makeSim(101, 90, su), ['n0017'], [0, 30, 60, 90]);
    summary.step4[label] = r.at;
    P(`### ${label}`, '');
    P('| Day | Trust belief | Worth belief | Effort belief | Warmth / sociability / diligence / pride | Friends | Enemies | Liked by |', '| --- | --- | --- | --- | --- | --- | --- | --- |');
    for (const d of [0, 30, 60, 90]) {
      const c = r.at[d].n0017;
      const tr = c.traits.map(x => (x > 0 ? '+1' : String(x))).join(' / ');
      P(`| ${d} | ${c.beliefs.join(' | ')} | ${tr} | ${c.friends.length}: ${c.friends.join(' ') || '—'} | ${c.enemies.length}: ${c.enemies.join(' ') || '—'} | ${c.likedBy} |`);
    }
    P('');
  }
  writeFileSync(join(OUT, 'report.md'), lines.join('\n') + '\n');
  writeFileSync(join(OUT, 'summary.json'), JSON.stringify(summary, null, 1));
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const a = process.argv.slice(2);
  mkdirSync(OUT, { recursive: true });
  if (a[0] === '--step2') { const [x, y] = a[1].split('-').map(Number); for (let s = x; s <= (y ?? x); s++) step2Seed(s); }
  else if (a[0] === '--report') report();
  else { for (const s of S2_SEEDS) if (!existsSync(join(RAW, `step2_seed${s}.json`))) step2Seed(s); report(); }
}
