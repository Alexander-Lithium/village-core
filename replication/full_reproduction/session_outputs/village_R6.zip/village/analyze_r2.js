// R2: spread of lives and village outcomes across 15 conditions, seeds 101–150, n 20, 60 days.
//   node analyze_r2.js --run <condition>   → results/R2/raw/<condition>.json (per-run raw results)
//   node analyze_r2.js --report            → results/R2/report.md (+ summary.json)
//   node analyze_r2.js                     → all conditions sequentially, then the report
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { Village, DEFAULT_CONFIG, PAIRS, beliefPosition, NEGATIVE_ACTS, streamFor } from './engine.js';
import { loadTableDir } from './run.js';

const here = dirname(fileURLToPath(import.meta.url));
const RAW = join(here, 'results', 'R2', 'raw');
const SEEDS = Array.from({ length: 50 }, (_, i) => 101 + i);
const DAYS = 60;
const FILLS = ['opusnormal_r1', 'opusnormal_r2', 'opusblind_r1', 'opusblind_r2', 'gemini_r1', 'gemini_r2', 'chatgpt_r1', 'chatgpt_r2', 'dev_r1'];
export const CONDITIONS = [
  ['consensus', 'tables/consensus', {}],
  ['consensus_loopOff', 'tables/consensus', { loopOff: true }],
  ['consensus_traitsOff', 'tables/consensus', { traitsOff: true }],
  ['consensus_shuffled', 'tables/consensus', { tablesMode: 'shuffled' }],
  ['consensus_random', 'tables/consensus', { tablesMode: 'random' }],
  ['rules', 'tables/rules', {}],
  ...FILLS.map(f => [f, 'tables/' + f, {}]),
];

function runCondition(name) {
  const [, dir, extra] = CONDITIONS.find(c => c[0] === name);
  const tables = loadTableDir(dir);
  const runs = [];
  for (const seed of SEEDS) {
    const sim = new Village({ ...DEFAULT_CONFIG, runSeed: seed, n: 20, days: DAYS, tableDir: dir, logDecisions: true, ...extra }, tables);
    sim.run();
    // acts chosen by initiators: event-log rows whose act is a real act (not 'apologise', not night '-')
    const acts = {}; let unkind = 0, total = 0;
    for (let i = 1; i < sim.eventLog.length; i++) {
      const [, , initiator, , act] = sim.eventLog[i].split(',');
      if (act === 'apologise' || act === '-') continue;
      const a = (acts[initiator] ||= { total: 0, unkind: 0 });
      a.total++; total++;
      if (NEGATIVE_ACTS.has(act)) { a.unkind++; unkind++; }
    }
    const last = sim.metrics[sim.metrics.length - 1];
    const moves = { up: 0, down: 0, flip: 0, break: 0 };
    for (const m of sim.metrics) for (const k in moves) moves[k] += m.moves[k];
    runs.push({
      seed, stateHash: sim.stateHash(), logHash: sim.logHash(), missingRows: sim.missingRows,
      friendships: last.friendships, feuds: last.feuds, isolates: last.isolates,
      moves, beliefMoves: moves.up + moves.down + moves.flip + moves.break, breaks: moves.break, flips: moves.flip,
      acts: total, unkindActs: unkind, unkindShare: total ? unkind / total : null,
      villagers: sim.npcs.map(n => ({
        id: n.id,
        positions: PAIRS.map(p => beliefPosition(n.beliefs[p])),
        friends: n.relOrder.filter(o => { const l = n.rel.get(o.num).liking; return l === 'like' || l === 'close'; }).length,
        acts: acts[n.id]?.total ?? 0, unkindActs: acts[n.id]?.unkind ?? 0,
        unkindShare: acts[n.id]?.total ? acts[n.id].unkind / acts[n.id].total : null,
      })),
    });
  }
  mkdirSync(RAW, { recursive: true });
  writeFileSync(join(RAW, name + '.json'), JSON.stringify({ condition: name, tableDir: dir, settings: extra, seeds: SEEDS, days: DAYS, runs }));
  console.log(`${name}: done`);
}

// ---------------------------------------------------------------- statistics
const mean = a => a.reduce((s, x) => s + x, 0) / a.length;
const sd = a => { const m = mean(a); return Math.sqrt(a.reduce((s, x) => s + (x - m) ** 2, 0) / (a.length - 1)); };
const f = (x, d = 3) => x.toFixed(d);

// per-villager spread for a given list of run indices (may repeat, for the bootstrap)
function spread(runs, idx) {
  const V = runs[0].villagers.length;
  let bd = 0, de = 0, sf = 0, su = 0, suCount = 0;
  for (let v = 0; v < V; v++) {
    const pos = idx.map(i => runs[i].villagers[v].positions);
    let dsum = 0, pairs = 0;
    for (let a = 0; a < pos.length; a++) for (let b = a + 1; b < pos.length; b++) {
      dsum += Math.abs(pos[a][0] - pos[b][0]) + Math.abs(pos[a][1] - pos[b][1]) + Math.abs(pos[a][2] - pos[b][2]); pairs++;
    }
    bd += dsum / pairs;
    de += new Set(pos.map(p => p.join(','))).size;
    sf += sd(idx.map(i => runs[i].villagers[v].friends));
    const us = idx.map(i => runs[i].villagers[v].unkindShare).filter(x => x !== null);
    if (us.length >= 2) { su += sd(us); suCount++; }
  }
  return { beliefDistance: bd / V, distinctEndings: de / V, sdFriends: sf / V, sdUnkind: su / suCount };
}

function report() {
  const boot = streamFor('R2:bootstrap'); // same 200 resamples for every condition
  const resamples = Array.from({ length: 200 }, () => SEEDS.map(() => boot.draw(SEEDS.length)));
  const pct = (arr) => { const s = arr.slice().sort((a, b) => a - b); return [s[5], s[194]]; }; // 2.5% / 97.5% of 200
  const lines = [];
  const P = (...l) => { for (const x of l) { lines.push(x); console.log(x); } };
  const summary = {};
  P('# R2 report', '', `Seeds ${SEEDS[0]}–${SEEDS[SEEDS.length - 1]} (50 runs), castSeed 1, n 20, ${DAYS} days, decision and event logs on.`, '');
  P('## 1. Spread of lives (mean over 20 villagers; [95% bootstrap interval, 200 resamples of the 50 seeds])', '');
  P('| Condition | Belief distance | Distinct endings (of 50) | SD friends | SD unkind-act share |', '| --- | --- | --- | --- | --- |');
  const all = {};
  for (const [name] of CONDITIONS) {
    const { runs } = JSON.parse(readFileSync(join(RAW, name + '.json'), 'utf8'));
    all[name] = runs;
    const base = spread(runs, SEEDS.map((_, i) => i));
    const bs = resamples.map(r => spread(runs, r));
    const ci = k => pct(bs.map(b => b[k]));
    const [bl, bh] = ci('beliefDistance'), [fl, fh] = ci('sdFriends'), [ul, uh] = ci('sdUnkind');
    summary[name] = { spread: { ...base, ci: { beliefDistance: [bl, bh], sdFriends: [fl, fh], sdUnkind: [ul, uh] } } };
    P(`| ${name} | ${f(base.beliefDistance)} [${f(bl)}, ${f(bh)}] | ${f(base.distinctEndings, 2)} | ${f(base.sdFriends)} [${f(fl)}, ${f(fh)}] | ${f(base.sdUnkind, 4)} [${f(ul, 4)}, ${f(uh, 4)}] |`);
  }
  P('');
  const MEAS = [['friendships', 2], ['feuds', 2], ['isolates', 2], ['beliefMoves', 1], ['breaks', 2], ['flips', 2], ['unkindShare', 4]];
  P('## 2. Village outcomes (mean ± 95% CI, CI = 1.96 × SD / √50)', '');
  P('| Condition | ' + MEAS.map(m => m[0]).join(' | ') + ' |', '|' + ' --- |'.repeat(MEAS.length + 1));
  const stats = {};
  for (const [name] of CONDITIONS) {
    stats[name] = {};
    const cells = MEAS.map(([k, d]) => {
      const a = all[name].map(r => r[k]);
      const m = mean(a), s = sd(a), ci = 1.96 * s / Math.sqrt(a.length);
      stats[name][k] = { mean: m, ci, sd: s, min: Math.min(...a), max: Math.max(...a) };
      return `${f(m, d)} ± ${f(ci, d)}`;
    });
    summary[name].outcomes = stats[name];
    P(`| ${name} | ${cells.join(' | ')} |`);
  }
  P('', '## 2b. Village outcomes: SD, min, max', '');
  P('| Condition | ' + MEAS.map(m => m[0] + ' SD / min / max').join(' | ') + ' |', '|' + ' --- |'.repeat(MEAS.length + 1));
  for (const [name] of CONDITIONS) {
    P(`| ${name} | ` + MEAS.map(([k, d]) => { const s = stats[name][k]; return `${f(s.sd, d)} / ${f(s.min, d)} / ${f(s.max, d)}`; }).join(' | ') + ' |');
  }
  P('');
  // reference hashes for reproducibility
  P('## Reference hashes (seed 101 of each condition)', '');
  for (const [name] of CONDITIONS) { const r = all[name][0]; P(`- ${name}: state \`${r.stateHash}\`, log \`${r.logHash}\`, missingRows ${r.missingRows}`); }
  writeFileSync(join(here, 'results', 'R2', 'report.md'), lines.join('\n') + '\n');
  writeFileSync(join(here, 'results', 'R2', 'summary.json'), JSON.stringify(summary, null, 1));
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const a = process.argv.slice(2);
  if (a[0] === '--run') runCondition(a[1]);
  else if (a[0] === '--report') report();
  else { for (const [n] of CONDITIONS) if (!existsSync(join(RAW, n + '.json'))) runCondition(n); report(); }
}
