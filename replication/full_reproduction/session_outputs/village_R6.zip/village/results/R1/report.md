# R1 report

## 1. Import and validation

| Fill | Data rows | Missing | Illegal / validation errors | Other problems | Cells cleaned |
| --- | --- | --- | --- | --- | --- |
| opusnormal_r1 | 240 | 0 | 0 | 0 | 0 |
| opusnormal_r2 | 240 | 0 | 0 | 0 | 0 |
| opusblind_r1 | 240 | 0 | 0 | 0 | 0 |
| opusblind_r2 | 240 | 0 | 0 | 0 | 0 |
| gemini_r1 | 240 | 0 | 0 | 0 | 14 |
| gemini_r2 | 240 | 0 | 0 | 0 | 13 |
| chatgpt_r1 | 240 | 0 | 0 | 0 | 0 |
| chatgpt_r2 | 240 | 0 | 0 | 0 | 0 |
| dev_r1 | 240 | 0 | 0 | 0 | 0 |

- gemini_r1 clean-up: "1" → "+1" ×14 (rows: T12-02 T12-03 T12-06 T12-08 T12-09 T12-13 T12-14 T12-15)
- gemini_r2 clean-up: "1" → "+1" ×13 (rows: T12-02 T12-03 T12-08 T12-09 T12-13 T12-14 T12-15)

## 2. Self-consistency (run 1 vs run 2)

| Arm | Rows identical | Share | Cells identical | Share |
| --- | --- | --- | --- | --- |
| opusnormal | 207/240 | 0.8625 | 496/537 | 0.9236 |
| opusblind | 205/240 | 0.8542 | 495/537 | 0.9218 |
| gemini | 218/240 | 0.9083 | 508/537 | 0.9460 |
| chatgpt | 159/240 | 0.6625 | 443/537 | 0.8250 |

## 3. Agreement between arms (mean of 4 cross pairs)

| Arm pair | Mean rows identical | Share | Mean cells identical | Share |
| --- | --- | --- | --- | --- |
| opusnormal vs opusblind | 204.25 | 0.8510 | 486.75 | 0.9064 |
| opusnormal vs gemini | 182.00 | 0.7583 | 460.75 | 0.8580 |
| opusnormal vs chatgpt | 152.00 | 0.6333 | 404.50 | 0.7533 |
| opusblind vs gemini | 180.00 | 0.7500 | 455.75 | 0.8487 |
| opusblind vs chatgpt | 151.25 | 0.6302 | 411.25 | 0.7658 |
| gemini vs chatgpt | 154.75 | 0.6448 | 416.25 | 0.7751 |

## 4. Agreement across all eight blind fills

| Measure | Count | Share |
| --- | --- | --- |
| Rows where all 8 identical | 104/240 | 0.4333 |
| Rows where ≥ 6 of 8 give the identical whole row | 178/240 | 0.7417 |
| Answer cells where all 8 agree | 323/537 | 0.6015 |

Per table: share of rows a single blind fill shares with the consensus (lowest / highest over the 8 fills):

| Table | Rows | Lowest | Highest | Lowest fill | Highest fill |
| --- | --- | --- | --- | --- | --- |
| T2 | 27 | 20/27 = 0.7407 | 27/27 = 1.0000 | chatgpt_r1, chatgpt_r2 | opusnormal_r1 |
| T3 | 36 | 29/36 = 0.8056 | 36/36 = 1.0000 | chatgpt_r2 | opusnormal_r2, opusblind_r1 |
| T4 | 24 | 11/24 = 0.4583 | 20/24 = 0.8333 | chatgpt_r1 | opusblind_r2 |
| T5 | 9 | 8/9 = 0.8889 | 9/9 = 1.0000 | opusnormal_r2, opusblind_r1, opusblind_r2, chatgpt_r1 | opusnormal_r1, gemini_r1, gemini_r2, chatgpt_r2 |
| T6 | 36 | 20/36 = 0.5556 | 34/36 = 0.9444 | chatgpt_r1 | opusblind_r2 |
| T7 | 54 | 30/54 = 0.5556 | 46/54 = 0.8519 | chatgpt_r1 | gemini_r2 |
| T8 | 12 | 5/12 = 0.4167 | 12/12 = 1.0000 | chatgpt_r1 | gemini_r2 |
| T9 | 12 | 11/12 = 0.9167 | 12/12 = 1.0000 | opusnormal_r1, opusnormal_r2, opusblind_r1 | opusblind_r2, gemini_r1, gemini_r2, chatgpt_r1, chatgpt_r2 |
| T10 | 12 | 9/12 = 0.7500 | 12/12 = 1.0000 | chatgpt_r1, chatgpt_r2 | opusblind_r2 |
| T12 | 18 | 11/18 = 0.6111 | 16/18 = 0.8889 | gemini_r1, gemini_r2, chatgpt_r1, chatgpt_r2 | opusnormal_r1, opusnormal_r2 |

## 5. Consensus

Validation of tables/consensus: pass

Ties: 27

- T2 eat|mid|low second: tied {home, field} ×4 → home (vocab order)
- T4 friendly|field|low first: tied {help, chat} ×4 → help (rule)
- T4 friendly|square|high first: tied {chat, share food} ×4 → chat (vocab order)
- T4 neutral|field|low second: tied {take credit, chat} ×4 → chat (vocab order)
- T6 argued with|people mean well|held meaning: tied {slight, insult} ×4 → slight (rule)
- T6 argued with|people mean well|core pressure: tied {same, strained} ×4 → strained (rule)
- T6 interrupted|people mean well|held meaning: tied {nothing much, slight} ×4 → slight (rule)
- T6 apologised to|people are against me|held meaning: tied {nothing much, good sign} ×4 → nothing much (rule)
- T6 apologised to|people are against me|held liking_change: tied {same, up} ×4 → same (rule)
- T7 praised|i am respected|held|high meaning: tied {nothing much, good sign} ×4 → good sign (rule)
- T7 praised|i am respected|held|high pressure: tied {same, stronger} ×4 → stronger (rule)
- T7 praised|i am overlooked|held|high liking_change: tied {same, up} ×4 → same (rule)
- T7 praised|i am overlooked|core|low meaning: tied {good sign, nothing much} ×4 → nothing much (rule)
- T7 praised|i am overlooked|core|high meaning: tied {nothing much, good sign} ×3 → nothing much (rule)
- T7 praised|i am overlooked|core|high pressure: tied {same, strained} ×4 → strained (rule)
- T7 ignored|i am respected|faint|low pressure: tied {same, weaker} ×4 → weaker (rule)
- T7 ignored|i am respected|held|mid pressure: tied {same, weaker} ×4 → weaker (rule)
- T7 ignored|i am overlooked|core|low meaning: tied {nothing much, slight} ×4 → slight (rule)
- T7 credit taken|i am respected|held|low pressure: tied {same, weaker} ×4 → weaker (rule)
- T8 work went well|nothing i do matters|core pressure: tied {same, strained} ×4 → strained (rule)
- T8 work went badly|hard work pays off|held pressure: tied {same, weaker} ×4 → weaker (rule)
- T8 work went badly|hard work pays off|core pressure: tied {same, strained} ×4 → strained (rule)
- T10 low|slight|none response: tied {cool off, hold grudge} ×4 → hold grudge (rule)
- T12 people mean well|held sociability: tied {0, +1} ×4 → 0 (rule)
- T12 hard work pays off|faint diligence: tied {0, +1} ×4 → 0 (rule)
- T12 nothing i do matters|faint diligence: tied {0, -1} ×4 → 0 (rule)
- T12 nothing i do matters|core warmth: tied {0, -1} ×4 → 0 (rule)

| Table | SHA-256 (consensus set) |
| --- | --- |
| T1 | `d33f0bdbab3a03428d5b88321763cb091c6338d96b87cb41c81e162ad934b661` |
| T2 | `fcd8f71c896afcbf4fbdec438a35059cb298793456cefb4362eef829b04e6226` |
| T3 | `caa727c230ce12dc0678a4fff922b3094b024a10a4d82cca1c1111dd52adf0ff` |
| T4 | `e7526674049ad995145b9a57fd532a03c56c373ffec5fa7b85ee94957e28f67b` |
| T5 | `34e037c36a548c2efda3be4142bd78c5f66531e9262f2ad0f403f997f4fb01dd` |
| T6 | `084e3ccca3ecd7c98b383ecbb027f81b631401c58b4a305168ef07b3167f4b9c` |
| T7 | `f6167ebde48e2fcb3644e40831c940a5452db9dc44bc006c38e70ebcd41425ca` |
| T8 | `e908987480fffa5f1491c2e1882d66a79c45480a86fb42b5e8851711c517ebd9` |
| T9 | `4a45387bd88c13bd56adf1d20e08edd458f83ca8a4f4777da5a4cdfa40597cdc` |
| T10 | `0be3057e79f327412f08599681397ce64bbdd9eed372a5e1671a307b9d77d437` |
| T11 | `c9a13b45b5ca54f8e9196047c68e4b82fff2991f6e93bdae1c644c32de4ed960` |
| T12 | `29954282a22af131feb3e63532c3325de14e307222fc14be9453c56c059d546b` |

runSeed 1, n 20, days 30, consensus tables: state `78bc903eab79f6a1c06e70c9619038a31245dac3647c0315f55f0dabcc2f32a2`, log `d707fc920c92d87fa6cdeff4b0f552b89dc37d1ae7c819c7d57b3a79d45735b9`, missingRows 0

## 6. Distance from the rule tables

| Fill | Rows identical to rule tables | Share | Cells identical to rule tables | Share |
| --- | --- | --- | --- | --- |
| opusnormal_r1 | 136/240 | 0.5667 | 398/537 | 0.7412 |
| opusnormal_r2 | 133/240 | 0.5542 | 396/537 | 0.7374 |
| opusblind_r1 | 132/240 | 0.5500 | 394/537 | 0.7337 |
| opusblind_r2 | 137/240 | 0.5708 | 399/537 | 0.7430 |
| gemini_r1 | 148/240 | 0.6167 | 416/537 | 0.7747 |
| gemini_r2 | 152/240 | 0.6333 | 423/537 | 0.7877 |
| chatgpt_r1 | 135/240 | 0.5625 | 394/537 | 0.7337 |
| chatgpt_r2 | 133/240 | 0.5542 | 386/537 | 0.7188 |
| dev_r1 | 159/240 | 0.6625 | 424/537 | 0.7896 |
| consensus | 149/240 | 0.6208 | 421/537 | 0.7840 |

dev_r1 vs consensus: rows identical 180/240 = 0.7500; cells identical 454/537 = 0.8454

## 7. Noise vs temperament

| Table.column | Cells | Stable | Noise | Temperament |
| --- | --- | --- | --- | --- |
| T2.first | 27 | 26 | 1 | 0 |
| T2.second | 27 | 13 | 9 | 5 |
| T3.stance | 36 | 24 | 8 | 4 |
| T4.first | 24 | 14 | 2 | 8 |
| T4.second | 24 | 3 | 14 | 7 |
| T5.decision | 9 | 6 | 3 | 0 |
| T6.meaning | 36 | 18 | 7 | 11 |
| T6.pressure | 36 | 25 | 6 | 5 |
| T6.liking_change | 36 | 21 | 7 | 8 |
| T7.meaning | 54 | 19 | 17 | 18 |
| T7.pressure | 54 | 31 | 11 | 12 |
| T7.liking_change | 54 | 38 | 3 | 13 |
| T8.meaning | 12 | 5 | 6 | 1 |
| T8.pressure | 12 | 9 | 0 | 3 |
| T9.new_mood | 12 | 11 | 0 | 1 |
| T10.response | 12 | 7 | 3 | 2 |
| T12.warmth | 18 | 14 | 1 | 3 |
| T12.sociability | 18 | 14 | 2 | 2 |
| T12.diligence | 18 | 14 | 0 | 4 |
| T12.pride | 18 | 11 | 4 | 3 |
| **All** | 537 | 323 | 104 | 110 |

## 8. Weighting by real use (consensus tables, seeds 1–20, n 20, 30 days)

Total look-ups: 709562

| Table | Look-ups | Share |
| --- | --- | --- |
| T1 | 192000 | 0.2706 |
| T2 | 191945 | 0.2705 |
| T3 | 56126 | 0.0791 |
| T4 | 56367 | 0.0794 |
| T5 | 9069 | 0.0128 |
| T6 | 47226 | 0.0666 |
| T7 | 9195 | 0.0130 |
| T8 | 7253 | 0.0102 |
| T9 | 63674 | 0.0897 |
| T10 | 3507 | 0.0049 |
| T11 | 36000 | 0.0507 |
| T12 | 37200 | 0.0524 |

Teacher-table rows looked up at least once: 216/240

| Fill | Weighted differing cells | Weighted cells | Share of real decisions differing from consensus |
| --- | --- | --- | --- |
| opusnormal_r1 | 65482 | 713257 | 0.0918 |
| opusnormal_r2 | 49086 | 713257 | 0.0688 |
| opusblind_r1 | 43115 | 713257 | 0.0604 |
| opusblind_r2 | 16340 | 713257 | 0.0229 |
| gemini_r1 | 67765 | 713257 | 0.0950 |
| gemini_r2 | 72401 | 713257 | 0.1015 |
| chatgpt_r1 | 94937 | 713257 | 0.1331 |
| chatgpt_r2 | 65970 | 713257 | 0.0925 |
| dev_r1 | 72719 | 713257 | 0.1020 |

Usage-weighted chance that a randomly chosen blind fill differs from the consensus:

| Table.column | Weight | P(differs) |
| --- | --- | --- |
| T2.first | 144304 | 0.0049 |
| T2.second | 47641 | 0.1514 |
| T3.stance | 56126 | 0.0438 |
| T4.first | 42309 | 0.3141 |
| T4.second | 14058 | 0.3268 |
| T5.decision | 9069 | 0.0223 |
| T6.meaning | 47226 | 0.0802 |
| T6.pressure | 47226 | 0.0489 |
| T6.liking_change | 47226 | 0.1931 |
| T7.meaning | 9195 | 0.1381 |
| T7.pressure | 9195 | 0.0459 |
| T7.liking_change | 9195 | 0.0777 |
| T8.meaning | 7253 | 0.1119 |
| T8.pressure | 7253 | 0.0858 |
| T9.new_mood | 63674 | 0.0208 |
| T10.response | 3507 | 0.0781 |
| T12.warmth | 37200 | 0.0390 |
| T12.sociability | 37200 | 0.0911 |
| T12.diligence | 37200 | 0.1020 |
| T12.pride | 37200 | 0.0437 |

## 9. T6, belief "people are against me", tier core

| Fill | helped: meaning | helped: pressure | apologised to: meaning | apologised to: pressure |
| --- | --- | --- | --- | --- |
| opusnormal_r1 | nothing much | same | nothing much | same |
| opusnormal_r2 | nothing much | same | nothing much | same |
| opusblind_r1 | nothing much | same | nothing much | same |
| opusblind_r2 | nothing much | same | nothing much | same |
| gemini_r1 | nothing much | same | nothing much | same |
| gemini_r2 | nothing much | same | nothing much | same |
| chatgpt_r1 | good sign | strained | good sign | strained |
| chatgpt_r2 | good sign | strained | good sign | strained |
| dev_r1 | nothing much | same | nothing much | same |
| consensus | nothing much | same | nothing much | same |
| rule tables | nothing much | strained | nothing much | strained |

