# R3 report

## Part A: decision traces (consensus, seed 101, n 20, 60 days)

Run check: state `99a59233d6fd7fef91ece19ef5d79865b2017c076692c0f2badba0a0fe63fcfe`, log `2caaaf7b0cab79a545a451e6ed82efe110a921576155f57e8a73963490e68c48`, missingRows 0

Encounters taken as an insult in this run: 304. First three:

### Insult 1: tick 7 (day 0, hour 7), field: n0017 → n0020, act `take credit` (event `credit taken`, meaning insult, pressure strained, liking change down)

| # | Who | Role | Table | Inputs | Output | Option used |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | n0017 | initiator | T1 | food=fed, energy=tired | need=none | - |
| 2 | n0020 | receiver | T1 | food=fed, energy=tired | need=none | - |
| 3 | n0017 | initiator | T2 | need=none, diligence=mid, sociability=low | first=field, second=home | first → field |
| 4 | n0020 | receiver | T2 | need=none, diligence=mid, sociability=mid | first=field, second=square | first → field |
| 5 | n0017 | initiator | T3 | warmth=high, liking=neutral, mood=calm | stance=friendly | - |
| 6 | n0017 | initiator | T4 | stance=friendly, room=field, honesty=low | first=help, second=take credit | second → take credit |
| 7 | n0020 | receiver | T7 | event=credit taken, belief=i am respected, tier=core, pride=high | meaning=insult, pressure=strained, liking_change=down | - |
| 8 | n0020 | receiver | T9 | mood=good, meaning=insult | new_mood=low | - |
| 9 | n0020 | receiver | T10 | warmth=mid, offence=insult, apology=none | response=hold grudge | - |

### Insult 2: tick 17 (day 1, hour 1), field: n0017 → n0012, act `take credit` (event `credit taken`, meaning insult, pressure weaker, liking change down)

| # | Who | Role | Table | Inputs | Output | Option used |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | n0012 | receiver | T1 | food=hungry, energy=rested | need=none | - |
| 2 | n0017 | initiator | T1 | food=hungry, energy=rested | need=none | - |
| 3 | n0012 | receiver | T2 | need=none, diligence=high, sociability=low | first=field, second=field | second → field |
| 4 | n0017 | initiator | T2 | need=none, diligence=mid, sociability=low | first=field, second=home | first → field |
| 5 | n0017 | initiator | T3 | warmth=high, liking=neutral, mood=calm | stance=friendly | - |
| 6 | n0017 | initiator | T4 | stance=friendly, room=field, honesty=low | first=help, second=take credit | second → take credit |
| 7 | n0012 | receiver | T7 | event=credit taken, belief=i am respected, tier=faint, pride=mid | meaning=insult, pressure=weaker, liking_change=down | - |
| 8 | n0012 | receiver | T9 | mood=calm, meaning=insult | new_mood=low | - |
| 9 | n0012 | receiver | T10 | warmth=mid, offence=insult, apology=none | response=hold grudge | - |

### Insult 3: tick 20 (day 1, hour 4), field: n0017 → n0003, act `take credit` (event `credit taken`, meaning insult, pressure stronger, liking change down)

| # | Who | Role | Table | Inputs | Output | Option used |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | n0003 | receiver | T1 | food=hungry, energy=rested | need=none | - |
| 2 | n0017 | initiator | T1 | food=hungry, energy=rested | need=none | - |
| 3 | n0003 | receiver | T2 | need=none, diligence=low, sociability=low | first=home, second=field | second → field |
| 4 | n0017 | initiator | T2 | need=none, diligence=mid, sociability=low | first=field, second=home | first → field |
| 5 | n0017 | initiator | T3 | warmth=high, liking=neutral, mood=good | stance=friendly | - |
| 6 | n0017 | initiator | T4 | stance=friendly, room=field, honesty=low | first=help, second=take credit | second → take credit |
| 7 | n0003 | receiver | T7 | event=credit taken, belief=i am overlooked, tier=held, pride=mid | meaning=insult, pressure=stronger, liking_change=down | - |
| 8 | n0003 | receiver | T9 | mood=calm, meaning=insult | new_mood=low | - |
| 9 | n0003 | receiver | T10 | warmth=high, offence=insult, apology=none | response=cool off | - |

## Part B: one-row edit of T4, 50 paired runs (seeds 101–150, n 20, 60 days)

Edit: `friendly,field,low,help,take credit` → `friendly,field,low,help,chat`. Table files changed: T4; lines changed in T4: 1.
T4 table hash (as loaded) original `e7526674049ad995145b9a57fd532a03c56c373ffec5fa7b85ee94957e28f67b`, edited `c1171b6ad5a5975a4cea2e8abe7fb2257524601a6621f905f8a5a8c684ecc9c8`.
Check: 50/50 original runs match R2 consensus (state hash, friendships, feuds, belief moves, unkind share).

| Measure | Mean original | Mean edited | Paired change ± 95% CI | SD original (seed to seed) | Change / SD |
| --- | --- | --- | --- | --- | --- |
| Targeted uses (T4 friendly|field|low, second option) | 277.96 | 335.42 | 57.46 ± 7.55 | 18.37 | 3.13 |
| Credit-taking events | 359.52 | 0.00 | -359.52 ± 8.82 | 31.81 | -11.30 |
| Unkind-act share | 0.0715 | 0.0027 | -0.0688 ± 0.0020 | 0.0071 | -9.74 |
| Belief changes (applied moves) | 210.48 | 150.94 | -59.54 ± 4.21 | 11.56 | -5.15 |
| Friendships (last day) | 96.18 | 110.64 | 14.46 ± 2.05 | 5.95 | 2.43 |
| Feuds (last day) | 3.80 | 0.00 | -3.80 ± 0.49 | 1.77 | -2.14 |
| Field hours (T2 → field) | 6469.4 | 6195.7 | -273.7 ± 59.9 | 170.1 | -1.61 |
| Days worked (night work events) | 706.7 | 686.8 | -19.8 ± 6.9 | 20.2 | -0.98 |
| Share of good work days | 0.5692 | 0.5701 | 0.0009 ± 0.0031 | 0.0196 | 0.05 |
| Hunger events (T1 → eat / eat now) | 3382.1 | 3410.5 | 28.5 ± 7.5 | 34.2 | 0.83 |

Pairs with identical final state: 0/50. Seeds where the original run never used the targeted option: 0/50.
Targeted row look-ups (either option), mean original 1136.58, edited 1370.44.
T4 look-ups that chose `take credit`, mean per run by row:option (original): friendly|field|low:second 277.96; cold|field|low:first 56.94; hostile|field|low:first 22.96; hostile|field|mid:second 1.66.
T4 look-ups that chose `take credit`, mean per run by row:option (edited): none.
Reference: seed 101 original state `99a59233d6fd7fef91ece19ef5d79865b2017c076692c0f2badba0a0fe63fcfe`, edited state `c1c36017acc1cf9a280a46bd39cb256d90e97baa5d20b2b2aca48e150098b977`.
