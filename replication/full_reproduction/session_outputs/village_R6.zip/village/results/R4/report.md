# R4 report

Consensus tables, n 20, 60 days, seeds 101–130 (30 seeds), logs on. One setting changed at a time.

Fingerprint check: 90/90 spec-default runs (loop on, loop off, shuffled) have the same state and log hashes as the R2 runs.

## Main table

| Variant | SD friends on / off | Friendships on / off | Feuds on / off | Unkind share consensus / shuffled | C1 | C2 | C3 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| spec defaults | 1.693 / 1.142 | 97.33 / 81.10 | 3.93 / 5.83 | 0.0714 / 0.4305 | yes | yes | yes |
| backup choice 15% | 1.715 / 1.085 | 82.80 / 75.77 | 1.83 / 2.43 | 0.0501 / 0.4071 | yes | yes | yes |
| backup choice 35% | 1.712 / 1.003 | 99.57 / 77.00 | 6.00 / 8.97 | 0.0923 / 0.4470 | yes | yes | yes |
| liking step 2 | 1.540 / 1.032 | 113.73 / 93.77 | 6.47 / 9.43 | 0.0855 / 0.4284 | yes | yes | yes |
| liking step 4 | 1.756 / 1.075 | 78.03 / 69.40 | 2.90 / 3.63 | 0.0662 / 0.4266 | yes | yes | yes |
| evidence window 5 days | 1.703 / 1.142 | 99.37 / 81.10 | 4.53 / 5.83 | 0.0752 / 0.4273 | yes | yes | yes |
| evidence window 10 days | 1.658 / 1.142 | 95.33 / 81.10 | 3.90 / 5.83 | 0.0720 / 0.4276 | yes | yes | yes |
| evidence thresholds looser | 1.652 / 1.142 | 87.63 / 81.10 | 4.40 / 5.83 | 0.0726 / 0.4364 | yes | yes | yes |
| evidence thresholds stricter | 1.647 / 1.142 | 103.47 / 81.10 | 3.97 / 5.83 | 0.0744 / 0.4196 | yes | yes | yes |
| hunger 4 per hour | 1.736 / 0.997 | 99.97 / 84.70 | 4.30 / 6.27 | 0.0734 / 0.4318 | yes | yes | yes |
| hunger 6 per hour | 1.773 / 1.132 | 94.03 / 81.37 | 3.10 / 5.80 | 0.0693 / 0.4258 | yes | yes | yes |

## Supplementary: margins (not asked for)

| Variant | SD friends on − off | Friendships on − off (paired, ± 95% CI) | Feuds on − off (paired, ± 95% CI) | Unkind shuffled / consensus | missingRows (all runs) |
| --- | --- | --- | --- | --- | --- |
| spec defaults | 0.551 | 16.23 ± 2.40 | -1.90 ± 0.90 | 6.03 | 0 |
| backup choice 15% | 0.630 | 7.03 ± 2.97 | -0.60 ± 0.66 | 8.12 | 0 |
| backup choice 35% | 0.709 | 22.57 ± 2.65 | -2.97 ± 1.03 | 4.84 | 0 |
| liking step 2 | 0.508 | 19.97 ± 3.03 | -2.97 ± 0.86 | 5.01 | 0 |
| liking step 4 | 0.680 | 8.63 ± 2.31 | -0.73 ± 0.76 | 6.45 | 0 |
| evidence window 5 days | 0.561 | 18.27 ± 2.45 | -1.30 ± 0.92 | 5.69 | 0 |
| evidence window 10 days | 0.515 | 14.23 ± 2.82 | -1.93 ± 0.75 | 5.94 | 0 |
| evidence thresholds looser | 0.510 | 6.53 ± 2.50 | -1.43 ± 0.89 | 6.01 | 0 |
| evidence thresholds stricter | 0.505 | 22.37 ± 2.36 | -1.87 ± 0.81 | 5.64 | 0 |
| hunger 4 per hour | 0.740 | 15.27 ± 2.99 | -1.97 ± 0.86 | 5.88 | 0 |
| hunger 6 per hour | 0.641 | 12.67 ± 1.79 | -2.70 ± 0.96 | 6.15 | 0 |

## Reference hashes (seed 101, loop on)

- spec defaults: state `99a59233d6fd7fef91ece19ef5d79865b2017c076692c0f2badba0a0fe63fcfe`, log `2caaaf7b0cab79a545a451e6ed82efe110a921576155f57e8a73963490e68c48`
- backup choice 15%: state `9610733d27e3860c9d330eed523a685da943b5018012bf27766ab063e3cb1309`, log `5023c4bcb326a30070c8f9fe2aba9ceb891e80f97cecc2c1b77e5e7e38ba1849`
- backup choice 35%: state `6c41a2283bdacf2f1c5ae9e23087d1a72a6f8eb719e1296861616870fdc80657`, log `922b0af605c38439c6922aeca60eb092cecacbed9d101cf75edc90106dfba7aa`
- liking step 2: state `a7cbd2ad86c5611602afe360cb1b4adc8f87ba0b239f100715948d4356f23b83`, log `1baf5ad298ee2f7a403bbe57a7dfb171a5d4f772cba93d2e2ea7964216d95242`
- liking step 4: state `2b9859e5b53797638133d53622aee35cdba51d84a7c0e20ea89b1f40316f308a`, log `c29421f3d11c0b294925358aba6f9c6b0af14ae24c551e620b1ed213df3263e1`
- evidence window 5 days: state `9262b3e03a0ba36705d141ac01440d07427626cff813aa1a5fe155a796bd2aca`, log `ad352b72fe31c847f4fa8b9ca8d9b69a3f7c67090ca447da59cf3db96b6d426c`
- evidence window 10 days: state `dd9b732abe761af9df20d533b89c3d8ff9208494743e4afcc97ecc273b1edf1e`, log `48a00d011557fcedef70eef87d5abcb71a8992891bc89d502bbd05d0288c8cca`
- evidence thresholds looser: state `d2c4d3f6f0b8e634300c3c991bbc539534c4f4d9cfd0f6bdc220cbeb2f886246`, log `692563bb3b07357141091eee30176abb2adcf86aeaf74abe59edb99a0715fff1`
- evidence thresholds stricter: state `a2337fcda95ca59b438a50460c35ae577210048138b6b50e7bac727c5a0ecc5b`, log `1e5c21b1b52019cee9d17bc8ee95adb652045d265962b3c48b618a955d259cbd`
- hunger 4 per hour: state `72a7931699382263ae41c0c9cf7bdcf94d89e957777ae5c25af143a1d29c5196`, log `0d4bfb3da99dbe2e0f84a6654955b01731a25c4eda729f3db0bea0b82b3b5f5a`
- hunger 6 per hour: state `31c68d97e10b9692fc807d6713d0a451c21b4a927c2df87ac1ba587adc969ed6`, log `238d4d8edd512376cca8c72809abbe0a70dc4215177338693c7c7c46f980dfe4`
