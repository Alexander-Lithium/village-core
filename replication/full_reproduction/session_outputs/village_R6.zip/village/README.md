# Village Core v1.0

A small, deterministic, agent-based village simulation (research testbed). Pure ES modules with no dependencies, so it runs in Node ≥ 18 and in modern browsers.

## How to run

```
node gen_cast.js          # writes cast/cast_s1_n20.csv
node gen_rule_tables.js   # writes tables/rules/T1..T12 (normalised form)
node test.js              # acceptance tests + golden hashes
node build_viewer.js      # writes viewer.html (open it in a browser, no network needed)

node run.js --runSeed 1 --n 20 --days 30 --tableDir tables/rules --out results/A
node run.js --runSeed 1 --n 20 --days 30 --seeds 1-100 --out results/batch
```

`run.js` options: `--runSeed --castSeed --n --days --hamletSize --pSecond --tableDir --tablesMode csv|shuffled|random --loopOff --traitsOff --skipValidation --logDecisions false --seeds a-b --out dir`.
It prints the state hash, log hash, missingRows and ms/tick. With `--out` it writes `summary.json`, `snapshots.json`, `decisions.csv` and `events.csv` (the logs are only written when decision logging is on). With `--seeds` it writes one folder per seed plus `final_metrics.csv`.

## Files

| File | Purpose |
| --- | --- |
| `engine.js` | Engine (`Village` class), vocabulary, table definitions, loader and validator, RNG, cast generator. |
| `sha256.js` | Pure-JS SHA-256 over UTF-8. |
| `gen_rule_tables.js` | Rule baseline (A6.1) → `tables/rules/*.csv`. |
| `gen_cast.js` | `cast/cast_s1_n20.csv`. |
| `run.js` | CLI batch runner. Also exports `loadTableDir` and `runOnce`. |
| `test.js` | Acceptance tests A15.1–11 (plus test 0, a SHA-256 known-answer check). |
| `build_viewer.js` / `viewer.html` | Self-contained viewer. |
| `results/A`…`results/I` | Outputs of the R0 reference runs. |

## File formats

- **Tables:** `tables/<set>/T*_*.csv`, headers exactly as in A6.0b. They are written in normalised form: header, then rows sorted by key (`|`-joined inputs, UTF-16 order), with `\n` after every line. Table hash = SHA-256 of that normalised text.
- **Cast:** `id,warmth,sociability,diligence,honesty,pride,flexibility,trust_pole,trust_tier,worth_pole,worth_tier,effort_pole,effort_tier`. Pole columns hold the full belief text (e.g. `people are against me`).
- **Decision log:** `tick,npc,table,key,output,choice` (A12). Log hash = SHA-256 of the header plus all lines, each followed by `\n`.
- **Event log:** `tick,room,initiator,receiver,act,event,meaning,pressure,likingChange`. For an apology, act = `apologise`. For a night work outcome, tick = `night<day>`, room / initiator / act / likingChange = `-`. `likingChange` is the table's output, before grudge modifiers.
- **summary.json:** `config`, `castHash`, `tableHashes` (the tables as loaded), `effectiveTableHashes` (only for shuffled/random: the tables after the transform), `missingRows` (count), `missingKeys` (`table:key` → count), `stateHash`, `logHash`, `dailyMetrics`, `timing`.
- **dailyMetrics[d]:** `events` (counts including night work outcomes), `moods` (end of hour 15), `positions[pair]` = counts at positions `[-3,-2,-1,+1,+2,+3]` after the night, `moves` (up/down/flip/break), `friendships`, `feuds`, `isolates`.
- **snapshots.json:** per day, per NPC: `positions` (trust, worth, effort), `eff` (warmth, sociability, diligence, pride) after the night, `mood` at the end of hour 15, plus the list of `moves` applied.

## Golden hashes (from `test.js`)

| Run | State hash | Log hash |
| --- | --- | --- |
| runSeed 1, n 20, days 30, rule tables | `f64386a9c686111ad2818b5dd48412efa7f727864a2721ec5d2c843475a76d75` | `7b862fb6ba29eccacde6d9a18f4b835e52267a73b863698cb0c26eaa218d48d9` |
| runSeed 1, n 5, days 3, rule tables | `7ae5d3c79d87a1d26ec9cb79851774a5df533b2d5ee32ac6b3818f9f2b06fa1c` | `40733d27d403624584d42e743542331d1b15eadd4b6abc1e4b7dffe7bc96b204` |

Cast hash (`cast_s1_n20.csv`): `89d3b47eff3c1ef57122b363aaad969fa0c7fc348367821a3572782801da885b`

## Builder decisions

1. **Step-wise ticks.** Each numbered step of A10 and A11 runs over all NPCs (id ascending) before the next step starts. Lookups are logged in exactly that order, at the moment they happen.
2. **Draws.** A `room` draw is consumed only when T2 is actually looked up (not for `eat now` / `rest now`). An `act` draw is consumed only when T4 is looked up (not when an apology replaces the act). The `meet` stream does the Fisher–Yates shuffle of a room, then one `draw(2)` per pair as each pair is processed. The two-option rule is `draw(100) < pSecond` → `second`.
3. **Cast.** The engine generates the cast from `castSeed` for any n. The first n rows are identical to `cast_s1_n20.csv`, and the cast hash is the hash of the CSV for exactly those n rows (so the n = 5 cast hash covers 5 rows). The viewer passes the shipped CSV for n ≤ 20. Pole columns hold the full belief text.
4. **Liking change (A10.6).** Resolved in this order, using R's grudge toward I *before* this event updates it. (a) Grudge `cool off` and change `same` or `up` → −1. (b) Otherwise `up` → +1, or 0 under `hold grudge` / `pay back`. (c) `down` → −1. (d) `same` → 0. The counter only changes, and the counter rule (A10.7) only runs, when the delta is not 0. The rule runs immediately.
5. **Offence and apology bullets** run in the order listed. If an `apologised to` event gets a `slight` / `insult` meaning (impossible under the rule tables), the offence is first set to that meaning, then resolved by the apology bullet.
6. **Worked beside** is set for every field encounter, including ones that turn into an apology.
7. **Pay back:** stance `hostile` with no T3 lookup (so nothing is logged for T3). T4 is still looked up and logged.
8. **Night work outcomes** use T8 and T9, are logged with tick `night<day>` (day 0-based), and do not set `gotEvent`, which is reset at the next tick anyway.
9. **Moves "applied"** (snapshot list and `moves` metric) = moves that changed the belief. Lookups that return `stay`, or a move that doesn't apply (A7), are not counted. All T11 lookups are still logged.
10. **Initial compile** runs even with `loopOff`. `loopOff` skips night steps 2 and 3 only (so buffers stay empty).
11. **traitsOff** sets all six temperament traits, including honesty and flexibility, to `mid`.
12. **Validation** enforces the full A3 pressure constraint: at `core` only `same` / `strained`; at `faint` / `held` only `stronger` / `same` / `weaker`. This is slightly stricter than the A6.0 wording (it also rejects `weaker` at core). It also rejects a bad header, wrong column counts, duplicates, missing or extra rows, out-of-vocabulary values and T4 acts not allowed in the row's room.
13. **missingRows** = the total number of lookups that fell back to a default. `missingKeys` gives the count per key. The T9 default is the current mood.
14. **Table hashes.** `tableHashes` are the hashes of the loaded CSVs (normalised). For `shuffled` / `random` the summary also gives `effectiveTableHashes` after the transform.
15. **Metrics.** Friendships and feuds are counted per unordered pair. Isolate = NPC with no `like` / `close` toward anyone and none toward it. Daily event counts include night work outcomes and apologies.
16. **logDecisions false** also turns off the event log. The log hash is then `-`.
17. **Timing** is `performance.now()` around each tick (the night is included in the hour-15 tick). `msPerTick` = total / waking ticks. It is never used in decisions.
18. **Starving-run tracking** (for test 8) counts consecutive waking ticks in which the food tier at the needs step is `starving`. It is instrumentation only and not part of the state.
19. **Test choices.** Test 4 changes T4 `neutral|square|mid` to `argue/argue` and compares day-0 encounters (tick, room, initiator, receiver). Test 7 deletes T3 `low|neutral|calm` (rule output `cold`, so the default `neutral` is visibly different). Test 8 checks runSeeds 1–5. Test 5 compares the last day's positions with both the starting positions and the day-0 snapshot.
20. **Viewer.** The n selector also offers 100 / 1000 / 10000. Decision logging is off in the viewer above n = 1000. Hashes are computed on Run or with "Compute hashes".

## R1: teacher fills and consensus

`node analyze_r1.js` imports `teacher_replies/*.txt` (unedited) into `tables/<fill>/`. T1 and T11 are copied from `tables/rules`. It builds `tables/consensus/` and writes `results/R1/report.md` plus `results/R1/lookups.json`. The engine is unchanged; the golden hashes above still pass.

R1 decisions:
- **Row parsing.** Data rows are recognised by a `T<n>-<nn>` id; headers, blank lines and code fences are ignored. The row's input values (after clean-up) give the key. The row id is checked against the grid position as a sanity check only.
- **Clean-up.** Only the permitted clean-up is applied, cell by cell, and each changed cell is logged.
- **Consensus ties.** When there is no rule value among the tied values, the tie goes to A3 order. For T4 that is the row's room list (field: help, chat, take credit, argue; square: chat, praise, share food, interrupt, ignore, argue).
- **Majority** = the value with the highest count; a tie is any equal top count, including 3–3–2.
- **Noise vs temperament.** A self-consistent arm is one where run 1 equals run 2. "Temperament" = at least two distinct values among the self-consistent arms. "Stable" = all 8 values equal. "Noise" = everything else.
- **Usage weights.** These come from the decision logs of 20 consensus runs (seeds 1–20, n 20, 30 days). Rows never looked up have weight 0. The "differs" shares use weighted cells over the ten teacher tables only.
- **Table shares of look-ups.** All twelve tables are included, including T1 and T11.

## R2: spread of lives and village outcomes

`node analyze_r2.js` runs 15 conditions × seeds 101–150 × 60 days (n 20, logs on). It writes per-run raw results to `results/R2/raw/<condition>.json` and the tables to `results/R2/report.md` and `summary.json`. `--run <condition>` runs one condition; `--report` re-aggregates.

R2 decisions:
- **Acts** = event-log rows whose act is a real act. Apology encounters (`apologise`) and night work outcomes (`-`) are excluded. Unkind = argue, interrupt, ignore, take credit.
- **Belief moves, breaks and flips** count applied moves only, i.e. moves that changed a belief (as in R0).
- **Friends** = the number of others this villager likes or is close to (outgoing, directed).
- **Undefined unkind share.** A villager who initiated no acts in a run has no share for that run, and that run is left out of its SD. This only happens under shuffled (48 villager-runs) and random (15) tables. Village-level shares were always defined.
- **Bootstrap.** 200 resamples of the 50 seeds, drawn from a mulberry32 stream seeded with `"R2:bootstrap"`. The same resamples are used for every condition. The interval is the 6th and 195th of the 200 sorted values. A seed drawn twice forms pairs with distance 0, so the belief-distance bootstrap is biased slightly downward.
- **Distinct endings** has no CI, since the prompt didn't ask for one. The SDs use n − 1.

## R3: one-row edit and decision traces

`node analyze_r3.js` writes `tables/consensus_T4edit/` (consensus with one T4 row changed: `friendly,field,low` second option `take credit` → `chat`), Part A traces (`results/R3/partA_traces.json`), per-run raw results for 50 pairs (`results/R3/raw.json`), and `results/R3/report.md` and `summary.json`. The engine is unchanged, and the original runs reproduce the R2 consensus runs exactly.

R3 decisions:
- **Insult encounters** = event-log rows with meaning `insult` and a real initiator (night work outcomes excluded). Apology encounters would count too, but none of the first three is one.
- **Trace lines** = every decision-log line whose tick equals the encounter tick and whose NPC is the initiator or the receiver, in log order. That includes lines from steps before the encounter (T1, T2). Night lines (`night<d>`) are a separate tick.
- **Targeted uses** = T4 look-ups with key `friendly|field|low` and choice `second`, counted in both arms. In the edited arm the second option is `chat`.
- **Field hours** = T2 look-ups whose chosen option (by the logged choice) is `field`. **Hunger events** = T1 look-ups returning `eat` or `eat now`.
- **Days worked** = night work events (well or badly). **Good-work share** = per-run ratio, then averaged over runs.
- **Unkind share** = village-level, as in R2. **Belief changes** = applied moves (up + down + flip + break) over all 60 days.
- **SDs** use n − 1. CI = 1.96 × SD(differences) / √50. Change/SD uses the SD of the original arm.

## R4: robustness to arbitrary settings

The engine now exposes eight settings as configuration (defaults = specification values; all golden hashes, all R2 fingerprints checked and all R3 runs are unchanged): `pSecond` 25, `likingStep` 3, `foodPerTick` 5, `mealSize` 40, `bufferDays` 7, `balAgainst` −2, `balFor` 2, `balStrong` 5. `run.js` accepts each as `--name value`. The constructor rejects non-integers and requires `likingStep ≥ 1`, `bufferDays ≥ 1`, `balAgainst < balFor ≤ balStrong`. `viewer.html` was rebuilt from the new engine.

`node analyze_r4.js` runs 11 variants × 3 conditions (loop on, loop off, loop on + shuffled) × seeds 101–130 (consensus, n 20, 60 days) and writes `results/R4/raw/*.json`, `report.md` and `summary.json`. `--run <variant>` runs one variant; `--report` re-aggregates.

R4 decisions:
- **Balance categories** use integer balances: `≤ balAgainst` against, `< balFor` mixed, `< balStrong` mostly for, else strongly for. This reproduces the spec's −2 / ≤1 / ≤4 / ≥5 cut-offs exactly.
- **Buffer trim** is `while (length > bufferDays) shift()`. With one push per night this is the same as the old single `shift()`.
- **Liking step** applies symmetrically (+step up, −step down). The counter still resets to 0 after a change.
- **mealSize** is exposed but not varied, since no variant uses it.
- **Shuffled condition** keeps the loop on and the variant's setting. The shuffle is drawn from the run's own `random` stream, as in R2.
- **Unkind share** is village-level per run (R2 definition), averaged over the 30 seeds. **SD of friends** is the R2 definition over 30 seeds.
- **C1–C3** compare point estimates only: C1 SD on > off; C2 mean friendships on > off and mean feuds on < off; C3 mean shuffled share > 2 × mean consensus share.
- **Loop-off rows** for the buffer and threshold variants are identical to the defaults by construction, since those settings act only in the night integration step that `loopOff` skips.

## R5: table answers versus live AI answers

`node analyze_r5.js` reads the unchanged attachments in `inputs/R5/`. It replays consensus seed 101 (n 20, 30 days), checks the 40 moments against the decision log, and derives table and rules answers. It also computes agreement, matches judge items and options, and scores the judges. Output: `results/R5/report.md`, `summary.json`, `moments_table.csv`. The engine is unchanged.

R5 decisions:
- **Moment check** = an exact match on (tick, npc, table, key) in the decision log.
- **Answers** are compared as strings. A reaction is `meaning; liking_change`, so both parts must match.
- **Judge items** are matched to moments by exact equality of the item text and the first line of the moment text. Options are parsed back to answers (`goes to the X`, `chooses to X`, `takes it as "M"; liking goes up/stays the same/goes down`).
- **A source whose answer has no option** (rules at J08/Q21, `chat`) gets no rating there. Its means use the other 17 moments, and that moment is left out of its head-to-head. Option J04 `chat` and J08 `argue` match no source. They are still rated and count in the judge correlations.
- **Both Gemini judges** = the mean over both judges' ratings, i.e. the average of the two per-judge means.
- **Correlations** use all 37 rated options (17 two-option items + one three-option item). The judge file with two blocks is split at the line starting `Gemini incognito`.

## R5b: chained rules answer for act moments

`node analyze_r5.js --chain` writes `results/R5b/`. For act moments only, the rules answer is the rule T4 first option at (rules stance, room, honesty). The rules stance is the rule T3 output for the key of the moment's own T3 look-up: the decision-log line just before the moment's T4 line, same tick and villager. Room and reaction moments are unchanged. Without `--chain` the script reproduces R5 (the n-note now names the missing source instead of fixed text).

R5b decisions:
- **Q26** has no T3 look-up: its `hostile` stance came from a `pay back` grudge (builder decision 7). The grudge is not a T3 decision, so the stance is kept as `hostile` and only T4 is taken from the rules: `hostile|field|low` → `argue`, the same as in R5.
- **Sanity check:** for every other act moment, the T3 line's output equals the stance in the moment's T4 key.

## R6: an outside mind steering one villager

The engine has a new config field `suture` (default `null`; all golden hashes and the R3/R5 outputs are unchanged): `{ subjects: [ids], mind: 'cold'|'warm'|'twin'|'random', fraction, untilDay }`. At hour 0 of each day it decides whether the day is steered: `day < untilDay` and `floor((day+1)·fraction) > floor(day·fraction)`. On a steered day a subject's choices use the mind's traits: T2 diligence and sociability, T3 warmth, T4 honesty, and T5 honesty and pride (only when the subject is the initiator). The random mind uses its own stream `"<runSeed>:suture"`, which is created only for that mind. Each steered look-up draws a full personality (warmth, sociability, diligence, pride, honesty): one per T2, one per T5, and one each for an encounter's T3 and T4.

`node analyze_r6.js` runs the self-checks, Step 2 (`--step2 a-b` writes `results/R6/raw/step2_seed<s>.json`), Step 3 and Step 4, and writes `results/R6/report.md` and `summary.json`.

R6 decisions:
- **"At day k" / "end of day k"** = after k full days (k × 16 waking ticks and k nights), so day 60 is the state right after the last steered day (day index 59) and its night. "Day 0" in Step 4 = after the initial compile, before any tick.
- **Twin** = the subject's effective traits after the initial compile, including honesty (= temperament).
- **Steering applies to T3, T4 and T5 only when the subject is the initiator**, since these are the initiator's choices. The night work outcome and all reactions use its own traits.
- **A random-mind personality draw** always takes five values in the stated order, even when the look-up uses only some of them. A pay-back encounter draws only for T4. An apology replaces the act, so after an `apologise` decision there is no T3/T4 draw.
- **Belief moves, breaks and flips** = applied moves in days 0–59 (the first 60 nights), as in R2. "Friends" / "enemies" = outgoing like-or-close / dislike; "liked by" / "disliked by" = incoming.
- **Toward-mind** uses the four compiled traits as −1/0/+1 against the mind's values (honesty is not a compiled trait and is left out).
- **Step 3 "no steering"** uses one baseline run per seed, measured for each villager. T2 counts are all T2 look-ups by the subject, by chosen room. `eat now` / `rest now` hours go home without a T2 look-up and are not counted.
- **Step 4** uses `untilDay` 60, as in Step 2, so days 60–89 are released.
- **Self-checks** in the report: no subjects, `untilDay` 0 and fraction 0 all equal no steering. With the loop off, the twin mind on everyone equals no steering. The steered-day counts are 15/30/45/60.
- **SDs** use n − 1. Every cell is mean ± 1.96 × SD / √n with n = 200 (Step 2) or 100 (Step 3).
