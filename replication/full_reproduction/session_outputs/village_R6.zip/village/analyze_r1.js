// R1 analysis: import teacher replies, validate, consistency, consensus, noise vs temperament, usage weighting.
// node analyze_r1.js   → writes tables/<fill>/, tables/consensus/, results/R1/{report.md,report.json}
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import {
  Village, TABLE_DEFS, TABLE_IDS, TEACHER_IDS, gridKeys, normaliseTable, loadTable, allowedOutputs,
  DEFAULT_CONFIG, ACTS_BY_ROOM,
} from './engine.js';
import { sha256 } from './sha256.js';
import { loadTableDir } from './run.js';

const here = dirname(fileURLToPath(import.meta.url));
const ARMS = ['opusnormal', 'opusblind', 'gemini', 'chatgpt'];
const BLIND = ARMS.flatMap(a => [`${a}_r1`, `${a}_r2`]);
const ALL = [...BLIND, 'dev_r1'];
const f4 = x => x.toFixed(4);
const out = []; // report lines
const P = (...l) => { for (const x of l) { out.push(x); console.log(x); } };
const table = (head, rows) => {
  P('| ' + head.join(' | ') + ' |', '|' + head.map(() => ' --- ').join('|') + '|');
  for (const r of rows) P('| ' + r.join(' | ') + ' |');
  P('');
};

// ---------------------------------------------------------------- rule tables
const ruleTexts = loadTableDir('tables/rules');
const rule = {};
for (const t of TABLE_IDS) rule[t] = loadTable(t, ruleTexts[t]).map;

// row list: [tid, key] in grid order, and cell list [tid, key, colIndex]
const ROWS = [], CELLS = [];
for (const t of TEACHER_IDS) for (const g of gridKeys(t)) {
  const key = g.join('|');
  ROWS.push([t, key]);
  TABLE_DEFS[t].outputs.forEach((_, c) => CELLS.push([t, key, c]));
}

// ---------------------------------------------------------------- 1. import
function cleanCell(raw) {
  let v = raw.trim();
  v = v.replace(/^["']+|["']+$/g, '').trim();
  v = v.toLowerCase();
  if (v === '1') v = '+1';
  if (/^[-‐-―−]1$/.test(v)) v = '-1';
  if (v === 'dont' || v === 'do not') v = "don't";
  return v;
}
const imports = {};
for (const name of ALL) {
  const text = readFileSync(join(here, 'teacher_replies', name + '.txt'), 'utf8');
  const fill = {}; for (const t of TEACHER_IDS) fill[t] = new Map();
  const cleanups = [], problems = [];
  for (const line of text.split(/\r?\n/)) {
    const rawFields = line.split(',');
    const id = cleanCell(rawFields[0] || '').toUpperCase();
    const m = /^(T\d+)-(\d+)$/.exec(id);
    if (!m) continue; // header, blank, code fence
    const tid = m[1];
    const d = TABLE_DEFS[tid];
    if (!d || d.type !== 'teacher') { problems.push(`${id}: not a teacher table`); continue; }
    const nIn = d.inputs.length, nOut = d.outputs.length;
    const fields = rawFields.slice(1);
    if (fields.length !== nIn + nOut) { problems.push(`${id}: ${fields.length} fields, expected ${nIn + nOut}`); continue; }
    const vals = fields.map((r, i) => {
      const c = cleanCell(r);
      if (c !== r) cleanups.push(`${id} col ${i < nIn ? d.inputs[i][0] : d.outputs[i - nIn][0]}: "${r}" → "${c}"`);
      return c;
    });
    const key = vals.slice(0, nIn).join('|');
    // row id ↔ grid position check
    const pos = gridKeys(tid).findIndex(g => g.join('|') === key);
    if (pos < 0) { problems.push(`${id}: inputs not in grid (${key})`); continue; }
    if (pos + 1 !== parseInt(m[2], 10)) problems.push(`${id}: row id does not match grid position ${pos + 1}`);
    if (fill[tid].has(key)) problems.push(`${id}: duplicate row ${key}`);
    fill[tid].set(key, vals.slice(nIn));
  }
  // write table set
  const dir = join(here, 'tables', name);
  mkdirSync(dir, { recursive: true });
  const texts = {};
  for (const t of TABLE_IDS) {
    texts[t] = TABLE_DEFS[t].type === 'designer' ? ruleTexts[t] : normaliseTable(t, fill[t]);
    writeFileSync(join(dir, TABLE_DEFS[t].file), texts[t]);
  }
  const errors = TABLE_IDS.flatMap(t => loadTable(t, texts[t]).errors);
  imports[name] = { fill, cleanups, problems, errors };
}

P('# R1 report', '', '## 1. Import and validation', '');
table(['Fill', 'Data rows', 'Missing', 'Illegal / validation errors', 'Other problems', 'Cells cleaned'],
  ALL.map(n => {
    const im = imports[n];
    const rows = TEACHER_IDS.reduce((s, t) => s + im.fill[t].size, 0);
    const missing = im.errors.filter(e => e.includes('missing row')).length;
    return [n, rows, missing, im.errors.length - missing, im.problems.length, im.cleanups.length];
  }));
for (const n of ALL) {
  const im = imports[n];
  if (im.errors.length || im.problems.length) P(`- ${n}: ` + [...im.errors, ...im.problems].join('; '));
  if (im.cleanups.length) {
    const byKind = {};
    for (const c of im.cleanups) { const k = c.replace(/^.*?: /, ''); byKind[k] = (byKind[k] || 0) + 1; }
    P(`- ${n} clean-up: ` + Object.entries(byKind).map(([k, v]) => `${k} ×${v}`).join(', ') +
      ` (rows: ${[...new Set(im.cleanups.map(c => c.split(' ')[0]))].join(' ')})`);
  }
}
P('');
const F = Object.fromEntries(ALL.map(n => [n, imports[n].fill]));
const cell = (n, t, k, c) => F[n][t].get(k)[c];
const rowStr = (n, t, k) => F[n][t].get(k).join('|');

// ---------------------------------------------------------------- comparisons
function compare(a, b) { // a, b: functions (t,k) -> array
  let rows = 0, cells = 0;
  for (const [t, k] of ROWS) {
    const x = a(t, k), y = b(t, k);
    let same = true;
    x.forEach((v, i) => { if (v === y[i]) cells++; else same = false; });
    if (same) rows++;
  }
  return { rows, cells };
}
const getter = n => (t, k) => F[n][t].get(k);
const NR = ROWS.length, NC = CELLS.length;

P('## 2. Self-consistency (run 1 vs run 2)', '');
const self = {};
table(['Arm', 'Rows identical', 'Share', 'Cells identical', 'Share'], ARMS.map(a => {
  const r = compare(getter(a + '_r1'), getter(a + '_r2')); self[a] = r;
  return [a, `${r.rows}/${NR}`, f4(r.rows / NR), `${r.cells}/${NC}`, f4(r.cells / NC)];
}));

P('## 3. Agreement between arms (mean of 4 cross pairs)', '');
const armRows = [];
for (let i = 0; i < ARMS.length; i++) for (let j = i + 1; j < ARMS.length; j++) {
  let r = 0, c = 0;
  for (const x of ['_r1', '_r2']) for (const y of ['_r1', '_r2']) {
    const q = compare(getter(ARMS[i] + x), getter(ARMS[j] + y)); r += q.rows; c += q.cells;
  }
  armRows.push([`${ARMS[i]} vs ${ARMS[j]}`, (r / 4).toFixed(2), f4(r / 4 / NR), (c / 4).toFixed(2), f4(c / 4 / NC)]);
}
table(['Arm pair', 'Mean rows identical', 'Share', 'Mean cells identical', 'Share'], armRows);

// ---------------------------------------------------------------- 5. consensus (needed for 4)
const vocabOrder = (t, k, c) => (t === 'T4' ? ACTS_BY_ROOM[k.split('|')[1]] : TABLE_DEFS[t].outputs[c][1]); // A3 order (T4: the row's room list)
const cons = {}; for (const t of TEACHER_IDS) cons[t] = new Map();
let ties = 0; const tieList = [];
for (const [t, k, c] of CELLS) {
  const counts = new Map();
  for (const n of BLIND) { const v = cell(n, t, k, c); counts.set(v, (counts.get(v) || 0) + 1); }
  const max = Math.max(...counts.values());
  const top = [...counts].filter(([, v]) => v === max).map(([v]) => v);
  let val = top[0];
  if (top.length > 1) {
    ties++;
    const rv = rule[t].get(k)[c];
    const order = vocabOrder(t, k, c);
    val = top.includes(rv) ? rv : top.slice().sort((x, y) => order.indexOf(x) - order.indexOf(y))[0];
    tieList.push(`${t} ${k} ${TABLE_DEFS[t].outputs[c][0]}: tied {${top.join(', ')}} ×${max} → ${val}${top.includes(rv) ? ' (rule)' : ' (vocab order)'}`);
  }
  if (!cons[t].has(k)) cons[t].set(k, []);
  cons[t].get(k)[c] = val;
}
F.consensus = cons;
const consDir = join(here, 'tables', 'consensus');
mkdirSync(consDir, { recursive: true });
const consTexts = {};
for (const t of TABLE_IDS) {
  consTexts[t] = TABLE_DEFS[t].type === 'designer' ? ruleTexts[t] : normaliseTable(t, cons[t]);
  writeFileSync(join(consDir, TABLE_DEFS[t].file), consTexts[t]);
}
const consErrors = TABLE_IDS.flatMap(t => loadTable(t, consTexts[t]).errors);

P('## 4. Agreement across all eight blind fills', '');
let all8 = 0, six = 0, cells8 = 0;
for (const [t, k] of ROWS) {
  const c = new Map(); for (const n of BLIND) { const s = rowStr(n, t, k); c.set(s, (c.get(s) || 0) + 1); }
  const m = Math.max(...c.values());
  if (m === 8) all8++; if (m >= 6) six++;
}
for (const [t, k, c] of CELLS) if (new Set(BLIND.map(n => cell(n, t, k, c))).size === 1) cells8++;
table(['Measure', 'Count', 'Share'], [
  ['Rows where all 8 identical', `${all8}/${NR}`, f4(all8 / NR)],
  ['Rows where ≥ 6 of 8 give the identical whole row', `${six}/${NR}`, f4(six / NR)],
  ['Answer cells where all 8 agree', `${cells8}/${NC}`, f4(cells8 / NC)],
]);
P('Per table: share of rows a single blind fill shares with the consensus (lowest / highest over the 8 fills):', '');
table(['Table', 'Rows', 'Lowest', 'Highest', 'Lowest fill', 'Highest fill'], TEACHER_IDS.map(t => {
  const keys = [...rule[t].keys()];
  const sh = BLIND.map(n => [n, keys.filter(k => rowStr(n, t, k) === cons[t].get(k).join('|')).length]);
  sh.sort((a, b) => a[1] - b[1]);
  const lo = sh[0], hi = sh[sh.length - 1];
  return [t, keys.length, `${lo[1]}/${keys.length} = ${f4(lo[1] / keys.length)}`, `${hi[1]}/${keys.length} = ${f4(hi[1] / keys.length)}`,
    sh.filter(s => s[1] === lo[1]).map(s => s[0]).join(', '), sh.filter(s => s[1] === hi[1]).map(s => s[0]).join(', ')];
}));

P('## 5. Consensus', '');
P(`Validation of tables/consensus: ${consErrors.length ? consErrors.join('; ') : 'pass'}`, '');
P(`Ties: ${ties}`, '');
for (const x of tieList) P('- ' + x);
P('');
const consSim = new Village({ ...DEFAULT_CONFIG, runSeed: 1, n: 20, days: 30, tableDir: 'tables/consensus' }, consTexts);
consSim.run();
table(['Table', 'SHA-256 (consensus set)'], TABLE_IDS.map(t => [t, '`' + consSim.tableHashes[t] + '`']));
P(`runSeed 1, n 20, days 30, consensus tables: state \`${consSim.stateHash()}\`, log \`${consSim.logHash()}\`, missingRows ${consSim.missingRows}`, '');

P('## 6. Distance from the rule tables', '');
const ruleGet = (t, k) => rule[t].get(k);
table(['Fill', 'Rows identical to rule tables', 'Share', 'Cells identical to rule tables', 'Share'],
  [...ALL, 'consensus'].map(n => { const r = compare(getter(n), ruleGet); return [n, `${r.rows}/${NR}`, f4(r.rows / NR), `${r.cells}/${NC}`, f4(r.cells / NC)]; }));
{
  const r = compare(getter('dev_r1'), getter('consensus'));
  P(`dev_r1 vs consensus: rows identical ${r.rows}/${NR} = ${f4(r.rows / NR)}; cells identical ${r.cells}/${NC} = ${f4(r.cells / NC)}`, '');
}

P('## 7. Noise vs temperament', '');
const cls = {}; const clsTot = { stable: 0, noise: 0, temperament: 0 };
for (const [t, k, c] of CELLS) {
  const vals = BLIND.map(n => cell(n, t, k, c));
  let kind;
  if (new Set(vals).size === 1) kind = 'stable';
  else {
    const selfVals = ARMS.filter(a => cell(a + '_r1', t, k, c) === cell(a + '_r2', t, k, c)).map(a => cell(a + '_r1', t, k, c));
    kind = new Set(selfVals).size >= 2 ? 'temperament' : 'noise';
  }
  const col = `${t}.${TABLE_DEFS[t].outputs[c][0]}`;
  cls[col] ||= { stable: 0, noise: 0, temperament: 0 };
  cls[col][kind]++; clsTot[kind]++;
}
table(['Table.column', 'Cells', 'Stable', 'Noise', 'Temperament'],
  [...Object.entries(cls).map(([k, v]) => [k, v.stable + v.noise + v.temperament, v.stable, v.noise, v.temperament]),
   ['**All**', NC, clsTot.stable, clsTot.noise, clsTot.temperament]]);

P('## 8. Weighting by real use (consensus tables, seeds 1–20, n 20, 30 days)', '');
const lookups = {}; const perTable = {}; let total = 0;
for (let s = 1; s <= 20; s++) {
  const sim = new Village({ ...DEFAULT_CONFIG, runSeed: s, n: 20, days: 30 }, consTexts);
  sim.run();
  for (let i = 1; i < sim.decisionLog.length; i++) {
    const [, , t, key, , choice] = sim.decisionLog[i].split(',');
    total++; perTable[t] = (perTable[t] || 0) + 1;
    const r = (lookups[t + '|' + key] ||= { total: 0, first: 0, second: 0 });
    r.total++; if (choice === 'first') r.first++; else if (choice === 'second') r.second++;
  }
}
const weight = (t, k, c) => {
  const r = lookups[t + '|' + k]; if (!r) return 0;
  if (t === 'T2' || t === 'T4') return c === 0 ? r.first : r.second;
  return r.total;
};
P(`Total look-ups: ${total}`, '');
table(['Table', 'Look-ups', 'Share'], TABLE_IDS.map(t => [t, perTable[t] || 0, f4((perTable[t] || 0) / total)]));
let rowsUsed = 0; for (const [t, k] of ROWS) if (lookups[t + '|' + k]) rowsUsed++;
P(`Teacher-table rows looked up at least once: ${rowsUsed}/${NR}`, '');
let W = 0; for (const [t, k, c] of CELLS) W += weight(t, k, c);
table(['Fill', 'Weighted differing cells', 'Weighted cells', 'Share of real decisions differing from consensus'],
  ALL.map(n => {
    let d = 0; for (const [t, k, c] of CELLS) if (cell(n, t, k, c) !== cons[t].get(k)[c]) d += weight(t, k, c);
    return [n, d, W, f4(d / W)];
  }));
P('Usage-weighted chance that a randomly chosen blind fill differs from the consensus:', '');
const colRows = [];
for (const t of TEACHER_IDS) TABLE_DEFS[t].outputs.forEach(([name], c) => {
  let w = 0, d = 0;
  for (const k of rule[t].keys()) {
    const wt = weight(t, k, c); w += wt;
    d += wt * BLIND.filter(n => cell(n, t, k, c) !== cons[t].get(k)[c]).length / 8;
  }
  colRows.push([`${t}.${name}`, w, w ? f4(d / w) : 'n/a (never used)']);
});
table(['Table.column', 'Weight', 'P(differs)'], colRows);

P('## 9. T6, belief "people are against me", tier core', '');
const k1 = 'helped|people are against me|core', k2 = 'apologised to|people are against me|core';
table(['Fill', 'helped: meaning', 'helped: pressure', 'apologised to: meaning', 'apologised to: pressure'],
  [...ALL, 'consensus'].map(n => [n, F[n].T6.get(k1)[0], F[n].T6.get(k1)[1], F[n].T6.get(k2)[0], F[n].T6.get(k2)[1]])
    .concat([['rule tables', rule.T6.get(k1)[0], rule.T6.get(k1)[1], rule.T6.get(k2)[0], rule.T6.get(k2)[1]]]));

mkdirSync(join(here, 'results', 'R1'), { recursive: true });
writeFileSync(join(here, 'results', 'R1', 'report.md'), out.join('\n') + '\n');
writeFileSync(join(here, 'results', 'R1', 'lookups.json'), JSON.stringify({ total, perTable, rows: lookups }, null, 1));
