// R3: can a designer change one rule and see why?
//   node analyze_r3.js            → Part A traces + Part B paired runs, writes results/R3/*
// Part A: consensus tables, seed 101, n 20, 60 days, logs on; first three encounters whose meaning is `insult`.
// Part B: one-row edit of consensus T4 (friendly|field|low: second `take credit` → `chat`),
//         50 paired runs (seeds 101–150, n 20, 60 days), original vs edited.
import { readFileSync, writeFileSync, mkdirSync, cpSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { Village, DEFAULT_CONFIG, TABLE_DEFS, NEGATIVE_ACTS } from './engine.js';
import { loadTableDir } from './run.js';

const here = dirname(fileURLToPath(import.meta.url));
const OUT = join(here, 'results', 'R3');
const SEEDS = Array.from({ length: 50 }, (_, i) => 101 + i);
const DAYS = 60, N = 20;
const EDIT_KEY = 'friendly,field,low';
const EDIT_FROM = 'friendly,field,low,help,take credit';
const EDIT_TO = 'friendly,field,low,help,chat';
const TARGET_KEY = 'friendly|field|low';

mkdirSync(OUT, { recursive: true });
const lines = [];
const P = (...l) => { for (const x of l) { lines.push(x); console.log(x); } };

// ---------------------------------------------------------------- edited table set
const EDIT_DIR = join(here, 'tables', 'consensus_T4edit');
cpSync(join(here, 'tables', 'consensus'), EDIT_DIR, { recursive: true });
const t4path = join(EDIT_DIR, TABLE_DEFS.T4.file);
const t4orig = readFileSync(join(here, 'tables', 'consensus', TABLE_DEFS.T4.file), 'utf8');
const t4lines = t4orig.split('\n');
const idx = t4lines.indexOf(EDIT_FROM);
if (idx < 0 || t4lines.filter(l => l.startsWith(EDIT_KEY + ',')).length !== 1) throw new Error('edit row not found exactly once');
t4lines[idx] = EDIT_TO;
const t4edit = t4lines.join('\n');
writeFileSync(t4path, t4edit);
const orig = loadTableDir('tables/consensus');
const edit = loadTableDir('tables/consensus_T4edit');
const changedFiles = Object.keys(orig).filter(t => orig[t] !== edit[t]);
const changedLines = t4orig.split('\n').filter((l, i) => l !== t4edit.split('\n')[i]).length;

function simulate(seed, tables, dir) {
  const sim = new Village({ ...DEFAULT_CONFIG, runSeed: seed, n: N, days: DAYS, tableDir: dir, logDecisions: true }, tables);
  sim.run();
  return sim;
}

// ---------------------------------------------------------------- Part A
P('# R3 report', '');
P('## Part A: decision traces (consensus, seed 101, n 20, 60 days)', '');
const simA = simulate(101, orig, 'tables/consensus');
P(`Run check: state \`${simA.stateHash()}\`, log \`${simA.logHash()}\`, missingRows ${simA.missingRows}`, '');
const ev = simA.eventLog.slice(1).map(l => l.split(','));
const dec = simA.decisionLog.slice(1).map(l => l.split(','));
const insults = ev.filter(e => e[6] === 'insult' && e[2] !== '-').slice(0, 3);
const totalInsults = ev.filter(e => e[6] === 'insult' && e[2] !== '-').length;
P(`Encounters taken as an insult in this run: ${totalInsults}. First three:`, '');
const fmtInputs = (tid, key) => {
  const names = TABLE_DEFS[tid].inputs.map(c => c[0]); const vals = key.split('|');
  return names.map((n, i) => `${n}=${vals[i]}`).join(', ');
};
const fmtOutput = (tid, out) => {
  const names = TABLE_DEFS[tid].outputs.map(c => c[0]); const vals = out.split('|');
  return names.map((n, i) => `${n}=${vals[i]}`).join(', ');
};
const traces = [];
insults.forEach((e, k) => {
  const [tick, room, I, R, act, event, meaning, pressure, lc] = e;
  const t = +tick, day = Math.floor(t / 16), hour = t % 16;
  P(`### Insult ${k + 1}: tick ${tick} (day ${day}, hour ${hour}), ${room}: ${I} → ${R}, act \`${act}\` (event \`${event}\`, meaning ${meaning}, pressure ${pressure}, liking change ${lc})`, '');
  P('| # | Who | Role | Table | Inputs | Output | Option used |', '| --- | --- | --- | --- | --- | --- | --- |');
  const rows = dec.filter(d => d[0] === tick && (d[1] === I || d[1] === R));
  rows.forEach((d, j) => {
    const [, npc, tid, key, out, ch] = d;
    let used = '-';
    if (ch !== '-') { const o = out.split('|'); used = `${ch} → ${ch === 'first' ? o[0] : o[1]}`; }
    P(`| ${j + 1} | ${npc} | ${npc === I ? 'initiator' : 'receiver'} | ${tid} | ${fmtInputs(tid, key)} | ${fmtOutput(tid, out)} | ${used} |`);
  });
  P('');
  traces.push({ event: e, decisions: rows });
});
writeFileSync(join(OUT, 'partA_traces.json'), JSON.stringify(traces, null, 1));

// ---------------------------------------------------------------- Part B
function measures(sim) {
  const m = { targetedUses: 0, targetedLookups: 0, creditTaken: 0, acts: 0, unkindActs: 0, unkindShare: null, beliefChanges: 0,
    friendships: 0, feuds: 0, fieldHours: 0, daysWorked: 0, workWell: 0, goodWorkShare: null, hungerEvents: 0 };
  for (let i = 1; i < sim.decisionLog.length; i++) {
    const [, , tid, key, out, ch] = sim.decisionLog[i].split(',');
    if (tid === 'T4') {
      if (key === TARGET_KEY) { m.targetedLookups++; if (ch === 'second') m.targetedUses++; }
      const o = out.split('|'); if ((ch === 'first' ? o[0] : o[1]) === 'take credit') { const r = key + ':' + ch; (m.creditSources ||= {})[r] = (m.creditSources[r] || 0) + 1; }
    }
    else if (tid === 'T2') { const o = out.split('|'); if ((ch === 'first' ? o[0] : o[1]) === 'field') m.fieldHours++; }
    else if (tid === 'T1' && (out === 'eat' || out === 'eat now')) m.hungerEvents++;
  }
  for (let i = 1; i < sim.eventLog.length; i++) {
    const [tick, , , , act, event] = sim.eventLog[i].split(',');
    if (event === 'credit taken') m.creditTaken++;
    if (tick.startsWith('night')) { m.daysWorked++; if (event === 'work went well') m.workWell++; continue; }
    if (act === 'apologise' || act === '-') continue;
    m.acts++; if (NEGATIVE_ACTS.has(act)) m.unkindActs++;
  }
  m.unkindShare = m.acts ? m.unkindActs / m.acts : null;
  m.goodWorkShare = m.daysWorked ? m.workWell / m.daysWorked : null;
  for (const d of sim.metrics) m.beliefChanges += d.moves.up + d.moves.down + d.moves.flip + d.moves.break;
  const last = sim.metrics[sim.metrics.length - 1];
  m.friendships = last.friendships; m.feuds = last.feuds;
  return m;
}

const raw = [];
for (const seed of SEEDS) {
  const a = simulate(seed, orig, 'tables/consensus'), b = simulate(seed, edit, 'tables/consensus_T4edit');
  raw.push({ seed, original: { stateHash: a.stateHash(), logHash: a.logHash(), missingRows: a.missingRows, ...measures(a) },
    edited: { stateHash: b.stateHash(), logHash: b.logHash(), missingRows: b.missingRows, ...measures(b) } });
}
writeFileSync(join(OUT, 'raw.json'), JSON.stringify(raw));

// consistency check against R2 raw results (consensus condition)
let r2check = 'R2 raw not found';
try {
  const r2 = JSON.parse(readFileSync(join(here, 'results', 'R2', 'raw', 'consensus.json'), 'utf8')).runs;
  const bad = r2.filter((r, i) => r.stateHash !== raw[i].original.stateHash || r.friendships !== raw[i].original.friendships ||
    r.feuds !== raw[i].original.feuds || r.beliefMoves !== raw[i].original.beliefChanges || r.unkindShare !== raw[i].original.unkindShare).length;
  r2check = `${50 - bad}/50 original runs match R2 consensus (state hash, friendships, feuds, belief moves, unkind share)`;
} catch { /* keep message */ }

const mean = a => a.reduce((s, x) => s + x, 0) / a.length;
const sd = a => { const m = mean(a); return Math.sqrt(a.reduce((s, x) => s + (x - m) ** 2, 0) / (a.length - 1)); };
const MEAS = [
  ['targetedUses', 'Targeted uses (T4 friendly|field|low, second option)', 2],
  ['creditTaken', 'Credit-taking events', 2],
  ['unkindShare', 'Unkind-act share', 4],
  ['beliefChanges', 'Belief changes (applied moves)', 2],
  ['friendships', 'Friendships (last day)', 2],
  ['feuds', 'Feuds (last day)', 2],
  ['fieldHours', 'Field hours (T2 → field)', 1],
  ['daysWorked', 'Days worked (night work events)', 1],
  ['goodWorkShare', 'Share of good work days', 4],
  ['hungerEvents', 'Hunger events (T1 → eat / eat now)', 1],
];
const f = (x, d) => x.toFixed(d);
P('## Part B: one-row edit of T4, 50 paired runs (seeds 101–150, n 20, 60 days)', '');
P(`Edit: \`${EDIT_FROM}\` → \`${EDIT_TO}\`. Table files changed: ${changedFiles.join(', ')}; lines changed in T4: ${changedLines}.`);
{ const h = d => new Village({ ...DEFAULT_CONFIG, runSeed: 101, n: N, days: 0 }, d).tableHashes.T4;
  P(`T4 table hash (as loaded) original \`${h(orig)}\`, edited \`${h(edit)}\`.`); }
P(`Check: ${r2check}.`, '');
P('| Measure | Mean original | Mean edited | Paired change ± 95% CI | SD original (seed to seed) | Change / SD |', '| --- | --- | --- | --- | --- | --- |');
const stats = {};
for (const [k, label, d] of MEAS) {
  const o = raw.map(r => r.original[k]), e = raw.map(r => r.edited[k]);
  if (o.some(x => x === null) || e.some(x => x === null)) throw new Error('undefined measure ' + k);
  const diff = e.map((x, i) => x - o[i]);
  const md = mean(diff), ci = 1.96 * sd(diff) / Math.sqrt(diff.length), so = sd(o);
  const eff = so > 0 ? md / so : null;
  stats[k] = { meanOriginal: mean(o), meanEdited: mean(e), meanChange: md, ci, sdOriginal: so, changeOverSd: eff,
    pairsDiffering: diff.filter(x => x !== 0).length };
  P(`| ${label} | ${f(mean(o), d)} | ${f(mean(e), d)} | ${f(md, d)} ± ${f(ci, d)} | ${f(so, d)} | ${eff === null ? 'n/a (SD 0)' : f(eff, 2)} |`);
}
P('');
const identical = raw.filter(r => r.original.stateHash === r.edited.stateHash).length;
const noTarget = raw.filter(r => r.original.targetedUses === 0).length;
P(`Pairs with identical final state: ${identical}/50. Seeds where the original run never used the targeted option: ${noTarget}/50.`);
P(`Targeted row look-ups (either option), mean original ${f(mean(raw.map(r => r.original.targetedLookups)), 2)}, edited ${f(mean(raw.map(r => r.edited.targetedLookups)), 2)}.`);
for (const side of ['original', 'edited']) {
  const tot = {}; for (const r of raw) for (const [k, v] of Object.entries(r[side].creditSources || {})) tot[k] = (tot[k] || 0) + v;
  const parts = Object.entries(tot).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} ${f(v / 50, 2)}`);
  P(`T4 look-ups that chose \`take credit\`, mean per run by row:option (${side}): ${parts.length ? parts.join('; ') : 'none'}.`);
}
P(`Reference: seed 101 original state \`${raw[0].original.stateHash}\`, edited state \`${raw[0].edited.stateHash}\`.`);
writeFileSync(join(OUT, 'summary.json'), JSON.stringify({ edit: { from: EDIT_FROM, to: EDIT_TO }, r2check, identical, noTarget, stats }, null, 1));
writeFileSync(join(OUT, 'report.md'), lines.join('\n') + '\n');
