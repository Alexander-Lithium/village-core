// R4: do the conclusions depend on arbitrary settings?
//   node analyze_r4.js                 → all variants (skips ones already in results/R4/raw), then the report
//   node analyze_r4.js --run <variant> → one variant → results/R4/raw/<variant>.json
//   node analyze_r4.js --report        → re-aggregate
// 11 variants (one setting changed at a time) × 3 conditions (loop on, loop off, loop on + shuffled tables)
// × seeds 101–130, consensus tables, n 20, 60 days, logs on.
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { Village, DEFAULT_CONFIG, NEGATIVE_ACTS } from './engine.js';
import { loadTableDir } from './run.js';

const here = dirname(fileURLToPath(import.meta.url));
const RAW = join(here, 'results', 'R4', 'raw');
const SEEDS = Array.from({ length: 30 }, (_, i) => 101 + i);
const DAYS = 60, N = 20, TABLE_DIR = 'tables/consensus';
export const VARIANTS = [
  ['spec defaults', {}],
  ['backup choice 15%', { pSecond: 15 }],
  ['backup choice 35%', { pSecond: 35 }],
  ['liking step 2', { likingStep: 2 }],
  ['liking step 4', { likingStep: 4 }],
  ['evidence window 5 days', { bufferDays: 5 }],
  ['evidence window 10 days', { bufferDays: 10 }],
  ['evidence thresholds looser', { balAgainst: -1, balFor: 1, balStrong: 4 }],
  ['evidence thresholds stricter', { balAgainst: -3, balFor: 3, balStrong: 6 }],
  ['hunger 4 per hour', { foodPerTick: 4 }],
  ['hunger 6 per hour', { foodPerTick: 6 }],
];
const CONDS = [['on', {}], ['off', { loopOff: true }], ['shuffled', { tablesMode: 'shuffled' }]];
const slug = s => s.replace(/[^a-z0-9]+/gi, '_');

function runVariant(name) {
  const [, change] = VARIANTS.find(v => v[0] === name);
  const tables = loadTableDir(TABLE_DIR);
  const out = { variant: name, change, seeds: SEEDS, days: DAYS, conditions: {} };
  for (const [cond, extra] of CONDS) {
    out.conditions[cond] = SEEDS.map(seed => {
      const sim = new Village({ ...DEFAULT_CONFIG, runSeed: seed, n: N, days: DAYS, tableDir: TABLE_DIR, logDecisions: true, ...extra, ...change }, tables);
      sim.run();
      let total = 0, unkind = 0;
      for (let i = 1; i < sim.eventLog.length; i++) {
        const act = sim.eventLog[i].split(',')[4];
        if (act === 'apologise' || act === '-') continue;
        total++; if (NEGATIVE_ACTS.has(act)) unkind++;
      }
      const last = sim.metrics[sim.metrics.length - 1];
      return {
        seed, stateHash: sim.stateHash(), logHash: sim.logHash(), missingRows: sim.missingRows,
        friendships: last.friendships, feuds: last.feuds, acts: total, unkindShare: total ? unkind / total : null,
        friends: sim.npcs.map(n => n.relOrder.filter(o => { const l = n.rel.get(o.num).liking; return l === 'like' || l === 'close'; }).length),
      };
    });
  }
  mkdirSync(RAW, { recursive: true });
  writeFileSync(join(RAW, slug(name) + '.json'), JSON.stringify(out));
  console.log(`${name}: done`);
}

const mean = a => a.reduce((s, x) => s + x, 0) / a.length;
const sd = a => { const m = mean(a); return Math.sqrt(a.reduce((s, x) => s + (x - m) ** 2, 0) / (a.length - 1)); };
const sdFriends = runs => mean(runs[0].friends.map((_, v) => sd(runs.map(r => r.friends[v]))));
const ci = d => 1.96 * sd(d) / Math.sqrt(d.length);

function report() {
  const lines = [];
  const P = (...l) => { for (const x of l) { lines.push(x); console.log(x); } };
  const res = {};
  for (const [name] of VARIANTS) res[name] = JSON.parse(readFileSync(join(RAW, slug(name) + '.json'), 'utf8'));

  // fingerprint check: spec-default runs must equal the R2 runs (same seeds, same conditions)
  const R2MAP = { on: 'consensus', off: 'consensus_loopOff', shuffled: 'consensus_shuffled' };
  let checked = 0, matched = 0;
  for (const [cond, r2name] of Object.entries(R2MAP)) {
    const p = join(here, 'results', 'R2', 'raw', r2name + '.json');
    if (!existsSync(p)) continue;
    const r2 = JSON.parse(readFileSync(p, 'utf8')).runs;
    res['spec defaults'].conditions[cond].forEach(r => {
      const o = r2.find(x => x.seed === r.seed); checked++;
      if (o && o.stateHash === r.stateHash && o.logHash === r.logHash) matched++;
    });
  }

  P('# R4 report', '', `Consensus tables, n 20, ${DAYS} days, seeds ${SEEDS[0]}–${SEEDS[SEEDS.length - 1]} (30 seeds), logs on. One setting changed at a time.`, '');
  P(`Fingerprint check: ${matched}/${checked} spec-default runs (loop on, loop off, shuffled) have the same state and log hashes as the R2 runs.`, '');
  P('## Main table', '');
  P('| Variant | SD friends on / off | Friendships on / off | Feuds on / off | Unkind share consensus / shuffled | C1 | C2 | C3 |', '| --- | --- | --- | --- | --- | --- | --- | --- |');
  const summary = {};
  for (const [name] of VARIANTS) {
    const c = res[name].conditions;
    if (Object.values(c).some(runs => runs.some(r => r.unkindShare === null))) throw new Error('undefined unkind share in ' + name);
    const s = {
      sdFriendsOn: sdFriends(c.on), sdFriendsOff: sdFriends(c.off),
      friendshipsOn: mean(c.on.map(r => r.friendships)), friendshipsOff: mean(c.off.map(r => r.friendships)),
      feudsOn: mean(c.on.map(r => r.feuds)), feudsOff: mean(c.off.map(r => r.feuds)),
      unkindConsensus: mean(c.on.map(r => r.unkindShare)), unkindShuffled: mean(c.shuffled.map(r => r.unkindShare)),
      missingRows: Object.values(c).flat().reduce((t, r) => t + r.missingRows, 0),
    };
    s.C1 = s.sdFriendsOn > s.sdFriendsOff;
    s.C2 = s.friendshipsOn > s.friendshipsOff && s.feudsOn < s.feudsOff;
    s.C3 = s.unkindShuffled > 2 * s.unkindConsensus;
    // paired differences (same seed), for the supplementary table
    const dF = c.on.map((r, i) => r.friendships - c.off[i].friendships), dX = c.on.map((r, i) => r.feuds - c.off[i].feuds);
    s.diffFriendships = [mean(dF), ci(dF)]; s.diffFeuds = [mean(dX), ci(dX)];
    s.ratioUnkind = s.unkindShuffled / s.unkindConsensus;
    summary[name] = s;
    const yn = b => (b ? 'yes' : 'no');
    P(`| ${name} | ${s.sdFriendsOn.toFixed(3)} / ${s.sdFriendsOff.toFixed(3)} | ${s.friendshipsOn.toFixed(2)} / ${s.friendshipsOff.toFixed(2)} | ${s.feudsOn.toFixed(2)} / ${s.feudsOff.toFixed(2)} | ${s.unkindConsensus.toFixed(4)} / ${s.unkindShuffled.toFixed(4)} | ${yn(s.C1)} | ${yn(s.C2)} | ${yn(s.C3)} |`);
  }
  P('', '## Supplementary: margins (not asked for)', '');
  P('| Variant | SD friends on − off | Friendships on − off (paired, ± 95% CI) | Feuds on − off (paired, ± 95% CI) | Unkind shuffled / consensus | missingRows (all runs) |', '| --- | --- | --- | --- | --- | --- |');
  for (const [name] of VARIANTS) {
    const s = summary[name];
    P(`| ${name} | ${(s.sdFriendsOn - s.sdFriendsOff).toFixed(3)} | ${s.diffFriendships[0].toFixed(2)} ± ${s.diffFriendships[1].toFixed(2)} | ${s.diffFeuds[0].toFixed(2)} ± ${s.diffFeuds[1].toFixed(2)} | ${s.ratioUnkind.toFixed(2)} | ${s.missingRows} |`);
  }
  P('', '## Reference hashes (seed 101, loop on)', '');
  for (const [name] of VARIANTS) { const r = res[name].conditions.on[0]; P(`- ${name}: state \`${r.stateHash}\`, log \`${r.logHash}\``); }
  writeFileSync(join(here, 'results', 'R4', 'report.md'), lines.join('\n') + '\n');
  writeFileSync(join(here, 'results', 'R4', 'summary.json'), JSON.stringify({ fingerprintCheck: `${matched}/${checked}`, summary }, null, 1));
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const a = process.argv.slice(2);
  if (a[0] === '--run') runVariant(a.slice(1).join(' '));
  else if (a[0] === '--report') report();
  else { for (const [n] of VARIANTS) if (!existsSync(join(RAW, slug(n) + '.json'))) runVariant(n); report(); }
}
