// R8 parts B and C (Part A is the speed-test page, built by build_speedtest.js).
//   node analyze_r8.js                → Part B, Part C (memory/speed in fresh child processes, then social life) → results/R8/
//   node --expose-gc analyze_r8.js --mem <hamletSize>   (child: one circle size, prints JSON)
import { writeFileSync, mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { execFileSync } from 'node:child_process';
import { Village, DEFAULT_CONFIG, NEGATIVE_ACTS } from './engine.js';
import { loadTableDir } from './run.js';

const here = dirname(fileURLToPath(import.meta.url));
const OUT = join(here, 'results', 'R8');
const HAMLETS = [21, 51, 101];

// ---------------------------------------------------------------- Part C child: memory and speed at 30,000 villagers
if (process.argv[2] === '--mem') {
  const hs = parseInt(process.argv[3], 10);
  const tables = loadTableDir('tables/consensus');
  const gc = globalThis.gc ?? null;
  const settle = () => { if (gc) { gc(); gc(); } };
  // warm-up: a tiny village so code and table parsing are not counted in the heap difference
  new Village({ ...DEFAULT_CONFIG, runSeed: 101, n: 50, days: 1, hamletSize: hs, tableDir: 'tables/consensus', logDecisions: false }, tables);
  settle();
  const before = process.memoryUsage().heapUsed;
  const t0 = performance.now();
  const sim = new Village({ ...DEFAULT_CONFIG, runSeed: 101, n: 30000, days: 1, hamletSize: hs, tableDir: 'tables/consensus', logDecisions: false }, tables);
  const buildMs = performance.now() - t0;
  settle();
  const after = process.memoryUsage().heapUsed;
  const t1 = performance.now();
  for (let h = 0; h < 16; h++) sim.tick();
  const tickMs = (performance.now() - t1) / 16;
  console.log(JSON.stringify({ hamletSize: hs, gcForced: !!gc, heapBefore: before, heapAfter: after, bytesPerVillager: (after - before) / 30000,
    buildMs, msPerHour: tickMs, hamlets: sim.hamlets.length, lastHamletSize: sim.hamlets[sim.hamlets.length - 1].length, stateHash: sim.stateHash() }));
  process.exit(0);
}

mkdirSync(OUT, { recursive: true });
const lines = [];
const P = (...l) => { for (const x of l) { lines.push(x); console.log(x); } };
P('# R8 report (parts B and C)', '');

// ---------------------------------------------------------------- Part B: cost
const PRICES = [['Claude Haiku 5.5', 0.10, 0.50], ['Gemini 2.5 Flash-Lite', 0.10, 0.40], ['Claude Sonnet 5.5', 2, 10], ['Claude Opus 5.5', 4, 20], ['GPT-5.5', 5, 30]];
const FILL_IN = 5000, FILL_OUT = 4000, CALL_IN = 300, CALL_OUT = 20, CALLS_PER_HOUR = 16 * 60 / 5; // 192
const usd = x => '$' + x.toFixed(x < 0.1 ? 5 : 2);
P('## Part B: cost (US$; prices as given, per million tokens)', '');
P(`Table fill = ${FILL_IN} input + ${FILL_OUT} output tokens. Live = ${CALLS_PER_HOUR} calls per villager per real hour × (${CALL_IN} in + ${CALL_OUT} out).`, '');
P('| Model | Input / output price | One table fill | Live, per villager per real hour | Live, 1,000 villagers per real hour |', '| --- | --- | --- | --- | --- |');
const cost = {};
for (const [m, pin, pout] of PRICES) {
  const fill = (FILL_IN * pin + FILL_OUT * pout) / 1e6;
  const perV = CALLS_PER_HOUR * (CALL_IN * pin + CALL_OUT * pout) / 1e6;
  cost[m] = { fill, perVillagerHour: perV, per1000Hour: perV * 1000 };
  P(`| ${m} | ${pin} / ${pout} | ${usd(fill)} | ${usd(perV)} | ${usd(perV * 1000)} |`);
}
P('');

// ---------------------------------------------------------------- Part C: cost of bigger circles (fresh process each)
P('## Part C: acquaintance circles', '');
const mem = HAMLETS.map(hs => JSON.parse(execFileSync(process.execPath, ['--expose-gc', fileURLToPath(import.meta.url), '--mem', String(hs)], { cwd: here, encoding: 'utf8' }).trim()));
P('### Cost: 30,000 villagers, runSeed 101, decision log off (fresh Node process per size, GC forced)', '');
P('| Circle (others known) | Hamlet size | Hamlets (last one) | Memory per villager (KB) | Build (ms) | ms per in-game hour (16 h) |', '| --- | --- | --- | --- | --- | --- |');
for (const r of mem) P(`| ${r.hamletSize - 1} | ${r.hamletSize} | ${r.hamlets} (last ${r.lastHamletSize}) | ${(r.bytesPerVillager / 1024).toFixed(2)} | ${r.buildMs.toFixed(0)} | ${r.msPerHour.toFixed(1)} |`);
P('');

// ---------------------------------------------------------------- Part C: social life
const SEEDS = Array.from({ length: 10 }, (_, i) => 101 + i);
const tables = loadTableDir('tables/consensus');
const mean = a => a.reduce((s, x) => s + x, 0) / a.length;
const sd = a => { const m = mean(a); return Math.sqrt(a.reduce((s, x) => s + (x - m) ** 2, 0) / (a.length - 1)); };
const ci = a => (1.96 * sd(a) / Math.sqrt(a.length));
P('### Social life: 1,000 villagers, 30 days, seeds 101–110, consensus tables, logs on (mean over seeds ± 1.96 × SD / √10)', '');
P('| Circle | Hamlet size | Friends per villager | Feuds per villager | Isolates (%) | Unkind-act share |', '| --- | --- | --- | --- | --- | --- |');
const social = {};
for (const hs of HAMLETS) {
  const rows = SEEDS.map(seed => {
    const sim = new Village({ ...DEFAULT_CONFIG, runSeed: seed, n: 1000, days: 30, hamletSize: hs, tableDir: 'tables/consensus', logDecisions: true }, tables);
    sim.run();
    let total = 0, unkind = 0;
    for (let i = 1; i < sim.eventLog.length; i++) {
      const act = sim.eventLog[i].split(',')[4];
      if (act === 'apologise' || act === '-') continue;
      total++; if (NEGATIVE_ACTS.has(act)) unkind++;
    }
    const last = sim.metrics[sim.metrics.length - 1];
    return { friends: 2 * last.friendships / 1000, feuds: 2 * last.feuds / 1000, isolatesPct: 100 * last.isolates / 1000, unkind: unkind / total };
  });
  social[hs] = Object.fromEntries(['friends', 'feuds', 'isolatesPct', 'unkind'].map(k => [k, { mean: mean(rows.map(r => r[k])), ci: ci(rows.map(r => r[k])) }]));
  const s = social[hs];
  P(`| ${hs - 1} | ${hs} | ${s.friends.mean.toFixed(2)} ± ${s.friends.ci.toFixed(2)} | ${s.feuds.mean.toFixed(3)} ± ${s.feuds.ci.toFixed(3)} | ${s.isolatesPct.mean.toFixed(2)} ± ${s.isolatesPct.ci.toFixed(2)} | ${s.unkind.mean.toFixed(4)} ± ${s.unkind.ci.toFixed(4)} |`);
}
P('');
writeFileSync(join(OUT, 'report.md'), lines.join('\n') + '\n');
writeFileSync(join(OUT, 'summary.json'), JSON.stringify({ cost, memory: mem, social, node: process.version }, null, 1));
