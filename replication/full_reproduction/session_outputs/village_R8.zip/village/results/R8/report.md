# R8 report (parts B and C)

## Part B: cost (US$; prices as given, per million tokens)

Table fill = 5000 input + 4000 output tokens. Live = 192 calls per villager per real hour × (300 in + 20 out).

| Model | Input / output price | One table fill | Live, per villager per real hour | Live, 1,000 villagers per real hour |
| --- | --- | --- | --- | --- |
| Claude Haiku 5.5 | 0.1 / 0.5 | $0.00250 | $0.00768 | $7.68 |
| Gemini 2.5 Flash-Lite | 0.1 / 0.4 | $0.00210 | $0.00730 | $7.30 |
| Claude Sonnet 5.5 | 2 / 10 | $0.05000 | $0.15 | $153.60 |
| Claude Opus 5.5 | 4 / 20 | $0.10 | $0.31 | $307.20 |
| GPT-5.5 | 5 / 30 | $0.14 | $0.40 | $403.20 |

## Part C: acquaintance circles

### Cost: 30,000 villagers, runSeed 101, decision log off (fresh Node process per size, GC forced)

| Circle (others known) | Hamlet size | Hamlets (last one) | Memory per villager (KB) | Build (ms) | ms per in-game hour (16 h) |
| --- | --- | --- | --- | --- | --- |
| 20 | 21 | 1429 (last 12) | 3.80 | 596 | 69.4 |
| 50 | 51 | 589 (last 12) | 7.09 | 486 | 91.5 |
| 100 | 101 | 298 (last 3) | 12.80 | 680 | 94.8 |

### Social life: 1,000 villagers, 30 days, seeds 101–110, consensus tables, logs on (mean over seeds ± 1.96 × SD / √10)

| Circle | Hamlet size | Friends per villager | Feuds per villager | Isolates (%) | Unkind-act share |
| --- | --- | --- | --- | --- | --- |
| 20 | 21 | 6.12 ± 0.06 | 0.116 ± 0.006 | 0.30 ± 0.06 | 0.0542 ± 0.0007 |
| 50 | 51 | 4.69 ± 0.05 | 0.037 ± 0.007 | 1.12 ± 0.14 | 0.0517 ± 0.0005 |
| 100 | 101 | 1.69 ± 0.04 | 0.010 ± 0.002 | 4.07 ± 0.36 | 0.0517 ± 0.0005 |

