# R7 report

n 1000 (castSeed 1, 50 hamlets of 20, 9500 within-hamlet pairs, 19000 directed likings), 1000 days, decision log off, steering off.

## Runs

| Tables | Seed | Run time (s) | missingRows | Final state hash |
| --- | --- | --- | --- | --- |
| consensus | 101 | 26.0 | 0 | `28d6e0d5e908f7aedb965f67f6f5d57f30968117fe66b33890b0c4850ef57f67` |
| consensus | 102 | 26.4 | 0 | `eb5beeae2e7a98f079f01dd05034f3bd27e8f2508a9fb6e0bfd94e007245254f` |
| consensus | 103 | 27.5 | 0 | `67dd8c39d4a4af136ce8aaa12361947242881f1288db4f9eb7f22b7b0d362fee` |
| consensus | 104 | 28.4 | 0 | `9f03fe7b0e9f53333109c7c00270affce1a10a5b4025a1168f4e4ef634f8d72b` |
| consensus | 105 | 26.6 | 0 | `76ece25edc6472ef59e653e8311db4800fb4959d31d80d737c2ef9c03939d8e8` |
| rules | 101 | 30.4 | 0 | `e90fd687b1d5fa55406607772ea21a7fe956217508a5092e88a5bafec5485c2e` |

## 1. Consensus tables, mean of seeds 101–105

| Day | Belief changes / villager / 100 d | Beliefs changed | Distinct belief combos | Likings changed | Friendships % of pairs | Feuds % of pairs | Isolates | Unkind share | Deeply held | Still as at start |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 50 | 14.704 | 89.7% | 140.4 | — | 42.84% | 1.47% | 2.0 | 0.0564 | 48.9% | 10.3% |
| 100 | 10.147 | 51.2% | 134.6 | 25.33% | 53.08% | 3.39% | 1.2 | 0.0699 | 53.3% | 7.7% |
| 250 | 10.031 | 40.0% | 130.6 | 4.89% | 57.36% | 6.84% | 1.4 | 0.0968 | 56.5% | 5.1% |
| 500 | 10.128 | 37.6% | 116.6 | 2.23% | 57.44% | 9.29% | 5.0 | 0.1117 | 58.6% | 4.0% |
| 750 | 10.042 | 36.7% | 115.2 | 1.85% | 57.44% | 10.45% | 5.8 | 0.1173 | 59.8% | 3.6% |
| 1000 | 10.104 | 36.7% | 115.4 | 1.62% | 57.47% | 11.14% | 5.6 | 0.1196 | 60.3% | 3.4% |

## 2. Day 1000, each run

| Run | Belief changes / villager / 100 d | Beliefs changed | Distinct belief combos | Likings changed | Friendships % of pairs | Feuds % of pairs | Isolates | Unkind share | Deeply held | Still as at start |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| consensus 101 | 10.206 | 37.2% | 113.0 | 1.70% | 56.96% | 11.15% | 5.0 | 0.1215 | 60.6% | 3.4% |
| consensus 102 | 10.014 | 37.1% | 115.0 | 1.76% | 58.09% | 11.01% | 4.0 | 0.1201 | 60.0% | 3.9% |
| consensus 103 | 9.674 | 36.2% | 112.0 | 1.57% | 57.77% | 10.88% | 5.0 | 0.1180 | 60.4% | 3.3% |
| consensus 104 | 10.100 | 36.0% | 114.0 | 1.45% | 57.57% | 11.22% | 4.0 | 0.1189 | 60.3% | 3.2% |
| consensus 105 | 10.524 | 37.1% | 123.0 | 1.63% | 56.97% | 11.44% | 10.0 | 0.1193 | 60.2% | 3.2% |
| rules 101 | 21.478 | 56.3% | 139.0 | 0.39% | 73.46% | 20.40% | 35.0 | 0.1070 | 56.7% | 1.8% |

