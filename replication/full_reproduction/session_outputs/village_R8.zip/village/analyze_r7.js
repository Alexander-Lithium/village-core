// R7: does a large village stay alive over a long time?
//   node analyze_r7.js --run <consensus|rules> <seed>  → results/R7/raw/<tables>_<seed>.json (series at every 50th day)
//   node analyze_r7.js --report                        → results/R7/report.md, series.csv, summary.json
//   node analyze_r7.js                                 → all six runs (missing ones), then the report
// n 1000 (castSeed 1, 50 hamlets of 20), 1000 days, decision log off, steering off.
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { Village, DEFAULT_CONFIG, PAIRS, COMPILED_TRAITS, beliefPosition } from './engine.js';
import { loadTableDir } from './run.js';

const here = dirname(fileURLToPath(import.meta.url));
const OUT = join(here, 'results', 'R7');
const RAW = join(OUT, 'raw');
const N = 1000, DAYS = 1000, STEP = 50;
const RUNS = [['consensus', 101], ['consensus', 102], ['consensus', 103], ['consensus', 104], ['consensus', 105], ['rules', 101]];
const UNKIND_EV = ['argued with', 'interrupted', 'ignored', 'credit taken'];
const ACT_EV = ['helped', 'chatted with', 'shared food with', 'argued with', 'interrupted', 'praised', 'ignored', 'credit taken', 'apologised to'];

function runOne(set, seed) {
  const t0 = performance.now();
  const sim = new Village({ ...DEFAULT_CONFIG, runSeed: seed, castSeed: 1, n: N, days: DAYS, tableDir: 'tables/' + set, logDecisions: false, suture: null }, loadTableDir('tables/' + set));
  const beliefs = () => sim.npcs.map(n => PAIRS.map(p => beliefPosition(n.beliefs[p])).join(','));
  const traits = () => sim.npcs.map(n => COMPILED_TRAITS.map(t => n.eff[t]).join(','));
  const likings = () => sim.npcs.flatMap(n => n.relOrder.map(o => n.rel.get(o.num).liking));
  const start = { beliefs: beliefs(), traits: traits() };
  let prev = { ...start, likings: null };
  const series = [];
  const total = DAYS * 16;
  while (sim.ticksRun < total) {
    sim.tick();
    if (sim.hour !== 0) continue;
    sim.snapshots.length = 0; // instrumentation only (not part of the state); dropped to keep memory small at n 1000
    const day = sim.day; // days completed
    if (day % STEP !== 0) continue;
    const m = sim.metrics[day - 1]; // the night metrics of this checkpoint day
    const win = sim.metrics.slice(day - STEP, day); // the 50 days since the previous checkpoint, this one included
    const moves = win.reduce((s, x) => s + x.moves.up + x.moves.down + x.moves.flip + x.moves.break, 0);
    const breaks = win.reduce((s, x) => s + x.moves.break, 0);
    const ev = k => win.reduce((s, x) => s + x.events[k], 0);
    const cur = { beliefs: beliefs(), traits: traits(), likings: likings() };
    const pos = sim.npcs.flatMap(n => PAIRS.map(p => beliefPosition(n.beliefs[p])));
    const share = (a, b) => a.filter((x, i) => x !== b[i]).length / a.length;
    series.push({
      day,
      friendships: m.friendships, feuds: m.feuds, isolates: m.isolates,
      friendsPerVillager: sim.npcs.reduce((s, n) => s + n.relOrder.filter(o => { const l = n.rel.get(o.num).liking; return l === 'like' || l === 'close'; }).length, 0) / N,
      distinctBeliefs: new Set(cur.beliefs).size,
      distinctTraits: new Set(cur.traits).size,
      deepShare: pos.filter(x => Math.abs(x) === 3).length / pos.length,
      positiveShare: pos.filter(x => x > 0).length / pos.length,
      beliefsChangedShare: share(cur.beliefs, prev.beliefs),
      traitsChangedShare: share(cur.traits, prev.traits),
      stillAsStartShare: 1 - share(cur.beliefs, start.beliefs),
      likingsChangedShare: prev.likings ? share(cur.likings, prev.likings) : null,
      beliefChangesPer100: moves / N * 2,
      breaksPer100: breaks * 2,
      unkindShare: UNKIND_EV.reduce((s, k) => s + ev(k), 0) / ACT_EV.reduce((s, k) => s + ev(k), 0),
    });
    prev = cur;
  }
  const ms = performance.now() - t0;
  const res = { tables: set, seed, n: N, days: DAYS, hamlets: sim.hamlets.length, pairs: sim.hamlets.reduce((s, h) => s + h.length * (h.length - 1) / 2, 0),
    directedLikings: sim.npcs.reduce((s, n) => s + n.relOrder.length, 0), stateHash: sim.stateHash(), castHash: sim.castHash, missingRows: sim.missingRows,
    runSeconds: ms / 1000, series };
  mkdirSync(RAW, { recursive: true });
  writeFileSync(join(RAW, `${set}_${seed}.json`), JSON.stringify(res));
  console.log(`${set} ${seed}: ${res.runSeconds.toFixed(1)} s, state ${res.stateHash}`);
}

const COLS = [
  ['beliefChangesPer100', 'Belief changes / villager / 100 d', x => x.toFixed(3)],
  ['beliefsChangedShare', 'Beliefs changed', x => (100 * x).toFixed(1) + '%'],
  ['distinctBeliefs', 'Distinct belief combos', x => x.toFixed(1)],
  ['likingsChangedShare', 'Likings changed', x => (x === null ? '—' : (100 * x).toFixed(2) + '%')],
  ['friendshipsPct', 'Friendships % of pairs', x => x.toFixed(2) + '%'],
  ['feudsPct', 'Feuds % of pairs', x => x.toFixed(2) + '%'],
  ['isolates', 'Isolates', x => x.toFixed(1)],
  ['unkindShare', 'Unkind share', x => x.toFixed(4)],
  ['deepShare', 'Deeply held', x => (100 * x).toFixed(1) + '%'],
  ['stillAsStartShare', 'Still as at start', x => (100 * x).toFixed(1) + '%'],
];
const ALL_KEYS = ['friendships', 'feuds', 'friendshipsPct', 'feudsPct', 'isolates', 'friendsPerVillager', 'distinctBeliefs', 'distinctTraits', 'deepShare', 'positiveShare',
  'beliefsChangedShare', 'traitsChangedShare', 'stillAsStartShare', 'likingsChangedShare', 'beliefChangesPer100', 'breaksPer100', 'unkindShare'];

function report() {
  const runs = RUNS.map(([s, seed]) => JSON.parse(readFileSync(join(RAW, `${s}_${seed}.json`), 'utf8')));
  for (const r of runs) for (const p of r.series) { p.friendshipsPct = 100 * p.friendships / r.pairs; p.feudsPct = 100 * p.feuds / r.pairs; }
  const cons = runs.filter(r => r.tables === 'consensus');
  const days = cons[0].series.map(p => p.day);
  const meanAt = (k, i) => { const v = cons.map(r => r.series[i][k]); return v[0] === null ? null : v.reduce((a, b) => a + b, 0) / v.length; };
  const lines = [];
  const P = (...l) => { for (const x of l) { lines.push(x); console.log(x); } };
  P('# R7 report', '', `n ${N} (castSeed 1, ${runs[0].hamlets} hamlets of 20, ${runs[0].pairs} within-hamlet pairs, ${runs[0].directedLikings} directed likings), ${DAYS} days, decision log off, steering off.`, '');
  P('## Runs', '', '| Tables | Seed | Run time (s) | missingRows | Final state hash |', '| --- | --- | --- | --- | --- |');
  for (const r of runs) P(`| ${r.tables} | ${r.seed} | ${r.runSeconds.toFixed(1)} | ${r.missingRows} | \`${r.stateHash}\` |`);
  P('', '## 1. Consensus tables, mean of seeds 101–105', '');
  P('| Day | ' + COLS.map(c => c[1]).join(' | ') + ' |', '|' + ' --- |'.repeat(COLS.length + 1));
  for (const d of [50, 100, 250, 500, 750, 1000]) {
    const i = days.indexOf(d);
    P(`| ${d} | ` + COLS.map(([k, , f]) => f(meanAt(k, i))).join(' | ') + ' |');
  }
  P('', '## 2. Day 1000, each run', '');
  P('| Run | ' + COLS.map(c => c[1]).join(' | ') + ' |', '|' + ' --- |'.repeat(COLS.length + 1));
  for (const r of runs) { const p = r.series[r.series.length - 1]; P(`| ${r.tables} ${r.seed} | ` + COLS.map(([k, , f]) => f(p[k])).join(' | ') + ' |'); }
  P('');
  // full series: every checkpoint, every run, plus the consensus mean
  const rowsOut = [];
  for (const r of runs) for (const p of r.series) rowsOut.push([r.tables, r.seed, p.day, ...ALL_KEYS.map(k => p[k] ?? '')]);
  days.forEach((d, i) => rowsOut.push(['consensus', 'mean', d, ...ALL_KEYS.map(k => meanAt(k, i) ?? '')]));
  writeFileSync(join(OUT, 'series.csv'), ['tables,seed,day,' + ALL_KEYS.join(','), ...rowsOut.map(r => r.join(','))].join('\n') + '\n');
  writeFileSync(join(OUT, 'report.md'), lines.join('\n') + '\n');
  writeFileSync(join(OUT, 'summary.json'), JSON.stringify({ runs: runs.map(r => ({ tables: r.tables, seed: r.seed, runSeconds: r.runSeconds, stateHash: r.stateHash, missingRows: r.missingRows })) }, null, 1));
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const a = process.argv.slice(2);
  mkdirSync(OUT, { recursive: true });
  if (a[0] === '--run') runOne(a[1], parseInt(a[2], 10));
  else if (a[0] === '--report') report();
  else { for (const [s, seed] of RUNS) if (!existsSync(join(RAW, `${s}_${seed}.json`))) runOne(s, seed); report(); }
}
