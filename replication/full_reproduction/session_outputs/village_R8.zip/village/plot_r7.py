# R7 chart: four small panels over time from results/R7/series.csv → results/R7/r7_over_time.png
# python3 plot_r7.py
import csv, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results", "R7")
BLUE, ORANGE = "#2a78d6", "#eb6834"          # categorical slots 1–2 (validated, light mode)
INK, INK2, GRID, SURF = "#0b0b0b", "#52514e", "#e4e3df", "#fcfcfb"

rows = list(csv.DictReader(open(os.path.join(OUT, "series.csv"))))
def series(tables, seed, key):
    pts = [(int(r["day"]), float(r[key])) for r in rows if r["tables"] == tables and r["seed"] == seed and r[key] != ""]
    return [p[0] for p in pts], [p[1] for p in pts]
SEEDS = sorted({r["seed"] for r in rows if r["tables"] == "consensus" and r["seed"] != "mean"})

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": GRID, "axes.labelcolor": INK2,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.titlecolor": INK, "figure.facecolor": SURF, "axes.facecolor": SURF})
fig, axes = plt.subplots(2, 2, figsize=(11, 7.4))
panels = [
    (axes[0, 0], "Belief changes per villager per 100 days", [("beliefChangesPer100", "-", 1)], ""),
    (axes[0, 1], "Share of villagers whose beliefs changed since the last checkpoint", [("beliefsChangedShare", "-", 100)], "%"),
    (axes[1, 0], "Share of likings that changed since the last checkpoint", [("likingsChangedShare", "-", 100)], "%"),
    (axes[1, 1], "Friendships (solid) and feuds (dashed), % of within-hamlet pairs", [("friendshipsPct", "-", 1), ("feudsPct", "--", 1)], "%"),
]
for ax, title, keys, unit in panels:
    for key, ls, mul in keys:
        for s in SEEDS:  # individual consensus seeds, thin and light, behind the mean
            x, y = series("consensus", s, key)
            ax.plot(x, [v * mul for v in y], color=BLUE, lw=0.8, alpha=0.25, ls=ls)
        for tables, seed, color in [("consensus", "mean", BLUE), ("rules", "101", ORANGE)]:
            x, y = series(tables, seed, key)
            y = [v * mul for v in y]
            ax.plot(x, y, color=color, lw=2, ls=ls, marker="o", ms=3)
            if len(keys) > 1:  # direct labels in the two-measure panel
                lab = ("friendships" if key == "friendshipsPct" else "feuds") + (" · consensus" if tables == "consensus" else " · rules")
                ax.annotate(lab, (x[-1], y[-1]), xytext=(4, 0), textcoords="offset points", va="center", fontsize=8, color=INK2)
    ax.set_title(title, fontsize=9.5, loc="left", pad=6)
    ax.grid(True, color=GRID, lw=0.6)
    ax.set_axisbelow(True)
    for sp in ["top", "right"]:
        ax.spines[sp].set_visible(False)
    ax.set_ylim(bottom=0)
    if unit == "%":
        ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:g}%"))
    ax.set_xlim(0, 1000)
    ax.set_xticks(range(0, 1001, 200))
for ax in axes[1]:
    ax.set_xlabel("Day")
axes[1, 1].set_xlim(0, 1230)
axes[1, 1].set_xticks(range(0, 1001, 200))
from matplotlib.lines import Line2D
fig.legend(handles=[Line2D([], [], color=BLUE, lw=2, marker="o", ms=3, label="Consensus tables, mean of seeds 101–105 (thin: each seed)"),
                    Line2D([], [], color=ORANGE, lw=2, marker="o", ms=3, label="Rule tables, seed 101")],
           loc="upper left", bbox_to_anchor=(0.005, 0.955), ncol=2, frameon=False, fontsize=9, labelcolor=INK)
fig.suptitle("1,000 villagers over 1,000 days (checkpoints every 50 days)", y=0.995, fontsize=11, color=INK, x=0.01, ha="left")
fig.tight_layout(rect=(0, 0, 1, 0.91))
fig.savefig(os.path.join(OUT, "r7_over_time.png"), dpi=150)
print("wrote results/R7/r7_over_time.png")
