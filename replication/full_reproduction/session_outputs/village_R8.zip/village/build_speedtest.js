// R8 Part A: builds speedtest.html, a self-contained speed test (engine, sha256, consensus tables, cast generator inlined).
//   node build_speedtest.js   → speedtest.html
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { loadTableDir } from './run.js';

const here = dirname(fileURLToPath(import.meta.url));
const stripModule = src => src.replace(/^import .*$/gm, '').replace(/^export (const|function|class|let) /gm, '$1 ');
const code = stripModule(readFileSync(join(here, 'sha256.js'), 'utf8')) + '\n' + stripModule(readFileSync(join(here, 'engine.js'), 'utf8'));
const tables = JSON.stringify(loadTableDir('tables/consensus')).replace(/</g, '\\u003c');
// reference: consensus, runSeed 101, n 20, 30 days (the R5 replay) — the page re-runs it to check the inlined engine
const CHECK_HASH = 'cf14cf19ee6c6c7172eecb2654eca4f58e656030886419b7e0980862428c7f52';

const html = `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Village Speed Test</title>
<style>
/* layout: one column, controls on top, live results table, device panel, copyable text */
:root{
  --bg:#f4f5f3; --panel:#ffffff; --ink:#1b1d1c; --ink2:#5b605d; --line:#dcdfdb; --accent:#2a6f97; --warn:#a4570b; --ok:#2e7d32;
  --body:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif; --mono:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
  color-scheme:light;
}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){
  --bg:#151817; --panel:#1e2220; --ink:#e8ebe8; --ink2:#a5aca8; --line:#343a37; --accent:#6fb3d9; --warn:#e3a35b; --ok:#7cc480; color-scheme:dark;}}
:root[data-theme="dark"]{--bg:#151817; --panel:#1e2220; --ink:#e8ebe8; --ink2:#a5aca8; --line:#343a37; --accent:#6fb3d9; --warn:#e3a35b; --ok:#7cc480; color-scheme:dark;}
html,body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.45 var(--body)}
main{max-width:860px;margin:0 auto;padding:16px;display:grid;gap:14px}
h1{font-size:20px;margin:0;text-wrap:balance}
p{margin:0;color:var(--ink2);max-width:65ch}
.panel{background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:12px;display:grid;gap:8px}
.row{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
button{font:inherit;padding:8px 16px;border-radius:6px;border:1px solid var(--accent);background:var(--accent);color:var(--panel);cursor:pointer}
button.secondary{background:transparent;color:var(--accent)}
button:disabled{opacity:.5;cursor:default}
button:focus-visible{outline:3px solid var(--ink);outline-offset:2px}
#status{font-family:var(--mono);font-size:13px;color:var(--ink2)}
.pill{display:inline-block;padding:1px 8px;border-radius:10px;border:1px solid currentColor;font-size:12px}
.pill.ok{color:var(--ok)} .pill.warn{color:var(--warn)}
.tablewrap{overflow-x:auto}
table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums;font-size:14px}
th,td{padding:6px 8px;border-bottom:1px solid var(--line);text-align:right;white-space:nowrap}
th:first-child,td:first-child{text-align:left}
th{color:var(--ink2);font-weight:600;font-size:12px}
td.over{color:var(--warn);font-weight:600}
dl{display:grid;grid-template-columns:max-content 1fr;gap:4px 12px;margin:0;font-size:13px}
dt{color:var(--ink2)} dd{margin:0;font-family:var(--mono);word-break:break-all}
textarea{width:100%;box-sizing:border-box;min-height:150px;font:12px/1.4 var(--mono);background:var(--bg);color:var(--ink);border:1px solid var(--line);border-radius:6px;padding:8px}
.bar{height:6px;background:var(--line);border-radius:3px;overflow:hidden;min-width:60px}
.bar>i{display:block;height:100%;background:var(--accent)}
</style></head>
<body><main>
<h1>Village speed test</h1>
<p>Grows the village from 10 to 1,000,000 villagers (consensus tables, hamlets of 20, decision log off) and times whole in-game hours. Budget: 18.75 s per in-game hour, the pace at which one in-game day lasts 5 real minutes. Keep the screen on and this tab in front while it runs.</p>
<section class="panel">
  <div class="row"><button id="start" type="button">Start</button><button id="copy" class="secondary" type="button" disabled>Copy results</button><span id="engine" class="pill">engine check: not run</span></div>
  <div id="status">Ready.</div>
</section>
<section class="panel">
  <div class="tablewrap"><table id="results"><thead><tr><th>Villagers</th><th>ms / in-game hour</th><th>µs / villager-hour</th><th>% of 18.75 s</th><th>Budget used</th><th>Setup (ms)</th><th>Repeats</th><th>Hours timed</th></tr></thead><tbody></tbody></table></div>
  <div id="stop" class="row"></div>
</section>
<section class="panel">
  <dl id="device"></dl>
</section>
<section class="panel">
  <label for="out">Results as text (also copied by the button)</label>
  <textarea id="out" readonly></textarea>
</section>
</main>
<script>
${code}
const TABLES = ${tables};
const CHECK_HASH = '${CHECK_HASH}';
const SIZES = [10, 30, 100, 300, 1000, 3000, 10000, 30000, 100000, 300000, 1000000];
const BUDGET_MS = 18750, BUILD_LIMIT_MS = 30000, KB_PER_VILLAGER = 4.8;
const $ = id => document.getElementById(id);
const pause = () => new Promise(r => setTimeout(r, 0));
const median = a => { const s = a.slice().sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; };
const fmt = (x, d = 1) => x.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });

const dm = navigator.deviceMemory;
const dmUsed = typeof dm === 'number' ? dm : 4;
const LIMIT_MB = dmUsed >= 8 ? 1600 : dmUsed * 1024 / 5;
const device = {
  'User agent': navigator.userAgent,
  'Logical cores': navigator.hardwareConcurrency ?? 'not reported',
  'deviceMemory': typeof dm === 'number' ? dm + ' GB' : 'not reported (assumed 4)',
  'Memory limit': fmt(LIMIT_MB, 1) + ' MB (at ' + KB_PER_VILLAGER + ' KB per villager)',
  'Screen': screen.width + ' × ' + screen.height + ' @ ' + (window.devicePixelRatio || 1) + 'x',
  'Viewport': window.innerWidth + ' × ' + window.innerHeight,
};
$('device').innerHTML = Object.entries(device).map(([k, v]) => '<dt>' + k + '</dt><dd>' + String(v).replace(/</g, '&lt;') + '</dd>').join('');

const rows = []; let stopReason = '', engineCheck = 'not run', startedAt = '';

function resultsText() {
  const L = ['Village speed test (R8 Part A)', 'Started: ' + startedAt];
  for (const [k, v] of Object.entries(device)) L.push(k + ': ' + v);
  L.push('Engine check: ' + engineCheck);
  L.push('villagers\\tms_per_hour\\tus_per_villager_hour\\tpct_budget\\tsetup_ms\\trepeats\\thours_timed');
  for (const r of rows) L.push([r.n, r.msPerHour.toFixed(3), r.usPerVH.toFixed(4), r.pct.toFixed(3), r.setup.toFixed(1), r.repeats, r.hours.join('/')].join('\\t'));
  L.push('Stop reason: ' + (stopReason || '(still running)'));
  return L.join('\\n');
}
function render() {
  $('results').tBodies[0].innerHTML = rows.map(r => '<tr><td>' + r.n.toLocaleString('en-US') + '</td><td' + (r.msPerHour > BUDGET_MS ? ' class="over"' : '') + '>' + fmt(r.msPerHour, 2) +
    '</td><td>' + fmt(r.usPerVH, 3) + '</td><td>' + fmt(r.pct, 2) + '%</td><td><div class="bar"><i style="width:' + Math.min(100, r.pct).toFixed(1) + '%"></i></div></td><td>' +
    fmt(r.setup, 1) + '</td><td>' + r.repeats + '</td><td>' + r.hours.join(' / ') + '</td></tr>').join('');
  $('stop').innerHTML = stopReason ? '<span class="pill ' + (stopReason.startsWith('Reached') ? 'ok' : 'warn') + '">Stopped</span> <span>' + stopReason + '</span>' : '';
  $('out').value = resultsText();
}

function makeVillage(n, runSeed, days) {
  return new Village({ ...DEFAULT_CONFIG, runSeed, n, days, hamletSize: 20, tableDir: 'consensus', logDecisions: false, suture: null }, TABLES);
}
async function measure(n, rep) {
  $('status').textContent = n.toLocaleString('en-US') + ' villagers, repeat ' + (rep + 1) + ': building…';
  await pause();
  const t0 = performance.now();
  let sim = makeVillage(n, 101 + rep, 1000000);
  const setup = performance.now() - t0;
  let hours = 0, timed = 0;
  while (true) {
    const a = performance.now();
    sim.tick();
    timed += performance.now() - a;
    hours++;
    sim.encounters.length = 0; sim.snapshots.length = 0; // instrumentation only, cleared outside the timed hour
    if (hours >= 48 || (hours >= 4 && timed >= 1500)) break;
    if (hours % 4 === 0) {
      $('status').textContent = n.toLocaleString('en-US') + ' villagers, repeat ' + (rep + 1) + ': ' + hours + ' hours timed, ' + fmt(timed / hours, 2) + ' ms per hour';
      await pause();
    }
  }
  sim = null;
  return { setup, msPerHour: timed / hours, hours };
}

async function run() {
  $('start').disabled = true; rows.length = 0; stopReason = ''; startedAt = new Date().toISOString();
  try { if (navigator.wakeLock) await navigator.wakeLock.request('screen'); } catch (e) {}
  // engine check: the inlined engine must reproduce a known state
  $('status').textContent = 'Checking the engine…'; await pause();
  const chk = makeVillage(20, 101, 30); chk.run();
  const ok = chk.stateHash() === CHECK_HASH;
  engineCheck = (ok ? 'pass' : 'FAIL') + ' (consensus seed 101, n 20, 30 days: ' + chk.stateHash().slice(0, 16) + '…)';
  $('engine').textContent = 'engine check: ' + (ok ? 'pass' : 'FAIL'); $('engine').className = 'pill ' + (ok ? 'ok' : 'warn');
  render();
  for (const n of SIZES) {
    const estMB = n * KB_PER_VILLAGER / 1024;
    if (estMB > LIMIT_MB) { stopReason = 'Skipped ' + n.toLocaleString('en-US') + ' villagers: estimated memory ' + fmt(estMB, 0) + ' MB is over the ' + fmt(LIMIT_MB, 0) + ' MB limit.'; break; }
    const reps = n <= 10000 ? 3 : 1;
    const res = [];
    try { for (let r = 0; r < reps; r++) res.push(await measure(n, r)); }
    catch (e) { stopReason = 'Error at ' + n.toLocaleString('en-US') + ' villagers: ' + (e && e.message ? e.message : e); break; }
    const msPerHour = median(res.map(x => x.msPerHour)), setup = median(res.map(x => x.setup));
    rows.push({ n, msPerHour, usPerVH: msPerHour * 1000 / n, pct: 100 * msPerHour / BUDGET_MS, setup, repeats: reps, hours: res.map(x => x.hours) });
    render();
    if (msPerHour > BUDGET_MS) { stopReason = 'One in-game hour took ' + fmt(msPerHour / 1000, 2) + ' s at ' + n.toLocaleString('en-US') + ' villagers (over 18.75 s).'; break; }
    if (setup > BUILD_LIMIT_MS) { stopReason = 'Building ' + n.toLocaleString('en-US') + ' villagers took ' + fmt(setup / 1000, 1) + ' s (over 30 s).'; break; }
    if (n === 1000000) stopReason = 'Reached 1,000,000 villagers.';
    await pause();
  }
  $('status').textContent = 'Done.'; $('copy').disabled = false; $('start').disabled = false; $('start').textContent = 'Run again';
  render();
}
$('start').addEventListener('click', run);
$('copy').addEventListener('click', async () => {
  const text = resultsText();
  try { await navigator.clipboard.writeText(text); $('copy').textContent = 'Copied'; }
  catch (e) { const t = $('out'); t.focus(); t.select(); try { document.execCommand('copy'); $('copy').textContent = 'Copied'; } catch (e2) { $('copy').textContent = 'Select the text below and copy it'; } }
  setTimeout(() => { $('copy').textContent = 'Copy results'; }, 2500);
});
render();
</script>
</body></html>
`;
writeFileSync(join(here, 'speedtest.html'), html);
console.log(`wrote speedtest.html (${html.length} bytes)`);
